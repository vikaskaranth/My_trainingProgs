trap "echo  caught signal siginit" SIGINT
trap "echo  caught signal sigquit" 3
trap "echo  caught signal sigterm" 15

while :
#while true
do	
	sleep 50
done
