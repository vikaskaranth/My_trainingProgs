# dffds
mailopt=FALSE
interval=60 

while getopts mt: option
do
      case "$option" in 
	 	m) mailopt=TRUE;;
		t) interval=$OPTARG;;
	 	\?)  echo "Usage getopt [-m][-t n ] user"
	     	echo "-m means to be informed by mail"
			echo "-t means check every n secs"
			exit 1;;
      esac
done

# make sure user name is specified

if [ $OPTIND -gt $# ]
then
    echo "Missing user name!"
    exit  2
fi
shiftcount=$(($OPTIND))
