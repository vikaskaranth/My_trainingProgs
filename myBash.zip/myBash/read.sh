count=0

while read lline
do
	count=`expr $count + 1`
done  < $1
echo "$count"
