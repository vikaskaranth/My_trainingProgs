#!/bin/bash
if [ $# -eq 1 ]; then
	if [ -e $1 ] ; then
    		echo "file existes"
    		if [ -f $1 ] ; then
         		if [ -r $1 ] ; then
	          	echo -e "Has read permission\n"
			else
		    		echo -e "No permission\n"
		    		chmod u+r $1
		    		echo -e " permission given\n"
			fi
     	else
			echo -e "Not a reguler file\n"
		fi
	else
		echo -e "File does not exeistes\n"
	fi
else
	echo  "Wrong number of arguments"
	echo -e "Usage : Script [options] filename \n"
fi
