#!/bin/bash
## program to illustrate for loop

for file in `ls` 
do 
	grep -l "test" $file > /dev/null
	if [ $? -eq 0 ]
	then
		echo $file 
	fi
done
