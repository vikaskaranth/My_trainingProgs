#! /bin/bash

yes_or_no()
{
	echo "Is your name $*?"
	while true
	do
		echo -n "Enter yes or no   :"
		read	ch
		case	$ch in
			yes| y | Y) return 0;;
			no | n |N) return 1;;
			*) echo "Answer Yes or No"
		esac
	done
}

# Main program begins here
if yes_or_no $1
then
	echo	"Hai $1 nice name"
else
	echo	"Never mind"
fi
exit 0	
