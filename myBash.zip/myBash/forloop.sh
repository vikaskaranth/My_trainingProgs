#!/bin/bash

for i in `seq 1 5 100`
do
    echo $i
done

