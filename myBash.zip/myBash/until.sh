#!/bin/bash
a=0
until test $a -gt 20
do
	echo -e "$a\n"
	a=$(($a+1))
done

