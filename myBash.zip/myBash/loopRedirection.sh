#!/bin/bash

##
##  Script to redirect the loop's output to file
##

for i in 1 2 3 4 5
do
    echo $i
done > loopout
