#!/bin/bash

echo " enter a number"
read num
if [ $num -gt 100 ]; then
	echo " greater than 100"
elif [ $num -lt 100  ] ; then
	echo " number is less then  100"
elif [ $num -ne 100 ] ; then
	echo "number is not eq to 100"
elif [ $num -le 100 ] ; then
	echo "number is less than or equal to100"
elif [ $num -eq 100 ] ; then
	echo " number is 100"
fi
