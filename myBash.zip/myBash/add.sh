#!/bin/bash

echo "Enter  a  number"
read num1
echo "Enter  a  number"
read num2
total=`expr $num1 + $num2`
echo $total

echo -e "\v"

#   only in POSIX standred shell 
#   Some older shell do not support this
sum=$(($num1 + $num2)) 
echo "sum is "$sum









#echo $[ $num1+$num2 ]
