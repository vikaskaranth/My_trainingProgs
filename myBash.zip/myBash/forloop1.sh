#!/bin/bash
for k in clear date cal
do
	sleep 1
	$k
done



#for variable in arguments
#do
#	do this
#done
