#! /bin/bash

IFS=':'

set foo bar bam
echo "$*"	
echo  $*
echo  "$@"	
echo  $@

unset IFS	
echo After unsetting IFS echo \$*

echo "$*"


