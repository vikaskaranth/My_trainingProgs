echo "enter some integer"
read a
echo "enter some integer"
read b
c=30
if test $(($a+$b)) -eq $c
#if test `expr $a + $b` -eq $c
then
	echo "equal"
elif test $a -eq 0
then
	echo "\$a is zero"
else
	echo "not equal"
fi
