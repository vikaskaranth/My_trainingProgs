#!/bin/bash

if [ $1 = $2 ]; then
    echo "eq"
 else
   echo "neq"


fi
