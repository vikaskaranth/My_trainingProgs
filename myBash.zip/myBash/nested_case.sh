#!/bin/bash

echo -e  "1) a \n 2) b \n 3) c \n 4) d \n 5) e" 
echo "select any one:"
read Opt
case $Opt in
	a)   echo "enter a1 a2 or a3"
		read Choice
		case $Choice in
			a1) echo "one";;
			a2) echo "two";;
			a3) echo "three"
		esac
		;;
	b) echo "case two selected";;
	c) echo "case  three selected";;
	d) echo "case  four selected";;
	e) echo "case  five selected";;
esac

