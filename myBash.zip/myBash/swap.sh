#!/bin/bash

##
## Swaping two files
## Check usage is proper
##

if [ $# -eq 2 ]; then
	mv $1 /tmp/$1
	mv $2 $1
	mv /tmp/$1 $2
else
    echo "Usage is : swap.sh <file1> <file2>"
fi
