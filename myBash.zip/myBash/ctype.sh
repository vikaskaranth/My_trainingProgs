#!/bin/bash
#
#    Classify charecter given as argument
#

if [ $# -ne 1 ]
then
    echo "Usage: ctype char"
    exit 1
fi
#
# Ensure that only one charecter is typed

char="$1"
numchars=$(echo $char | wc -c)
echo $numchars
if [ $numchars -ne 1 ]
then
     echo " Please type single char"
	exit 1
fi
#
# Now classify it

case $char in
	[0-9] ) echo "Digit";;
	[a-z] ) echo "lower case";;
	[A-Z] ) echo "Upper case";;
	* ) echo "Special charecter";;
esac
