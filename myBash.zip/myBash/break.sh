#!/bin/bash

rm -rf fred*
echo > fred1
echo > fred2
mkdir fred3
echo > fred4

for file in fred*
do
	if [ -d "$file" ] ; then
	break
	fi
	echo the file is $file
done

echo first directory starting with fred was $file

rm -rf fred*
if [ $? -eq 0 ];then
	exit 0
else
	exit 1
fi	

