echo "enter  integer value"
read a1
echo "enter integer value"
read a2
#if [ $a1 -eq $a2 ]; then
#	echo "the entred values are same"
#else
#	echo "Not equal"
#fi

if test $a1 -eq $a2 
then
	echo "the entred values are same"
else
	echo "Not equal"
fi
