
declare -i sum x=10
declare -i c=1 
declare -i d=2
declare -i e 
a=100
b=20
echo 'expr $a + $b is :'  `expr $a + $b `

sum=$a+$b
echo 'sum=$a+$b is:' $sum

echo '$[ $a * $b ] ' $[ $a * $b ]

echo '$(($a/$b))'  $(($a/$b))

e=c+d+x
echo $e
