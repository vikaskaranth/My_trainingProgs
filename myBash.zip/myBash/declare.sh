#!/bin/bash

declare -i a=20 c=5
declare -i b=30
declare -i sum
sum=a+c+b
echo The sum of $a $c and $b is $sum

