#! /bin/bash

touch file_one
rm -f file_two

if [ -e "file_two" ] || echo "Here" || [ -f "file_one" ] || echo "Hello" 
then
	echo  "in if"
else
	echo	"in else"
fi
exit 0
