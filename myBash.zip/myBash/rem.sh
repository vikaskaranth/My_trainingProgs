#!/bin/bash
#
#  Remove some one fron the phone book
#
if [ $# -ne 1 ]; then
    echo "Incorrect number of arguments"
    echo "Usage: rem.sh name"
    exit 1
fi

name=$1
#
#  Find number of maching
#
matches=$(grep "$name" phonebook | wc -l)
#
# if more than on match Issue a message else remove
#

if [ $matches -gt 1 ]; then
	echo "More than one match qulify further"
elif [ $matches -eq 1 ]; then
     grep -v "$name" phonebook > /tmp/phonebook
	mv /tmp/phonebook phonebook
fi
