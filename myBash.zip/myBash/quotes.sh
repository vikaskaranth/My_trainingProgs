#! /bin/bash
myvar="Hai there"

echo $myvar
echo "$myvar"
echo '$myvar'
echo \$myvar

echo Enter some text
read  myvar
echo '$myvar' is equal to $myvar
exit 0
