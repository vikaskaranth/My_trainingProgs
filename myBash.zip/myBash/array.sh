#!/bin/bash
array[0]="Vikas karanth"
array[1]="Suhas karanth"
array[2]="ullas karanth"

#echo -e "First name : ${array[0]}"
#echo -e "sec name : ${array[1]}"
#echo -e "third name : ${array[2]}"

#echo -e "name s: ${array[*]}\n"
#echo -e "Total number of names: ${#array[*]}\n"

Total=`expr ${#array[*]} - 1`
for ctr in `seq 0  $Total`
do
	echo -e "$ctr name is ${array[$ctr]}\n"
done
