#!/bin/bash
function quit {
   echo -e "\n\n I am quiting..............\n"
   exit
}
function Myfunct {
      echo  $1 $2 $3 $4 $5
}

Myfunct Let Us Bring New Age 
Myfunct To The World

echo -e "In the main script : $1  \t $2 \t $3"
quit
echo "This will not print"
