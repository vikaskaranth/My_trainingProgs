#/bin/bash
# script to illustrate while loop in shell
a=0
while  test $a -lt 50		
do
	echo -e "\t$a"
	a=$(($a+1))	# increment 'a' by 1
	if test $a -eq 20
	then
 		exit
	fi
done
	echo "Script is exited ; This will not print"
