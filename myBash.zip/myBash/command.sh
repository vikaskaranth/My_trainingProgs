#!/bin/bash
sleep 1&
echo "\$0 is "$0
echo "\$1 is "$1
echo "\$2 is "$2
echo "\$3 is "$3
echo "\$4 is "$4
echo "\$5 is "$5
echo "\$6 is "$6
echo "\$7 is "$7
echo "\$8 is "$8
echo "\$9 is "$9
echo "\${10} is "${10}
echo "\${11} is "${11}
echo "All the parameters are : "$*
echo "All the parameters are : "$@
echo "Total num of parameters  "$#
echo "Current process ID is :"$$
echo "process ID is :"$!
