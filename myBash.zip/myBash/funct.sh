#!/bin/bash

Var="HELLO"
AnotherVar="Light"
function hello {
           local Var="World"
		 AnotherVar="White Light"
           echo "In function : $Var"
		 echo 'In function $AnotherVar is :' $AnotherVar
}
echo " Before calling function : $Var"
echo 'Before calling  function $AnotherVar is :' $AnotherVar
hello  #Function invokation
echo "After calling function : $Var"
echo 'After calling  function $AnotherVar is :' $AnotherVar
