# script to  illustrate case in shell scripting

echo -e  " 1) a \n 2) b \n 3) c \n 4) d \n 5)  e" 
echo "select any one:"
read a
case $a in
	a|A)echo "case one selected"
		;;
	B|b)echo "case two selected"
		echo " testing multiple statement"
		;;
	c)echo "case  three selected";;
	d)echo "case four selected";;
	e)echo "case five selected";;
	*)echo "INVALID"
esac
echo " End of script"
