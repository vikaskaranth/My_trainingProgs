/*file2.c*/
#include <stdio.h>

int a = 1, b = 3;
int f (void);

int main (void)
{
printf ("%3d\n", f ());
printf ("%3d %3d\n", a, b);
}

