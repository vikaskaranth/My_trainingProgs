#include<stdio.h> 

main()
{
      int iData;
      iData=100;
      printf("%d\n",iData);
}
int iData;
