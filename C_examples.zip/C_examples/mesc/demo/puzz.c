#include<stdio.h> 

main()
{
    x, y= 5, 6;
   
    printf("x is %d",x);// garbage
    printf("y is %d",y);// 5
}
