#include<stdio.h> 

extern int  iData; //No memory is allocated so far

static void foo(void)
{
    iData=100;
    printf("In foo %d",iData);
}
