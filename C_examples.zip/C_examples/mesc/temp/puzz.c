#include<stdio.h> 
int iData=100;
main()
{
    int iData=10;
    printf("In main %d\n",iData);
    {
        int iData=55;
        printf("Inner block main %d\n",iData);
    }
    printf("In main after inner blk%d\n",iData);
}
