#include<stdio.h> 
int iData; // Do not allocate memory

void bar()
{
    iData=55;
    printf("In bar () %d",iData);
}
