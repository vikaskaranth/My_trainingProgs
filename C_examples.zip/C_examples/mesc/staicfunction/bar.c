#include<stdio.h> 
extern int iData; // Do not allocate memory

void bar()
{
     foo();
}
