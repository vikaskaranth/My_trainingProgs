#include<stdio.h>
#include<string.h>
#include<math.h>
main()
{
	char num[10];
	char temp[10];
	double sum=0;
	int i,l1;
	int j=0;
	printf("enter the hexa decimal no\n");
	scanf("%s",num);
	l1=strlen(num);
	for(i=l1-1;i>1;i--)
	{
		
		switch(num[i])
		{
			case 'a':
			case 'A':
				{
					sum+=10*(pow(16,j));
					j++;
					break;
				}
			case 'b':
			case 'B':
				{
					sum+=11*(pow(16,j));
					j++;
					break;
				}
			case 'c':
			case 'C':
				{
					sum+=12*(pow(16,j));
					j++;
					break;
				}
			case 'd':
			case 'D':
				{
					sum+=13*(pow(16,j));
					j++;
					break;
				}
			case 'e':
			case 'E':
				{
					sum+=14*(pow(16,j));
					j++;
					break;
				}
			case 'f':
			case 'F':
				{
					sum+=15*(pow(16,j));
					j++;
					break;
				}
			default:
				{
					sum+=(num[i]-'0')*(pow(16,j));
					j++;
					break;
				}
		}
	}
	
	printf("the hexa decimal no is   %g\n",sum);


}
