#include<math.h>
main()
{
 	const float pi=3.14156;
 	float area,radius;
	printf("Enter the radius of the circle\n");
	scanf("%f",&radius);
 	area=pi*(pow(radius,2));
	printf("Area of the circle is %f\n",area);
}
