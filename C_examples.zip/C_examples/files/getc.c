/*	program	to read from file and display contents on the screen   */

# include <stdio.h>

main(int argc, char  *argv[])
{
	FILE	*fp;
	char	ch;
	if(argc!= 2){
		printf("usage: a.out <file name>\n");
		_exit(1);  // exit with error
	}
	if((fp=fopen(argv[1],"r")) == NULL){
		printf("Can't open a file");
		_exit(2);
	}
	ch = fgetc(fp);
	while(ch!=EOF)
	{ 
		putchar(ch);
		ch = fgetc(fp);
	}
	fclose(fp);
	getchar();
}
