# include <stdio.h>
main(int argc, char  *argv[])
{
	FILE	*in,*out;
	char	ch;
	if(argc!= 3){
		printf("usage: a.out <source file name> <target file name>\n");
		exit(1);
	}
	// in is read pointer
	if((in=fopen(argv[1],"rb")) == NULL){
		printf("Can't open a file for in");
		exit(2);
	}
	//out is write pointer
	if((out=fopen(argv[2],"wb")) == NULL){
		printf("Can't open a file for out");
		exit(3);
	}
	do{
	 	ch = getc(in);	//read from  file
		putc(ch,out);	//write into file
	}while(ch!=EOF); //EOF is ctrl D
	fclose(in);	//Close read pointer 
	fclose(out);	//Close write pointer
}
