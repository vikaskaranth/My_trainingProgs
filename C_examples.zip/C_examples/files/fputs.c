# include <stdio.h>
main()
{
	char	str[80];
	FILE	*fp;
	if((fp = fopen("Test","w")) == NULL){	//open a file with Write mode
		printf("Can't open a file\n");
		exit(1);
	}
	do{
		printf("Enter a string, <CR> to quit	>");
		gets(str);
		strcat(str,"\n");	//add a new line
		fputs(str,fp);
	} while(*str!='\n');
}

