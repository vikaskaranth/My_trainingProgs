/*	Key to disk program	*/

# include <stdio.h>

main(int argc, char  *argv[])
{
	FILE	*fp;
	char	ch;
	if(argc!= 2){
		printf("usage: a.out <file name>\n");
		_exit(1);
	}
	if((fp=fopen(argv[1],"w")) == NULL){
		printf("Can't open a file");
		_exit(2);
	}
	do{
		fputc(ch=getchar(),fp);
	}while(ch!=EOF); //EOF is ctrl D
	fclose(fp);
}
