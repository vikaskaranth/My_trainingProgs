#include<stdio.h> 

long length(char []);

main()
{
  	char str[20];
	printf("enter any string ");
	scanf("%[^\n]s",str);
	printf("\nlength of the string entered is %d\n",length(str));
}

long length(char arr[])
{
	int i;
	for(i = 0; arr[i]!='\0'; i++)
		;
	return i;
}
