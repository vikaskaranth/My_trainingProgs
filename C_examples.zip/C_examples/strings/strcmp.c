# include <stdio.h>
int strcomp(char [], char []);

main()
{
	char str1[20],  str2[20];
	int comp;
	printf("enter any string ");
	scanf("%[^\n]s",str1);
	printf("enter another string\n");
	__fpurge(stdin);
	scanf("%[^\n]s",str2);
	comp=strcomp(str1,str2);
	if(comp == 0)
		printf("srings are identical\n");
	else if(comp < 0)
		printf("%s is smaller than %s\n",str1,str2);
	else
		printf("%s is greater than %s\n",str1,str2);
}

int strcomp(char t[],char   s[])
{
	int i;
	for(i = 0; (t[i]==s[i]); i++)
		if(t[i] == '\0')
			return 0;
	return t[i] - s[i];
}
