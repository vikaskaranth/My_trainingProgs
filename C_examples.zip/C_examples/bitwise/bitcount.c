
/* binary counting example -counts bits set to 1 in an 8 bit number */

#include <stdio.h>

unsigned int bitcount(unsigned int); /* prototype */

main()

{ 
   unsigned char i8,count;
   unsigned int i;

   printf("Enter number ( decimal)\n");
   scanf("%u",&i);
   
   if (( i < 0 ) || (i > 0xFFFFFFFF))
     { printf("Error:Number out of range = %d\n", i);
       exit(1);
     }
   
   count = bitcount(i);
   
   printf("\n\nNumber of bits set to 1 in %d = %d\n",i,count);
   
}

unsigned int bitcount(unsigned int x)
{  
   unsigned int count;

   for (count = 0; x!=0; x>>=1)
     if ( x & 1 )
       ++count;
       
   return count;
}
