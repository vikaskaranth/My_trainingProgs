#include <stdio.h>
main()
{
	char iNum=104;
	char left;
	char z;
	left=iNum << 4 ;
	printf("%d\n",left);
         z = iNum >> 3;	
	printf("%d\n",z); 
}
