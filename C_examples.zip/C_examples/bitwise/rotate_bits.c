//Program to rotate the bits of an integer to left by n bit positions.

unsigned leftrot(unsigned x,int n)
{
    int lbit;
    while(n-- > 0)
    {
	lbit=(x&0x80000000)>>31;
	x=x<<1;
	x=x | lbit;
    }
    return x;
	
}
