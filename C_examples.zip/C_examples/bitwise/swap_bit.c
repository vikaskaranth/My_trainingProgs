//program to swap first and last bytes of a given integer.
// Debugged 

main( )
{
int x=0xfe0000ff,i;
//	printf("Enter any number:");
//	scanf("%d",&x);
	printf("Before swapping first and last bytes of an integer:");

	for(i=31;i>=0;i--)
	printf("%d",(x>>i)&1);
	//x=(x<<24)|(x & 0x00ffff00) | (x>>24);
	x=(x<<24) | (x>>24);
	x = (x&0xff0000ff);
	printf("\n");
	
	for(i=31;i>=0;i--)
	printf("%d",(x>>i)&1);
}
