#include<stdio.h>
main()
{
	char   num2 = 38, num1 = 70;
	char   z;

	z = num1 & num2;
	printf("%d\n",z);

}
