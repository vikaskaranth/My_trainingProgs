#include<stdio.h>
#include<math.h>
main()
{
	short x, y,i ,sum=0 ;
	short num, num1;
	x = y= 0xABC;
	for(i=0; i < 16;i++){
		printf("%d",1&x);
		   x >>=1;
	}
	for(i=4; i < 14;i++)
	    sum += pow(2,i);
	printf("\n%d\n",sum);
	num1=sum;

	for(i=0; i < 16;i++){
		printf("%d",1&sum);
		   sum >>=1;
	}
	num = y & num1;
	printf("\n%d\n",num);
}
