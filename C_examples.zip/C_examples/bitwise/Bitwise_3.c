//To keep first bit on

#include<stdio.h>

main()
{
      int num = 65;
      printf("Num is %d\n",num);
      num &=~64;
      printf("Num is %d\n",num);
 getchar();
      }
/*
main()
{
      unsigned char num = 1;
      printf("Num is %d\n",num);
      num &=~64;
      printf("Num is %d\n",num);

}
*/
