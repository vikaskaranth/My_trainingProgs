#include<stdio.h> 

main()
{
	unsigned char x=64;
	unsigned char y=~x;
	printf("%d\n",y);
}
