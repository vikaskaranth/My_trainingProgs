//program to get  'n' bits from pth position in a 32 bit integer.
#include<stdio.h> 

main()
{
	int i,p,n,x;
	printf("Enter any number:");
	scanf("%d",&x);
	
	for(i=8;i>=0;i--)
    	printf("%d",(x>>i)&1);
/*
    printf("\nEnter position and number bits to be displayed\n");
    scanf("%d%d",&p,&n);
    for(i=p;i>=n;i--)
    	printf("%d",(x>>i)&1);
    	
	fflush("stdin");
    getchar();
*/
}
