#include<stdio.h>
#include<stdlib.h>
main()
{
     char  a=12;
     char  b=34;
     printf("a = %d \n",a );
     printf("b = %d \n\n\n",b );
     a =a ^b;
     b =a ^b;
     a =a ^b;
     printf("a = %d \n",a );
     printf("b = %d \n",b );
}
