#include <stdio.h>
//Program to rotate the bits of an integer to right by n bit positions.

unsigned char rightrot(unsigned x,int n);
int main(int argc, char *argv[])
{
	char rotated;
	rotated = rightrot(atoi(argv[1]),atoi(argv[2]));
	printf("%d\n",rotated); 
	return 0;
}
unsigned char rightrot(unsigned x,int n)
{
    char rbit;
    while(n-- > 0)
    {
	rbit=(x&1)<<8;
	x=x>>1;
	x=x | rbit;
    }
    return x;
}
