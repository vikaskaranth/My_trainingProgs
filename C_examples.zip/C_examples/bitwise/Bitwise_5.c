//To make both numbers EQ using bitwise operator

#include<stdio.h>
main()
{
      int num = 7,  num2=64;
      printf("Num2 is %d\n",num2);
      num = num | num2;
      num &=num2;
      printf("Num2 is %d num is %d\n",num2);

      getchar();
      }
