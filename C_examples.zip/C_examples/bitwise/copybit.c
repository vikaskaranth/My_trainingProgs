#include<stdio.h> 
#include<stdlib.h>
#include<unistd.h>
main(int argc,char*argv[])
{
	unsigned int Snum=31,Tnum=24 ;
	int i;
	
//	scanf("%d",&Snum);
	
	printf("%u  ", (1 << Snum ));
	for(i =0 ; Snum; i++,Snum--)
	printf("%d  ",(Tnum & (1 << Snum )));
}
