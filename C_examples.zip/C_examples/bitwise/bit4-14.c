#include<stdio.h>
#include<string.h>
#include<math.h>
main(int argc, char  *argv[])
{
	int x ,i,j, num=0;
	char   str[10];
	int  y,sum=0 ;
	int  num1;

	for(i=0,j=0;argv[1][i]!='\0';i++)
		   if(argv[1][i]=='0'||argv[1][i]=='x')
				 continue;
		   else
				 str[j++]=argv[1][i];
	str[j]='\0';

	for(i=0,j=strlen(str)-1;j>=0;j--,i++){
		switch(str[j])
		{
			case '0': num += pow(16,i)* 0;
					break;
			case '1': num += pow(16,i)* 1;
					break;
			case '2': num += pow(16,i)* 2;
					break;
			case '3': num += pow(16,i)* 3;
					break;
			case '4': num += pow(16,i)* 4;
					break;
			case '5': num += pow(16,i)* 5;
					break;
			case '6': num += pow(16,i)* 6;
					break;
			case '7': num += pow(16,i)* 7;
					break;
			case '8': num += pow(16,i)* 8;
					break;
			case '9': num += pow(16,i)* 9;
					break;
			case 'a': 
			case 'A': num += pow(16,i)* 10;
					break;
			case 'b': 
			case 'B': num += pow(16,i)* 11;
					break;
			case 'c': 
			case 'C': num += pow(16,i)* 12;
					break;
			case 'd': 
			case 'D': num += pow(16,i)* 13;
					break;
			case 'e': 
			case 'E': num += pow(16,i)* 14;
					break;
			case 'f': 
			case 'F': num += pow(16,i)* 15;
					break;
		}
	}
	printf("Final string is %s\n",str);
	printf("Final num is %X\n",num);

	for(i=4; i < 14;i++)
	    sum += pow(2,i);
	num1=sum;

	y = num & num1;
	y >>= 4;
	printf("%X\n",y);
}
