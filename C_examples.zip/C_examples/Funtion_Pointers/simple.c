#include<stdio.h>

int addition_function(int x, int y){
		//printf("%d", (x+y));
		return ( x + y);
	}

int multiplication_function(int x, int y){
		//printf("%d",(x*y));
		return (x * y);
	}

int (*fun_pointer)(int , int);

main()
{
	fun_pointer  = addition_function;

	printf("The Addition Result is :%d\n",fun_pointer(10,5));

	fun_pointer  = multiplication_function;
	printf("The Multiplication result is : %d\n",fun_pointer(10,5));
}
