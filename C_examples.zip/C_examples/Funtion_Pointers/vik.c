#include<stdio.h>
int z;
main()
{
	int a,b;
	printf("%u\n%u\n%u\n",&a,&b,&z); 
}
