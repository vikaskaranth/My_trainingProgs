# include <stdio.h>
long fact(long int num)
{
	if(num==0)
		return 1;
	else
		return num * fact(num-1);
}
char fun(void)
{

}
main()
{
	long int n, f1;
	long int(*ptrfact)(long int);
	
	char (*fn[3])(void);

	ptrfact=fact;
	fn[0] = fun;


	printf("%u\n",fn);
	printf("%u\n",ptrfact);
	printf("After inc\n");
	ptrfact++;
	//fn++;
	printf("%u\n",fn);
	printf("%u\n",ptrfact);



	/*printf("Enter the number whose factorial has to be found\n");
	
	scanf("%ld",&n);
	
	f1=(*ptrfact)(n);
	
	printf("The factorial of %ld is %ld\n",n,f1);
	
	printf("The factorial of %ld is %ld\n",n+1,ptrfact(n+1));
*/
}
