#include<stdio.h>

int * func_mem_alloc(int);
void func_data_addition(int *, int);
void func_memory_display(int *, int);

main(){
	int *ptr, num_memory_loc;
	printf("Enter the Number of Memory Locations to be used :\n");
	scanf("%d",&num_memory_loc);
	ptr = func_mem_alloc(num_memory_loc);
	func_data_addition(ptr, num_memory_loc);
	func_memory_display(ptr, num_memory_loc);
}

int * func_mem_alloc(int num_memory_loc){
	return( (int *)malloc((num_memory_loc) * (sizeof(int))));
}

void func_data_addition(int * ptr, int num_memory_loc){
	int i;
	printf("%d", num_memory_loc);
	printf("Enter the Integer Values : \n");
	for( i = 0; i < num_memory_loc ; i++) {
		scanf("%d",ptr++);
	}
}

void func_memory_display(int *ptr, int num_memory_loc){
	int num_display = 0, i;
	printf("The values that reside at the User space are :\n");
	for(i = 0; i < num_memory_loc; i++){
		num_display = *ptr + *ptr++;} 
		printf("%d\n",num_display);
}		
	
	
