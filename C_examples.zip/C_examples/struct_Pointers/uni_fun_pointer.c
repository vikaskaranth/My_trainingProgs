#include<stdlib.h>
#include<string.h>
#include<stdio.h>

struct pointers{
	int (* int_fun_pointer)(int, int);
	float (* float_fun_pointer)(float, float);
	char str[100];
};

int int_function(int x , int y);
float float_function(float x , float y);

main()
{
	
	struct pointers   obj;	
	strcpy(obj.str,"Vikas karanth");
	obj.int_fun_pointer = int_function;
	
	printf("%d\n",obj.int_fun_pointer(10,20));

	obj.float_fun_pointer = float_function;
	printf("%f\n",obj.float_fun_pointer(10.0001,20.00001));
}

int int_function(int x , int y)
{
	return (x + y);
}
float float_function(float x , float y)
{
	return (x + y);
}
