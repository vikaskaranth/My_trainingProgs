#include<stdio.h> 

struct BIT_INFO {
    unsigned int b0     :1;  // bit 0 single bit
    unsigned int b1     :1;  // bit 1 single bit
    unsigned int b2_3   :2;  // bit 2 & 3
    unsigned int b4_7   :4;  // bit 4 through 7 ( 4 bits)
    unsigned int b8_9   :2;  // bit 8 & 9 ( 2 bits)
    unsigned int b10_15 :6;  // bit 10 through 15 ( 6 bits)
}; 

union HardwareRegisters {
    unsigned char   byte[2];
    unsigned short  word;
    struct BIT_INFO bits;
} ;

main()
{
      union HardwareRegisters   Obj;
      Obj.word = 0x0f0f;

       printf("%d\n",Obj.bits.b0);
       printf("%d\n",Obj.bits.b1);
       printf("%d\n",Obj.bits.b4_7);
       printf("%d\n",Obj.bits.b10_15);

}
