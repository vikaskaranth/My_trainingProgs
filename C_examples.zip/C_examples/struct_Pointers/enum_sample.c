#include<stdio.h> 

main()
{
     enum bool {
        false, 
        true
     } value ;

     value = false;
     if (value){
         printf("You are what you belive\n");
     }
     else if (value==false){
         printf("You are what you pretend\n");
     }
}
