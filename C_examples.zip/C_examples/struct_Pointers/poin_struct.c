#include<stdio.h>
#include<stdlib.h>

struct Date{	
	int    d;
	int    m;
	int    y;
};
main()
{
	struct Date	*p;
	p = (struct Date *) malloc(sizeof(struct Date));
	scanf("%d %d %d",&p->d,&p -> m,&p ->y);
	puts("\n\n");
	printf("%d %d %d",p ->d,p ->m,p ->y);
    
    fflush(stdin);
    getchar();
}
/*
main()
{
	struct Date	*p;
	p = (struct Date *) malloc(sizeof(struct Date));
	scanf("%d %d %d",&pd,&p  m,&p y);
	puts("\n\n");
	printf("%d %d %d",p d,p m,p y);
}
*/
