#include<stdio.h>
struct  mychoice_t{
    int is_float;

    union   {
       float f;
       char* s;
    };
} my;

main()
{
      my.is_float = 1;
      my.f = 15.565f;

}
