# include <stdio.h>
# include <string.h>

struct student		
{
	char name[30];	
	float marks;
}  student1, student2;	 
   
main ()
{
	//struct student student3;	
	printf("Enter student One's name\n"); 
	scanf("%s",student1.name);	
	printf("Eneter student One's marks\n");
	scanf("%f",&student1.marks );
	
	printf("Enter student Two's name\n"); 
	scanf("%s",student2.name);	
	printf("Eneter student Two's marks\n");
	scanf("%f",&student2.marks );
	
	printf("Student One's record\n"); 
	printf(" Name is %s \n", student1.name);
	printf(" Marks are %f \n", student1.marks);

	printf("Student Two's record\n"); 
	printf(" Name is %s \n", student2.name);
	printf(" Marks are %f \n", student2.marks);
getchar();
}
