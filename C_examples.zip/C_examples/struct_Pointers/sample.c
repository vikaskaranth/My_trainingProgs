#include<stdio.h>

struct sample
{
	int   i;
	double c2;
	float   f;
	double c4;
};
//typedef struct sample sam;

main()
{
	sam obj;
	printf("%d   \n",sizeof(obj)); 
};
