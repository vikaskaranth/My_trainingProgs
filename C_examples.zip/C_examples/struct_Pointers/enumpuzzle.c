#include <stdio.h>

main()
{
   enum
   {
      monday=1, tuesday=1, wednesday=-99, thursday,\
      friday, saturday, sunday
   } day;

   day = 1;

   if(day == saturday || day == sunday)
      printf( "Day is a weekend day" );
   else if(day == wednesday)
      printf( "Day is hump day - middle of the work week");

      printf("%d\n",day);


}

          
