# include<stdio.h>
# include<string.h>

struct address	
{
	int	rollnumber;
	char	street[30];
	char   city[30];
};

struct student	
{
	char	     name[30];
	float	   marks;
	struct address adr; 
};	

main ()
{
	int 	counter, count;
	struct student class[20];

	printf("Enter number of records you want to enter\n");
	scanf("%d",&count);

	for(counter = 0; counter < count; counter ++){
		printf("Enter students name\n");
		scanf("%s",class[counter].name);
		printf("Enter students marks\n");
		scanf("%f",&class[counter].marks);
		printf("Enter students rollnumber\n");
		scanf("%d",&class[counter].adr.rollnumber);
		printf("Enter students street name\n");
		scanf("%s",class[counter].adr.street);
		printf("Enter students city name\n");
		scanf("%s",class[counter].adr.city);
	}

	for(counter = 0; counter < count; counter ++){
		printf( "name is %s\n", class[counter].name);
		printf( "adr.plot is %d\n", class[counter].adr.rollnumber);
		printf( "Marks are %f\n", class[counter].marks);
		printf( "adr.street is %s\n", class[counter].adr.street);
		printf( "adr.city is %s\n", class[counter].adr.city);
	}
}
