# include <stdio.h>
struct student
{
	char name [30];
	float marks ;
};

struct student read_student(void);
void print_student (struct student);	
void read_student_p(struct student *);

main()
{
	system("clear");
	struct student student1;
	student1 = read_student();

	puts("First student's Record....................................");
	print_student( student1);

	read_student_p(&student1);
	puts("Another student's Record....................................");
	print_student (student1);
	fflush(stdin);getchar();
 }

struct student read_student()
{
	struct student student2;
	puts("Enter students name");
	gets(student2.name);
fflush(stdin);
	puts("Enter marks");
	scanf("%f",&student2.marks);
	return (student2);
}

void print_student (struct student student2)	
{
	printf( "name is %s\n", student2.name);
	printf( "mark is: %f\n", student2.marks);
}

void read_student_p(struct student *student2)
{
	puts("Enter students name");
fflush(stdin);
	gets(student2->name);
	puts("Enter marks");
	fflush(stdin);
	scanf("%f",&student2->marks);
}
