#include<stdio.h>
#include<stdlib.h>

struct sample
{
	int     *ip;
	float	*fq;
}*ptr;

main()
{
	int counter1, counter2,counter;
	const int iMax_instance=2;
	const int ip_max_count=5;
	const int fq_max_count=5;
	
	ptr = (struct sample *)malloc(iMax_instance*sizeof(struct sample));
	for(counter1 = 0; counter1 < iMax_instance; counter1++){	
		(ptr+counter1)->ip = (int *) malloc(sizeof(int) *5);
		(ptr+counter1)->fq = (float *) malloc(sizeof(float) *5);
	}
	for(counter1 = 0; counter1 < iMax_instance; counter1++){
		printf("Enter 5 ints : \n");
		for(counter2 = 0; counter2 < ip_max_count;counter2++){
		     scanf("%d",(ptr+counter1)->ip+counter2);
	    }
	
		printf("Enter 5 Floats: \n");
		for(counter2 = 0; counter2 < fq_max_count;counter2++)
			scanf("%f",(ptr+counter1)->fq+counter2);
		
	}
	printf("Ints are\n"); 
	for(counter1 = 0; counter1 < iMax_instance; counter1++){
		for(counter2 = 0; counter2 < ip_max_count;counter2++)
			printf("%d   ",*((ptr+counter1)->ip+counter2));
		printf("\n"); 
		}
	printf("Floats are: \n"); 
	for(counter1 = 0; counter1 < iMax_instance; counter1++){
		for(counter2 = 0; counter2 < fq_max_count;counter2++){
			printf("%f  ",*((ptr+counter1)->fq+counter2));
	    }
		printf("\n");
	} 
	for(counter = 0; counter < iMax_instance; counter++){	
		free((ptr+counter)->ip );
		free((ptr+counter)->fq );
	}
	free(ptr);
}	




