#include<stdio.h>
#include<stdlib.h>

struct sample
{
	int       *ip;
	float	*fq;
}*ptr;

main()
{
	int j,  i;
	ptr = (struct sample *)malloc(2*sizeof(struct sample));
	for(i = 0; i < 2; i++){	
		(ptr+i)->ip = (int *) malloc(sizeof(int) *5);
		(ptr+i)->fq = (float *) malloc(sizeof(float) *5);
	}
	for(i = 0; i < 2; i++){
		printf("Enter 5 ints : \n");
		for(j = 0; j < 5;j++)
			scanf("%d",(ptr+i)->ip+j);
		
	//	__fpurge(stdin);
		printf("Enter 5 Floats: \n");
		for(j = 0; j < 5;j++)
			scanf("%f",(ptr+i)->fq+j);
		
	}
	printf("Ints are\n"); 
	for(i = 0; i < 2; i++){
		for(j = 0; j < 5;j++)
			printf("%d   ",*((ptr+i)->ip+j));
		printf("\n"); 
		}
	printf("Floats are: \n"); 
	for(i = 0; i < 2; i++){
		for(j = 0; j < 5;j++)
			printf("%f     ",*((ptr+i)->fq+j));
		printf("\n");
	} 
	for(i = 0; i < 2; i++){	
		free((ptr+i)->ip );
		free((ptr+i)->fq );
	}
	free(ptr);
}	
