#include<stdio.h> 
#include<stdlib.h> 
struct Employee
{
    struct date
    {
        int d , m , y;
    }* ptr;
    char   name[25];
};
int main()
{
     struct Employee   Obj;
	
	Obj.ptr = malloc(sizeof(*(Obj.ptr)));

	scanf("%s",Obj.name);
	scanf("%d",&Obj.ptr->d);
	scanf("%d",&Obj.ptr->y);
	scanf("%d",&Obj.ptr->m);

	printf("%s\n",Obj.name);
	printf("%d\n",Obj.ptr->d);
	printf("%d\n",Obj.ptr->y);
	printf("%d\n",Obj.ptr->m);
	free(Obj.ptr);
     return 0;
}
