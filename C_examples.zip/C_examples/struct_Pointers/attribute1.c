# include<stdio.h>
# include<string.h>

struct test
{
	unsigned char  field1 ;
    	unsigned short field2 __attribute__((__packed__));
    	unsigned long  field3 __attribute__((__packed__));
} var1, var2;

main()
{
     printf("%d\n",sizeof var1);
}
