#include<stdio.h>
//#pragma pack(2)
#pragma unpack(1)
struct sample{
	int hr;
	char name;
};//__attribute__((packed));


main()
{
	struct sample simple;
/*	printf("Enter the Current hour : \n");
	scanf("%d",&simple.hr);
	printf("Enter the Current min : \n");
	scanf("%d",&simple.min);
	printf("Enter the name : \n");
	scanf("%s\n",simple.name);
*/
	printf("Size of Object : %d \n", sizeof(simple));
}
	
