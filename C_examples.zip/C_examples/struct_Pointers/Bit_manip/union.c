#include<stdio.h> 
struct byte{
    unsigned a:1-4;
    unsigned b:3;
    unsigned c:2;
    unsigned d:1;
    unsigned e:5;
};

main()
{
    struct byte   obj = 4;
    printf("size of byte is %d",sizeof obj);
    printf("%d\n",obj.a);
    printf("%d\n",obj.b);
    printf("%d\n",obj.c);
}
