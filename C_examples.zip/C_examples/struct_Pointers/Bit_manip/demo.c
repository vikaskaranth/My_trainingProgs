# include <stdio.h>


struct bit{
	unsigned  int a: 7;
	unsigned  int b: 5;
	unsigned  int  c: 6;
	unsigned  int  d: 8;
    int num;
  //  unsigned int Used:24 ;
};
main()
{
	struct bit Obj = { 1,0,25,45};
	printf("%u\n",Obj.a); 
	printf("%u\n",Obj.b); 
	printf("%u\n",Obj.c); 
	printf("%u\n",Obj.d); 

	printf("size od Obj is :%u\n",sizeof (Obj)); 
	getchar();
}
