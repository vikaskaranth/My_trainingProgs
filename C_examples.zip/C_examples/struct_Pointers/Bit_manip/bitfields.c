# include <stdio.h>
struct date
{
	   int d,m,y;
};

struct bit{
	unsigned age : 7;
	unsigned sex : 1;
	signed mstatus : 1;
     unsigned major_minor : 1;
	unsigned Indian : 1;
	signed DA : 4;
	signed HRA : 4;
	signed CCA : 5;
     unsigned unused :   8;
};
struct student
{
	struct date  DOB;
	struct bit Info;
	char    *name;
	int * marks;
};
main()
{
	struct bit obj={25,1,1,1,1};
	int da, hra,cca;
	printf("sizeof obj is %d\n",sizeof(obj));
	printf("Enter da hra cca\n"); 
	scanf("%d%d%d",&da,&hra,&cca);
     obj.DA = da;
     obj.CCA =cca;
     obj.HRA =hra;
	printf("%u\n",obj.age);
	printf("%u\n",obj.sex);
	printf("Natinality %u\n",obj.Indian);
	printf("da is :%u\t hra is : %u\t cca is :  %u\n",obj.DA,obj.HRA,obj.CCA);
}
