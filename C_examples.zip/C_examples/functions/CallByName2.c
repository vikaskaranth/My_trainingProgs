#include<stdio.h>

#define FUN(A,B) A<B
main()
{
	int x = 10; int y =20;
	char name[]="Ram";
	FUN(x,name);
//	printf("%d   %d",x,y); 
}
