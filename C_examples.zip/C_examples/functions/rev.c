#include<stdio.h>
void rev(int n)
{
	if(n ) {printf("%d   ",n); rev(--n);}
	else return;
}
main()
{
	int N=10;
	rev(N);
}
