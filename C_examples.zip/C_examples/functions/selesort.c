#include<stdio.h>

void selection(int [],int );

main()
{
	int n,a[10],i;

	printf("enter limit of an array");
	scanf("	%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);

	selection(a,n);
}

void selection (int ia[],int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if(ia[i]<ia[j])
			{
				temp=ia[i];
				ia[i]=ia[j];
				ia[j]=temp;
	 		}
	 for(i = 0;i < n;i ++)
		printf("\n%d",ia[i]);

}
