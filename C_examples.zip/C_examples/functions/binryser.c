#include<stdio.h>

#define EQ(a,b) (a<b)

int binary(int [],int,int);
main()
{
	int a[10], key,n,j,i,temp,flag;
	printf("enter a limited value for array");
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);

	for(i=0;i<n;i++)
		for(j=i;j<n;j++)
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
	for(i=0;i<n;i++)
		printf("\n%d",a[i]);
	printf("\nenter a item tobe searched\n");
	scanf("%d",&key);
	flag=binary(a,n,key);
	if(flag==-1)
		printf("%d is exist",key);
	else
		printf("%d is not exitst",key);
}

int binary(int a[10],int n,int key)
{
	int top,middle, bottom;
	top=n-1;
	bottom=0;
	while(top>bottom)
	{
		middle=(top+bottom)/2;
		if(EQ(a[middle],key))
			bottom=bottom+1;
		else
			top=middle;
	}
	if(top==-1)
		return -1;
	if(EQ(a[top],key))
		return top;
	else
		return -1;
}
