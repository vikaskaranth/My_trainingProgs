#include<stdio.h>
void fun(void);
void foo(void);
void bar(void);
void zoozoo(void);


main()
{
/*z = 1.0 / 3.0;
	if(z == 0.333333333)
		printf("Hai\n"); 
	else
		printf("Bye\n"); 
*/
 printf("Hai in main  %f\n",z); 
  fun();
  getchar();
}
float  z=5;
void fun(void)
{
     z++;
     printf("Hai in fun  %f\n",z); 
     foo();
 }
void foo(void)
{	
    z++;
    printf("Hai in foo  %f\n",z); 
     bar();
 }
void bar(void)
{	
    z++;
     printf("Hai in bar  %f\n",z); 
 }
void zoozoo(void)
{
 }
