#include<stdio.h>

#define FUN(A,B) A=100;B=200
main()
{
	int x = 10; int y =20;
	FUN(x,y);
	printf("%d   %d",x,y); 
}
