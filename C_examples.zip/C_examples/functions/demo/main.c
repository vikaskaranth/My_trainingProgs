#include<stdio.h>

int fnfoo(void);
static int iNum=100;

int main()
{
    fnfoo();
    fnfoo();
    fnfoo();
    fnfoo();
    fnfoo();
}

