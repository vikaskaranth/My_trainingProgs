 # include<stdio.h>
 struct sample
 {
 union point
  {
   int x[4];
   float y;
 }O;
 char name;
 //float  x;
};

 struct sample  Obj,*pp;
main()
{
printf("(%d, %d)\n",sizeof(Obj),sizeof(*pp));

 	getchar();

}
