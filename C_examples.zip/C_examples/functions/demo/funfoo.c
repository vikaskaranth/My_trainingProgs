#include<stdio.h>
extern    int   iNum;
int  fnfoo(void)
{
     printf("iNum is :%d\n",iNum++);
}
