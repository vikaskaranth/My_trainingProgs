# include <stdio.h>
void swap(int	*, int	*);	//function prototype

main()
{
	int	p,q;
	printf("Enter two integers\n");
	scanf("%d%d",&p,&q);
	printf("\np = %d,q = %d\n",p,q);	
	swap(&p,&q);	//function invocation by sending an address
	printf("\np = %d,q = %d\n",p,q);	
}

void swap(int   *x, int *y)	//function definition 
{
	int temp = *x;
	*x = *y;
	*y = temp;
}
