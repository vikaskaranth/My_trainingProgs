#include<stdio.h>
#define EQ(a,b) (a==b)

int search( int a[],int ,int );
main()
{
	int a[10],i,n,key,   flag = -1;
	printf("enter a limited value for");
	scanf("%d",&n);
	for(i=0;i<n;i++)

		scanf("%d",&a[i]);

	printf("enter a digit tobe searched");
	scanf("%d",&key);
	flag = search(a,n,key);
	if(flag == key)
		printf("%d is exist\n",key);
	else
		printf("doesnot exist\n");
}

int search(int a[10],int n,int key)
{
	int i;
	for(i=0;i<n;i++)
	
		if(EQ(a[i],key))
			return(a[i]);
	return -1;
}
