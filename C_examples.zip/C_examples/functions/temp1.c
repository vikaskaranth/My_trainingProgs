# include <stdio.h>
void swap(int	**);	//function prototype

main()
{
      int x = 5;
	int	*p;
	p = &x;
	//printf("Enter two integers\n");
	//scanf("%d%d",p,q);
	printf("\np = %d",*p);	
	swap(&p);	//function invocation by sending an address
	printf("\np = %d",*p);	
	getchar();
}

void swap(int   **x)	//function definition 
{
	int temp = 100;

	*x= &temp;
}
