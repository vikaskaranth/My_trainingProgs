# include <stdio.h>
void fnswapInt(int, int);	//function prototype

main()
{
	int   iNum1, iNum2;
	printf("Enter two integers\n");
	scanf("%d%d",&iNum1,&iNum2);
	
	printf("\np = %d,q = %d\n",iNum1,iNum2);	
	
	fnswapInt(iNum1,iNum2);	//function invocation

	printf("\np = %d,q = %d\n",iNum1,iNum2);	
system("pause");
}

void fnswapInt(int   x, int y)	//function definition
{
	int temp = x;
	x = y;
	y = temp;
}
