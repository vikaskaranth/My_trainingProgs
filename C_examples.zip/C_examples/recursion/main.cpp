#include<stdio.h>
main()
{

    int num=10;
	printf("The number is %d\n",--num);

    if(num > 1) 
           main();
           
           getchar();
}
