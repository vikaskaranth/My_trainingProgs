# include <stdio.h>
main(int argc,char   **argv)
{
	if(argc !=3){
		printf("You have to use two arguments\n");
		exit(-1);
	}
	printf("The arguments are\n");
	printf("The first argument is %s\n",argv[1]);
	printf("The first argument is %s\n",argv[2]);
}
