//A sample session with gdb command used are break , run, next,step ,print

# include <stdio.h>

int sum(int  num1, int   num2);

main()
{
	int num1, num2, total;
	printf("Enter the first number\n");
	scanf("%d",&num1);
	printf("Enter the second number\n");
	scanf("%d",&num2);
	total = sum(num1 , num2);
	printf("The sum is %d\n",total);
}

int sum(int  num1, int   num2)
{
	int   result;
	result = num1 + num2;
	return(result);
}
