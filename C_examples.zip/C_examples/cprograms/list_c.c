
/* list_c.c -  list C realted files ie .c .o .h files */

/* c89 list_c.c -o list_c */

#include <sys/types.h>
#include <sys/dir.h>
#include <sys/param.h>
#include<strings.h>
#include<unistd.h>
#include<stdlib.h>
#include <stdio.h>

#define FALSE 0
#define TRUE !FALSE

extern  int alphasort();
//extern char *rindex(const char *s, char c);

char pathname[MAXPATHLEN];

main()
{ int count,i;
  struct direct **files;
  int file_select();

(char *) getwd(pathname);
  printf("Current Working Directory = %s\n",pathname);

  count = 
    scandir(pathname, &files, file_select, alphasort);


  /* If no files found, make a non-selectable menu item */
  if (count <= 0) {
    printf("No files in this directory\n");
    exit(0);
  }

  printf("Number of files = %d\n",count);

  for (i=0;i<count;++i)
   { printf("%s ",files[i]->d_name);
     if ( (i % 4) == 0) printf("\n");
   }
   
  printf("\n"); /* flush buffer */
}


int
file_select(struct direct   *entry)
{
	char		*ptr;
	char		tmp[MAXPATHLEN];

      if ((strcmp(entry->d_name, ".") == 0) ||
	    (strcmp(entry->d_name, "..") == 0))
		return (FALSE); 

	/* Check for .c or .o or .h filename extensions */
	ptr = rindex(entry->d_name, '.');
	if ((ptr != NULL) &&
	    ((strcmp(ptr, ".c") == 0) || (strcmp(ptr, ".h") == 0) || (strcmp(ptr, ".o") == 0) )) 
		return (TRUE);

}
