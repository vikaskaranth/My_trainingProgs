# include <stdio.h>

#define VAL 35	
#define HELLO "HELLO"	
main()
{	
	int res;
	printf("%s\n",HELLO);
#define HELLO 123.4321	
	printf("%e",HELLO);

	res = VAL-5;	
	printf ("res = VAL-5: res == %d\n",res);
	
}
