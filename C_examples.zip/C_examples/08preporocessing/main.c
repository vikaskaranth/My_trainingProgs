#include<stdio.h>
main()
{
    int   x[3][5] = {{1,2,3,4,5},
    				{2,4,6,8,9},
				{23,34,45,54,56}
				};
	int *ptr[3];

	ptr = x;
printf("%p \n",(*(ptr + 2)+1));
}
