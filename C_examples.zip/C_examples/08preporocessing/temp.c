#define MAX(x,y)  x > y? x:y 
#include <stdio.h>
main ()
{
	int k = 4;
	int j = 24;
 	int z = MAX(k++,j++); 

	printf ("value of z is %d\n", z);	
}

