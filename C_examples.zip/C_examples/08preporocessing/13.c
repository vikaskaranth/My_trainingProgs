/*
 *	# and ## are two preprocessor operators used to string operations  *
 */
# include <stdio.h>

#define concat(a,b) a##b	
main()
{
	int xy = 10;
	printf("%d",concat(x,y));//This is expanded into printf("%d",xy);
}
