#include <stdio.h>
#include "file1.h"  

#if (defined (USD)) 
     #define currency_rate 46
#elif (defined (UKP))
     #define currency_rate 100	 
#else
     # define currency_rate 1	
#endif        				

 main()
{		
	int rs;
	rs = 10 * currency_rate;
	printf ("%d\n", rs);
}

