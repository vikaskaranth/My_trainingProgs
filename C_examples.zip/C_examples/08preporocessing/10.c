#define CUBE(x)  x*x*x 
#include <stdio.h>
main ()
{
	int k = 5;
	int j = 0;
	j = CUBE(k); // j = k*k*k

	printf ("value of j is %d\n", j);	
}

