#include<string.h>
#include<stdio.h> 

#define DUMBCOPY(x,y,size)  	for(i=0;i<size;i++)x[i]=y[i]
#define SMARTCOPY(x,y,size)   	memcpy(x,y,size)

main()
{
	int   i,   j;
/*
	char source[65536],destination[65536];
	strcpy(source,"Hello world");
	printf("DUMBCOPY\n");  // always faster 
	DUMBCOPY(destination,source,strlen(source)+1);
	printf("%s\n",destination);
	printf("SMARTCOPY\n");
	SMARTCOPY(destination,source,strlen(source)+1);
	printf("%s\n",destination);
*/
	
	int destination[65536],source[65536]={10,20,30,40,50,60,70,80};
	
/*
	printf("DUMBCOPY\n");  // always faster 
	DUMBCOPY(destination,source,8);
	for(j=0;j<8;j++) printf("%d\n",destination[j]);
	
*/
	printf("SMARTCOPY\n");
	SMARTCOPY(destination,source,8*sizeof(int));
	for(j=0;j<8;j++) printf("%d\n",destination[j]);
}
