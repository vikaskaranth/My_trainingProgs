#include<stdio.h> 
#if defined (unix) || defined (__unix__)
#define ad Add()
#elif vax
#define ad Mul()
#endif
int Add();
main()
{
	ad;
}
int Add()
{
	printf("In function\n");
}
