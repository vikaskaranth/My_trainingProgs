#include <stdio.h>
#include "file1.h"

#if !defined (USD) || defined (UKP)	 
# define currency_rate 1
#else
#error ERROR: NO_CURRENCY rate is specified.
#endif

 main()
{		
	int rs;
	rs = 10 * currency_rate;  		
	printf ("%d\n", rs);
}
