#include<stdio.h>

/* bubble sort */

main()
{
	int i,j,num[5],temp;
	printf("enter elements into the array\n");
	for(i=0;i<5;i++)
		scanf("%d",&num[i]);
	for(i=0;i<5;i++)
		for(j=0;j<(5-i)-1;j++)
		{
			if(num[j]>num[j+1])
			{
				temp=num[j];
				num[j]=num[j+1];
				num[j+1]=temp;
			}
		}
		for(i=0;i<5;i++)
			printf("%d\t",num[i]);
}
