/* PROGRAM TO reverse A GIVEN NUMBER */

#include<stdio.h>

main()
{
	int num,rev,r;
	char rep='y';

	do
	{
		system("clear");
		printf("ENTER ANY number:");
		scanf("%d",&num);

                printf("\n");
		printf("THE reverse OF THE NUMBER i.e '%d' IS: ",num);

		rev=0;

		while(num!=0)
		{
			r=(num % 10);
			num=(num / 10);
			rev=rev*10+r;
		}

		printf("%d\n",rev);

	printf("\n");
	printf("Do you wish to continue [y/n] or [Y/N]:");
	//__fpurge(stdin);
	fflush(stdin);
	scanf("%c",&rep);
	}
	while(rep=='y' || rep=='Y');

	printf("\n");
	printf("Press any key return back to the program...........");
}

