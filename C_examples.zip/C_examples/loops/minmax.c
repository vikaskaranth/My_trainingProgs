main()
{
	int   n, max,   min,   i, num;
	printf("Enter the limit\n");
	scanf("%d",&n);
	printf("Enter a number\n");
	scanf("%d",&num);
	max = min = num;	
	printf("Enter %d number\n",n - 1);
	for(i=1; i < n;i++){
		scanf("%d",&num);
		if(num > max)
			max = num;
		else if (num < min)
			min = num;
	}
	printf("max is %d\n min is %d\n",max, min);
}
		
