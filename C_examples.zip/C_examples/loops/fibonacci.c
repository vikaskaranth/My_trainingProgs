// a program to print fibonacci series
# include <stdio.h>
main()
{
	int firstnum=0,secondnum=1,resultnum=1,counter,num;
	printf("Enter any number :");
	scanf("%d",&num);
	for(counter=0;counter<num;counter++)
	{
	printf(" %d",resultnum);
	resultnum=firstnum+secondnum;
	firstnum=secondnum;
	secondnum=resultnum;


	}
fflush(stdin);getchar();	

}	
