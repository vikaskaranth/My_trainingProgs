#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

main()
{
	   int x = 5;
	   int *pVar;
	   pVar = &x;
	   printf("%p\n",pVar);
	   printf("%p\n",&pVar);
	   printf("%d\n",*pVar);
	   printf("%p\n",*(&pVar));
}
