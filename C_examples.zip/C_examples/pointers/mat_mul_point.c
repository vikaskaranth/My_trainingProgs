#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

main()
{
	int  *a[5],*b[5]  ,  *c[5],   i , j,   k;
	for(i = 0; i < 5;i++)
	{
		a[i] = (int *) malloc(sizeof(int)*5);
		b[i] = (int *) malloc(sizeof(int)*5);
		c[i] = (int *) malloc(sizeof(int)*5);
	}

	puts("Enter elements to mat1\n");
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
			scanf("%d",*(a+i)+j);

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(a+i)+j));
		puts("\n");
	}
	puts("Enter elements to mat2\n");
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
			scanf("%d",*(b+i)+j);

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(b+i)+j));
		puts("\n");
	}
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
		{
			*(*(c+i)+j) = 0;
			for(k = 0; k < 2;k++)
				*(*(c+i)+j) += *(*(a+i)+k) * *(*(b+k)+j);
		}

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(c+i)+j));
		puts("\n");
	}
}


/*

Pointer Cautions

When writing a program that uses pointers, avoid one serious error: using an uninitialized pointer on the left side of an assignment statement. For example, the following statement declares a pointer to type int:

int *ptr;

This pointer isn't yet initialized, so it doesn't point to anything. To be more exact, it doesn't point to anything known. An uninitialized pointer has some value; just don't know what it is. In many cases, it is zero. If using an uninitialized pointer in an assignment statement, this is what happens:

*ptr = 12;

The value 12 is assigned to whatever address ptr points to. That address can be almost anywhere in memory--where the operating system is stored or somewhere in the program's code. The 12 that is stored there might overwrite some important information, and the result can be anything from strange program errors to a full system crash.
The left side of an assignment statement is the most dangerous place to use an uninitialized pointer. Other errors, although less serious, can also result from using an uninitialized pointer anywhere in the program, so be sure the program's pointers are properly initialized before using them. The compiler won't do this.

Note:
•	DON'T try to perform mathematical operations such as division, multiplication, and modulus on pointers. Adding (incrementing) and subtracting (differencing) pointers are acceptable.
•	DON'T forget that subtracting from or adding to a pointer changes the pointer based on the size of the data type it points to. It doesn't change it by 1 or by the number being added (unless it's a pointer to a one-byte character).
•	DO understand the size of variable types on the computer. Knowing variable sizes is a must when working with pointers and memory.
•	DON'T try to increment or decrement an array variable. Assign a pointer to the beginning address of the array and increment it.

*/
