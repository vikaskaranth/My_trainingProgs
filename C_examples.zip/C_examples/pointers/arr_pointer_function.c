 /* Passing an array of pointers to a function. */

#include <stdio.h>

void print_strings(char *p[], int n);

int main()
{
    char *message[7] = { "Sunday","Monday", "Tuesday", "Wednesday","Thursday","Friday","Saturday" };
    int count;

    print_strings(message, 7);
    return(0);
}

void print_strings(char *p[], int n)
{
    int count;

    for (count = 0; count < n; count++)
        printf("%s ", p[count]);
    printf("\n");
}


