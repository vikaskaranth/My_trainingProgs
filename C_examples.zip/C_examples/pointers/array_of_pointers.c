/* Initializing an array of pointers to type char. */

#include <stdio.h>

int main()
{
    char *message[7] = { "Sunday","Monday", "Tuesday", "Wednesday","Thursday","Friday","Saturday" };
    int count;

    for (count = 0; count < 7; count++)
        printf("%s ", message[count]);
    printf("\n");
    return(0);
}