
#include<stdio.h> 
# include<unistd.h> 
#include<stdlib.h>

int main()
{
	int  *pa_mat[5];
    int   a[10],	b[5]  ,  c[15],   i , j;
	
	pa_mat[0]=a;
	pa_mat[1]=b;
	pa_mat[2]=c;
	
	puts("Enter elements to mat1\n");
	for(i = 0; i < 3;i++)
		for(j = 0; j < 3;j++)
			scanf("%d",*(pa_mat+i)+j);

	
	for(i = 0; i < 3;i++)
	{
		for(j = 0; j < 3;j++)
			printf("%d\t",*(*(pa_mat+i)+j));
		puts("\n");
	}
	return 0;
}
