/* Program using array of pointers and functions */

#include<stdio.h>
#include<stdlib.h>


void  _matrix_get_alloc(int **p,int rows,int cols);
void  _matrix_enter_elements(int **p,int rows,int cols);
void  _matrix_addition_result(int **p,int **q,int **r, int rows,int cols);
void  _matrix_display(int **r, int rows,int cols);


main()
{
	int *a[10], *b[10], *c[10];
	int i, j, rows, cols;

	printf("Enter the Number of rows : ");
	scanf("%d",&rows);
	printf("Enter the Number of Columns : ");
	scanf("%d", &cols);
	_matrix_get_alloc(a, rows, cols);
	_matrix_get_alloc(b, rows, cols);
	_matrix_get_alloc(c, rows, cols);
	_matrix_enter_elements(a, rows, cols);
	_matrix_enter_elements(b, rows, cols);
	_matrix_addition_result(a, b, c, rows, cols);
 	_matrix_display(c,  rows, cols);
}

void  _matrix_get_alloc(int **p, int rows, int cols){
		int i;
		//p = (int **)malloc(rows * sizeof(int *));
		for(i = 0; i < rows ; i++){
			*(p+i) = (int *)malloc(cols * sizeof(int));
		}
}
void  _matrix_delete(int **p){
	for(i = 0; i < rows ; i++)
		free(*(p+i));
}	
void	_matrix_enter_elements(int **p,int rows,int cols){
	int i ,j;
	printf("Enter the Elements for the matrix %c : \n", p);
	for(i = 0; i < rows; i++){
		for (j = 0; j < cols; j++){
			scanf("%d",(*(p+i)+j));
		}
	}
}

void  _matrix_addition_result(int **p,int **q,int **r, int rows,int cols){
		int i, j;
		printf("\n");
		for(i = 0; i < rows; i++)
			for(j = 0 ; j < cols; j++)
				r[i][j]  = p[i][j] + q[i][j];	
}
void  _matrix_display(int **r, int rows,int cols)
{
	int i, j;
	printf("\n");
	for(i = 0; i < rows; i++){
		for(j = 0 ; j < cols; j++)
			printf("%d\t", r[i][j]);
		printf("\n");
	}
}
