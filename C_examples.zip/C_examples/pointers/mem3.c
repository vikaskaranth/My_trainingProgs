#include<stdio.h>
#include<stdlib.h> 

int *nums;

main()
{
	int next, n=0;
	void print_nums(unsigned int );
	nums=(int *)malloc(sizeof(int));
	
	while(1)
	{
		printf("Enter %dth number\n",n+1);
		if(scanf("%d",nums+n)!=1)break;
		nums=(int *)realloc(nums,(++n+1)*sizeof *nums);
	}
	
	print_nums(n);
	exit(0);
}
void print_nums(unsigned int N)
{
	unsigned int i ; i=0;
	while(i<N)
	{
		printf("%dth Number is %d\n",i,*(nums+i));
		i++;
	}
}//closing function print_nums
