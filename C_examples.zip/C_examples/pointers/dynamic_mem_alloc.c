#include<stdio.h>
#include<stdlib.h>
#include<unistd.h> 

int func_data_addition(int *, int);
int func_memory_display(int *, int);
	
main(){
	int *ptr, num_memory_loc;

	printf("Enter the Number of Memory Locations to be used :\n");
	scanf("%d", &num_memory_loc);

	ptr = (int *)malloc((num_memory_loc) * (sizeof(int)));
	func_data_addition(ptr, num_memory_loc);
	func_memory_display(ptr, num_memory_loc);
	free(ptr);
}

int func_data_addition(int * p, int num_memory_loc){

	int i;

	printf("Enter the Integer Values : \n");
	for( i = 0; i < num_memory_loc ; i++) {
		scanf("%d",p++);
	}
}

int func_memory_display(int *p, int num_memory_loc){

	int num_display = 0, i;

	printf("The values that reside at the User space are :\n");

	for(i = 0; i < num_memory_loc; i++){
		num_display = *p + *p++;} 
		printf("%d\n",num_display);
}		
	
	
