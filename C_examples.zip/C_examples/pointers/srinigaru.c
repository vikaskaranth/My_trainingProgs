#include<stdio.h>
#include<stdlib.h> 

//main(int c , char *v[], char *envi[])
main(int c , char **v, char **envi)
{
	int result;
	if(c != 4)printf("Error in input\n");
	else{
		switch(v[2][0]){
			case '+':result =  atoi(v[1]) + atoi(v[3]);
						printf("result is %d\n",result); 
			  	  	  break;	
			case '*': result = atoi(v[1]) * atoi(v[3]);
						printf("result is %d\n",result); 
					  break;	
			case '/':result= atoi(v[1]) / atoi(v[3]);
						printf("result is %d\n",result); 
					  break;	
			case '-': result = atoi(v[1]) - atoi(v[3]);
						printf("result is %d\n",result); 
					  break;	
			default: printf("Invalid operator\n");
		}
	}	
	puts(envi[0]);
	puts(envi[1]);
	puts(envi[2]);
	puts(envi[3]);
	puts(envi[4]);
	puts(envi[5]);
	puts(envi[6]);
}
