#include<stdio.h>
#include<stdlib.h>

main()
{
	int **a, **b, **c;
	int i, j, rows, cols;


		printf("Enter the Number of Rows for the Matrices : \n");
		scanf("%d",&rows);
		a = (int **)malloc(rows * sizeof(int *));
		b = (int **)malloc(rows * sizeof(int *));
		c = (int **)malloc(rows * sizeof(int *));
		
		printf("Enter the Number of Columns for the Matrices : \n");
		scanf("%d",&cols);
		
		for(i = 0; i < rows ; i++){
			*(a+i) = (int *)malloc(cols * sizeof(int));
			*(b+i) = (int *)malloc(cols * sizeof(int));
			*(c+i) = (int *)malloc(cols * sizeof(int));
			}

		printf("Enter the Elements for the first matrix : \n");
		for(i = 0; i < rows; i++){
			for (j = 0; j < cols; j++){
			scanf("%d", (*(a+i)+j));
			}
		}
			
		printf("Enter the Elements for the Second matrix : \n");
		for(i = 0; i < rows ; i++){
			for(j = 0; j < cols ; j++){
			scanf("%d",(*(b+i)+j));
			}
		}
		
		printf("\n");
		for(i = 0; i < rows; i++){
			for(j = 0 ; j < cols; j++){
				c[i][j]  = a[i][j] + b[i][j];	
				printf("%d\t", c[i][j]);
			}	printf("\n");
		}
        for(i = 0; i < rows; i++){ 
		  free(a[i]);
            free(b[i]);
            free(c[i]);
        }
        free(a);
        free(b);
        free(c);
	}
