#include<stdio.h>
main()
{
	int  arr[4]={20,30,40,50};
	int  *ptr =arr;
	printf("%p     %d    \n",(ptr+0),*(ptr+0)); 
	printf("%p     %d    \n",(ptr+1),*(ptr+1)); 
	printf("%p     %d   \n ",(ptr+2),*(ptr+2)); 
	printf("%p     %d   \n ",(ptr+3),*(ptr+3)); 

	printf("%p     %d    \n",(arr+0),*(arr+0)); 
	printf("%p     %d    \n",(arr+1),*(arr+1)); 
	printf("%p     %d   \n ",(arr+2),*(arr+2)); 
	printf("%p     %d   \n ",(arr+3),*(arr+3)); 
}
