# include <stdio.h>
main()
{
	char	str1[15];
	char	str2[15];
	int  flag;
	printf("Enter a string\n");
	scanf("%s",str1);
	printf("strlen is%d\n",xstrlen(str1));// calling string lenth

	xstrcpy(str2,str1);
	printf("Copied string is :%s\n",str2);
	
	xstrcat(str1,str2);
	printf("Concatenated string is %s\n",str1);
	
	flag = xstrcmp(str1,str2);
	
	if(flag == 0)
		printf("Both strings are identical\n");
	else if(flag < 0)
		printf("%s is smaller than %s",str1,str2);
	else
		printf("%s is greater than %s",str1,str2);
}
	

int	xstrlen(char	*p)
{
	int	i;
	for(i = 0;*(p+i)!='\0';i++)
		;	//NULL statement
	return i;
}

char *	xstrcpy(char	*t,char	*s)
{
	char *temp=t;
	for(;(*t++ = *s++)!='\0';)
		;	//NULL statement
	return temp;
}

/*
  compare strings s1 & s2 and return
  a value > 0 if s1>s2, value == 0 if s1==s2, value < 0 if s1 < s2
*/
int xstrcmp( register char s1[], register char s2[] )
{
  register int i = 0;
  while ( (s1[i] != '\0') &&		// As long as s1 has not ended, and
  		(s2[i] != '\0') &&		// s2 has not ended, and
  		(s1[i] == s2[i]) )		// current character of s1 & s2 are the same
  {
	   i = i+1;				// check the next position in both
  }
  // I ended the scan because s1 has ended or s2 has ended or 
  // both have ended or the corr characters are not equal
  if ((s1[i]=='\0')&&(s2[i]=='\0')) // if both have ended, I return 0
	return 0;
  else if (s1[i] > s2[i])		// else, if the char of s1 is greater,
							// then i return 1
	return 1;
  else						// else, I return -1
	return -1
}

int	xstrcmp(char	*p,char	*q)
{
	for(;(*p++ == *q++);)
		if(*p == '\0')
			return 0;
	return *--p - *--q;
}
char * xstrcat(char    *p,char	*q)
{
	char *temp = p;
	for(;(*p++)!= '\0';)
		;
	--p;
	for(;(*p++ = *q++)!='\0';)
		;
	return temp;
}
