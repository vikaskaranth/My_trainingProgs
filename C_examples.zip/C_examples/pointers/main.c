#include<stdio.h>
#include<string.h>


main()
{
	char * ptr;

	int num = 0x1f2f0f0f;
	ptr = (char   *)&num;
	printf("%p    %d\n",(ptr+0),*(ptr+0));
	printf("%p    %d\n",ptr+1, ptr[1]);
	printf("%p    %d\n",ptr+2, ptr[2]);
	printf("%p    %d\n",ptr+3, ptr[3]);
}
