# include <stdio.h>
int main()
{
	int  	ix = 5;
	int 	*iPtr = NULL;
	iPtr = &ix;
	printf("ix=%d\n",ix);//ix=5 
	printf("iPtr=%p\n",iPtr); //iPtr=0x7ffe053c3154 
	printf("&ix=%p\n",&ix); //&ix=0x7ffe053c3154   
	printf("*iPtr=%p\n",iPtr); //*iPtr=0x7ffe053c3154    
	printf("&iPtr=%p\n",&iPtr); //&iPtr=0x7ffe053c3158        
	printf("It is address of x *&p=%p\n",*&iPtr); //It is address of x *&p=0x7ffe053c3154 
}


                                                                                                                    
                                                                                                     
                                                                                                    
                                                                                                 
                                                                                             
