#include<stdio.h> 
#include<stdlib.h> 
int main()
{
   int    z,    *p=NULL;
   p = (int *) malloc (4);
   *p = 100;
   z =*p * 10;
   printf("%d\n",z);
}
