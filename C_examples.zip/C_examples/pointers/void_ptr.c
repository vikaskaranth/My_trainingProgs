#include<stdio.h>
main()
{
	int   i=100;
	double f = 222.5340;
	void *vptr;
	printf("%lf\n",f); 
	vptr = &i;
	printf("int is %d\n",*(int *)vptr); 

	vptr = &f;
	printf("Float is %lf\n",*(double *)vptr); 
}
