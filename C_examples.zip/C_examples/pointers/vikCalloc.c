#include<unistd.h> 
#include<stdlib.h> 
#include<stdio.h>

typedef int ele_type;

main()
{
	int n,	i;
	ele_type	*p ;
	
	printf("enter limit of an array");
	scanf("%d",&n);

 	p=(ele_type  *) calloc(n,sizeof(ele_type));
	for(i=0;i<n;i++)
		scanf("%d",(p+i));

	 for(i = 0;i < n;i ++)
		printf("\n%d",*(p+i));
}
