#include<stdio.h>
#define MAXROW	5
#define MAXCOL 5

void fnReadMatrix( int iMatA[5][5],int irow, int icol);
void fnWriteMatrix(int iMatA[5][5],int  irow,int icol);

main()
{
     int    iNum[5][5];
	fnReadMatrix(iNum,2,2 );
     printf("Printging the matrix goes here..................\n");
	fnWriteMatrix(iNum,2,2);
}

void fnReadMatrix( int iMatA[5][5],int irow, int icol)
{
	int iCtr, iSecCtr;

	printf("Enter the matrix elements.................\n");

	for(iCtr = 0; iCtr < irow; iCtr ++)
	    for(iSecCtr = 0; iSecCtr < icol; iSecCtr ++)
    	        scanf(" %d" , &iMatA[iCtr] [iSecCtr] );

}

void fnWriteMatrix  (int iMatA[5][5],int  irow,int icol)
{
	int iCtr, iSecCtr;
     
	for(iCtr = 0; iCtr < irow; iCtr ++){
	    for(iSecCtr = 0; iSecCtr < icol; iSecCtr ++)
    	        printf(" %d\t " , iMatA[iCtr] [iSecCtr] );
	    printf("\n");
     }

}
