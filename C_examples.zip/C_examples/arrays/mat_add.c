#include<stdio.h>
/*
# define ROW
# define	COLUMN
*/
main() 
{
	int m1[5][5], m2[5][5], m3[5][5];
	int i, j, r, c;
	printf("Enter matrix size\n");
	scanf("%d%d", &r, &c);
	printf("enter the elements into matrix m1\n");
	for (i = 0; i < r; i++)
		for (j = 0; j < c; j++)
			scanf("%d", &m1[i][j]);
	printf("enter the elements into matrix m2\n");
	for (i = 0; i < r; i++)
		for (j = 0; j < c; j++)
			scanf("%d", &m2[i][j]);
	for (i = 0; i < r; i++)
		for (j = 0; j < c; j++)
			m3[i][j] = m1[i][j] + m2[i][j];
	printf("Resultant matrix is ............\n");
	for (i = 0; i < r; i++) {
		for (j = 0; j < c; j++)
			printf("%d   ", m3[i][j]);
		printf("\n");
	}
}


