main()
{
	int num1,num2,num3,max;
	printf("Enter any 3 numbers :");
	scanf("%d%d%d",&num1,&num2,&num3);
	if(num1>num2)
		if(num1>num3)
			max = num1;
		else
			max = num3;
	else if(num2> num3)
		max = num2;
	else
		max = num3;
	printf("The greatest of three numbers is %d\n",max);
}
