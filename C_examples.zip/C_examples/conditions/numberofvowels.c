//a program to find number of vowels 
main()
{
	char ch;
	int counter=0;
	printf("\n Enter any String ");
	while((ch=getchar()) !='\n')
	{
	switch(ch)
	{
	case 'a':
	case 'e':
	case 'i':
	case 'o':
	case 'u':
	case 'A':
	case 'E':
	case 'I':
	case 'O':
	case 'U':
	counter++;
	} 
	}
	printf("number of vowels %d",counter);
	
}

