#include<stdio.h> 
main()
{
	int num;
	scanf("%d",&num);
	switch(){
	 	case   1:  printf("One");
			break;
		 case 2:   printf("Two");
			break;
		 default:  printf("Greater thar One and two\n");
	}
}
/*
	if(num == 1) printf("One");
	else if(num == 2) printf("Two");
	else  printf("Greater thar One and two\n");
*/
