#include<iostream>

using namespace std;

class Stack{
    int *data;
    int sz;
    int itop;
   public:
    Stack(){
       data = NULL;
       sz=0;
       itop=0;
    }
    Stack(int size): itop(0), sz(size){
       data = new int[size];
    }
    Stack(Stack &stk){
       sz = stk.sz;
       itop = stk.itop;
       data = new int[sz];
       for(int i = 0; i <= itop; i++)
          data[i]=stk.data[i];
    }
    ~Stack(){
       delete []data;
       itop = 0;
       sz=0;
    }
    void push(int val){
        if(isStackFull())
           cout<<"Stack full"<<endl;
        else
           data[itop++ ]=val;
    }
    int pop(void){
       if(isStackEmpty())
          cout <<"Stack is empty"<<endl;
       else
          return(data[--itop]);
    }
    int top(){return itop;}
    int isStackEmpty(){
       if(itop == 0) return 1;
       else   return 0;
    }
    int isStackFull(){
        if(itop >=sz) return 1;
        else return 0;
    }
};



int main()
{
    Stack o(10);
    o.push(2);
    o.push(4);
    o.push(5);
    o.push(6);
    o.push(7);
    o.push(20);

    Stack obj(o);

    cout <<obj.pop()<<endl;
    cout <<obj.pop()<<endl;
    cout <<obj.pop()<<endl;
    cout <<"POPing from o"<<endl;
    cout <<o.pop()<<endl;
    cout <<o.pop()<<endl;
    cout <<o.pop()<<endl;
    cout <<o.pop()<<endl;
}
