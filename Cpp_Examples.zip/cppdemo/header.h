#ifndef __HEADER_H__
#define __HEADER_H__


#include<iostream>
#include<cstring>

using namespace std;
class Person
{
	char *name;
	char *address;
	char *phone;
      public:
	void init(void);
	void clear(void);
	void setname(char const *str);
	void setaddress(char const *str);
	void setphone(char const *str);
	char const *getname(void)	const;
	char const *getaddress(void)	const;
	char const *getphone(void)	const;
      void printperson(Person const &);
};
#endif
