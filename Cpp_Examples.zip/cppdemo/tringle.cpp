#include<iostream>
#include<cmath>
using namespace std;

class RTriangle{
     private:
         static int flag;
         float   base ;
         float   height;
         float   area;
         float   perimeter;
     public:
         void setBase(float   b){
              base =b;
          }
         void setHeight(float  h){
               height =h;
         }
         float getBase(void){
              return base;
          }
         float getHeight(void){
               return height;
         }
         float getArea(void){
             if(flag == 0) 
                 cout <<"Call fnArea first";
             else
                 return(area);
          }
         float getPerimeter(void){
               return (perimeter);
         }
         float  fnArea(void);
         float  fnPerimeter(void);
};
int RTriangle::flag=0;

float  RTriangle::fnArea(void){
     flag = 1;
     area = 0.5*base*height;
     return(area);
}
float  RTriangle::fnPerimeter(void){
     float  hypo;
     hypo = sqrt(base*base+height*height);
     perimeter = hypo+base+height;
     return perimeter;
}
int main()
{
      RTriangle  *Ptriangle=NULL;

      Ptriangle = new RTriangle();
      Ptriangle->setBase(213.21);
      Ptriangle->setHeight(21.21);

      //cout <<"Area is : "<<Ptriangle->fnArea()<<endl;
      //cout <<"Perimeter is : "<<Ptriangle->fnPerimeter()<<endl;

      cout <<"area"<<Ptriangle->getArea()<<endl;
      cout <<"perimeter is "<<Ptriangle->getPerimeter()<<endl;

      delete Ptriangle;

};
/*
#include"cons_Complex.h"

int main()
{
    cout <<"-----------CASE I-----------------"<<endl;
    Complex  obj;
    obj.Display(); 
    cout <<"---------------------------------"<<endl;
    cout <<"Real part is :"<<fixed<<obj.getReal();
    cout <<"Imaginary part is :"<<fixed<<obj.getImag();
  {
    cout <<"----------CASE II-----------------"<<endl;
    Complex  cObj = Complex(55.00);
    cObj.Display(); 
    cout <<"Real part is :"<<fixed<<cObj.getReal();
    cout <<"Imaginary part is :"<<fixed<<cObj.getImag();
  }
    {
    cout <<"----------CASE III ----------------\n";
    Complex  cObj2(55.0,5.00);
    cObj2.Display(); 
    cout <<"Real part is :"<<fixed<<cObj2.getReal();
    cout <<"Imaginary part is :"<<fixed<<cObj2.getImag();
   }
}
#include<iostream>
using namespace std;

class Complex{
   private:
        float   real;
        float   imag;
   public:
        Complex(void){
           real = imag = 0.0;
        }
        Complex(float r ,float i = 0.0){
           real = r;
           imag = i;
        }
        ~Complex(){ cout <<"Hi there.........\n";}
        void setReal(float   r){real = r;}
        void setImag(float   i){imag = i;}
        float getReal(void){return real ;}
        float getImag(void){return imag ;}
        void Display(void){
             cout <<"Real part is :"<<real  <<endl;
             cout << "Imaginary part is :"<<imag<<endl;
        }
};

#include<stdio.h> 
int main()
{
     int iNum=10;

     int *const iPtr;

}
#include<iostream>
#include<cmath>
using namespace std;

class RTriangle{
     private:
         float   base ;
         float   height;
         float   area;
         float   perimeter;
     public:
         static float  pi;
         RTriangle(){
             cout <<"Indefault constructor\n" ;
         }
         ~RTriangle(){cout<<"In destructor\n"; }
         RTriangle(float b, float h){
             base = b;
             height = h;
         }
         void setBase(float   b){
              base =b;
          }
         void setHeight(float  h){
               height =h;
         }
         float getBase(void){
              return base;
          }
         float getHeight(void){
               return height;
         }
         float getArea(void){
               return(area);
          }
         float getPerimeter(void){
               return (perimeter);
         }
         float  fnArea(void);
         float  fnPerimeter(void);
};

float   RTriangle::pi=3.14156f;

float  RTriangle::fnArea(void){
     area = 0.5*base*height;
     return(area);
}
float  RTriangle::fnPerimeter(void){
     float  hypo;
     hypo = sqrt(base*base+height*height);
     perimeter = hypo+base+height;
     return perimeter;
}
int main()
{
     
      RTriangle   *ptr=NULL;

      ptr = new  RTriangle(123.24,65.7213);

      cout <<"Area is : "<<ptr->fnArea()<<endl;
      cout <<"Perimeter is : "<<ptr->fnPerimeter()<<endl;
      
      cout <<"Pi is : "<<RTriangle::pi<<endl;
      delete  ptr;
}

#include<iostream>

using namespace std;

class Number{
    protected: 
        int value;
    public:
        Number(){}
        Number(int  val){
            value = val;
        }
        void Print(){
            ;
        }
};
class Hex:public Number  {
    public:
        Hex(){}
        Hex(int v) :Number(v){  }
        void Print(){
           cout <<"Value is : "<<hex<<value ;
        }
};
class Oct:public Number  {
    public:
        Oct() {  }
        Oct(int v) :Number(v){  }
        void Print(){
           cout <<"Value is : "<<oct<<value ;
        }
};
class Decimal:public Number  {
    public:
        Decimal(){}
        Decimal(int v) :Number(v){  }
        
        void Print(){
           cout <<"Value is : "<<dec<<value ;
        }
};
int main()
{
    Decimal odecimal(55);
    odecimal.Print();

    Oct  oct_obj(55);
    oct_obj.Print();

    Hex   hex_obj(55);
    hex_obj.Print();
}
#include<stdio.h> 
#include<stdlib.h>
#include"max.h"

void fnSwap(int  *a, int *b)
{// Swap a and b.
   int  temp = *a; *a = *b; *b = temp;
}
void * my_allocate(int size)
{
    void *temp_ptr;
    if((temp_ptr=malloc(size))==NULL)
        perror("malloc failed\n");
    else
       return temp_ptr;
}

void  selection_sort(int * iptr,int size);
int main()
{
     int    *iptr = NULL;
     int counter;
     
     iptr = my_allocate(-40);
     for(counter = 0;  counter < 5; counter++)
         scanf("%d",iptr+counter);

     selection_sort(iptr,5);

     for(counter = 0;  counter < 5; counter++)
         printf("%d-->",*(iptr+counter));
     printf("\n");

     free(iptr);
} 
void  selection_sort(int * iptr,int size)
{
    int j;
    for (; size > 1; size--) {
      j = Max(iptr, size);
      fnSwap(iptr+j, iptr+(size - 1));
      }
}
#include<stdio.h> 
#include<stdlib.h>
#include"max.h"

void fnSwap(int  *a, int *b)
{// Swap a and b.
   int  temp = *a; *a = *b; *b = temp;
}

void  selection_sort(int * iptr,int size);
int main()
{
     int    *iptr = NULL;
     int counter;
     
     iptr = malloc(40);
     for(counter = 0;  counter < 5; counter++)
         scanf("%d",iptr+counter);

     selection_sort(iptr,5);

     for(counter = 0;  counter < 5; counter++)
         printf("%d-->",*(iptr+counter));
     printf("\n");

     free(iptr);
} 
void  selection_sort(int * iptr,int size)
{
    int j;
    for (; size > 1; size--) {
      j = Max(iptr, size);
      fnSwap(iptr+j, iptr+(size - 1));
      }
}
*/
