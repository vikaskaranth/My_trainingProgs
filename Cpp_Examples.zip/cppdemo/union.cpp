#include <iostream>
#include <string>
typedef union structc_tag    {
    char  c;
    double d;
    int    s;
} structc_t;

int main()
{
    structc_t  obj;
    obj.c='A';
    obj.d=213213.123;
    std::cout << "obj.c  ->"<<obj.c<<std::endl;
    std::cout << "obj.d   ->"<<std::fixed<<obj.d<<std::endl;
    std::cout << "Hello, " << sizeof(obj)<< "!\n";
}

