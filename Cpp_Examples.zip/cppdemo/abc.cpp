#include<iostream>
using namespace std;

class sample {
    int const a;
   public:
	sample(int i): a(i){ }
	void print() const { cout<<a<<endl; }
};
int main( ) {
 	sample s(20);	

      s.print(); 
}

