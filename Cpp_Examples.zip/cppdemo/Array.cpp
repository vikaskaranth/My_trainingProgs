#include<iostream>
using namespace std;

class Array {
    int *data;
    int size;
    int capacity;
    public:
         Array(){
             data=nullptr;
             size=capacity=0;
         }
         Array(int sz){
             size=0;
             capacity=sz;
             data=new int[sz];
         }
         Array(Array & ref ){
             size=ref.size;
             capacity=ref.capacity;
             data=new int[capacity];
             for(int i = 0; i < size; i++)
                 data[i]=ref.data[i];
         }
         ~Array(){
             delete [] data;
             data=nullptr;
         }
         void addbeg(int val){
             data[0]=val;
             if(size == 0)
                 size++;
         }
         void append(int val){
             data[size]=val;
             size++;

         }
         void insert(int pos,int val){
             if(pos >= size){
                 pos=size;
                 size++;
             }
             data[pos]=val;
         }
         int Size(){ return size;}
         int deletebeg(){
             int  i, temp;
             temp=data[0];
             for( i=0; i < size;i++)
                 data[i]=data[i+1];
             --size;
             return temp;
         }
         int deleteend(){
             --size;
             return data[size];
         }
         int delete_pos(int pos){
             int  i, temp;
             temp=data[pos-1];
             for(i=pos-1; i < size;i++)
                data[i]=data[i+1];
             --size;
             return temp;

         }
         void Print(){
             int  i, temp;
             for(i=0; i < size;i++)
                cout <<data[i]<<endl;
         }
         int getVal(int pos){
             return(data[pos-1]);
         }
};


int main()
{
    Array   array(100);
    array.addbeg(10);
    array.append(20);
    array.insert(2,30);
    array.addbeg(100);
    array.append(200);
    array.insert(5,300);
    
    cout <<"Size of Array is"<<array.Size();
    cout <<"Data at "<<3<<array.getVal(3)<<endl; 

    array.Print();
    cout <<"*******************************\n";
    cout <<array.deletebeg()<<endl;
    cout <<array.deleteend()<<endl;
    cout <<array.delete_pos(2)<<endl;
    cout <<"*******************************\n";
    array.Print();
    cout <<"Size of Array is"<<array.Size()<<endl;


    Array sec_obj(array);

    sec_obj.addbeg(10);
    sec_obj.append(20);
    sec_obj.insert(2,30);
    sec_obj.addbeg(100);
    sec_obj.append(200);
    sec_obj.Print();
    cout <<"Size of Array is"<<sec_obj.Size();
}
