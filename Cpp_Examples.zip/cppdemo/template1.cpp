#include<iostream>
template<class T>
class Array{
     T *iPtr;
     int size;
     public:
      Array(int sz){
          if(sz > 0){
             size=sz;
             iPtr = new T [size];
          }
      }  
};

template<template X class T>
class Stack
{
     X<> O;




}

int main()
{
    Array<float>   fo(5);
    Array<>   o(5);


}
