#include"String.h"
#include"cstring"
using namespace std;

myString::myString(void){
     nstring = NULL;
     nlength=0;
}//default sets string to NULL
myString::myString(const char* input)//Takes in a string and creates an object
{
     nlength = strlen(input);
     nstring=new char[nlength];
     strcpy(nstring,input);
}
myString::	myString(const myString & S)//Copy constructor
{
     nlength = strlen(S.nstring);
     nstring=new char[nlength];
     strcpy(nstring,S.nstring);
}
myString::~myString(void)//Destructor deletes the nstring at the end
{
    delete []nstring;
}
int myString:: length()//displays length of string excluding null
{
     return(strlen(nstring));
}
char & myString:: at(int loc)//returns a chracter at specified loc-1
{
     if(loc >= 0 && loc <= length())
         return(nstring[loc]);
}
bool myString:: empty()// if string is empty returns true else it returns false
{
    if(nstring==NULL)  return 1;
    else               return 0;
}
void myString::  swap(myString& from)// swaps the contents of two strings
{
    myString  temp;
    temp = from;
    strcpy(from.nstring,  nstring);
    strcpy(nstring , temp.nstring);
}	
ostream& operator << (ostream & OS,const myString &S)// out stream displays the string
{
    OS << S.nstring;
    return OS;
}
myString & myString::  operator = (const myString& S)//if A and B are object B is "neil", the A =B therefore A is "neil"
{
    if(this != &S){
       if(nstring != NULL)      
           delete []nstring;
       nlength = S.nlength;
       nstring  = new char[nlength];
       strcpy(nstring,S.nstring);
    }
    return *this;
}
bool operator ==(const myString& S1, const myString & S2)// checks if both strings are equal
{
     if(strcmp(S1.nstring,S2.nstring)==0)
         return 1;
     else
         return 0;
}
myString operator + (const myString& S1, const myString & S2)
{
     myString temp;

     temp.nlength = S1.nlength+S2.nlength;
     if(temp.nstring != NULL)      
           delete []temp.nstring;
     temp.nstring  = new char[temp.nlength];
     strcpy(temp.nstring,S1.nstring);
     strcat(temp.nstring,S2.nstring);
     return temp;
}	
