#include<iostream>
using namespace std;

class iAdd{
    public: virtual int add()=0;
    virtual ~iAdd(){}
};
class iMul{
    public: virtual int mul()=0;
    virtual ~iMul(){}
};
class iSub{
    public: virtual int sub()=0;
    virtual ~iSub(){}
};
class iDiv{
    public: virtual int div()=0;
    virtual ~iDiv(){}
};

class IntNumber:public iAdd,iMul,iSub,iDiv{
    int inum1, inum2;
    public: 
    IntNumber(){}
    IntNumber(int n1, int n2){inum1=n1;inum2=n2;}
    virtual int add(){return inum1 + inum2;}
    virtual int mul(){return inum1 * inum2;}
    virtual int sub(){return inum1 - inum2;}
    virtual int div(){return inum1 / inum2;}
};
class FloatNumber:public iAdd,iMul,iSub,iDiv{
    float fnum1, fnum2;
    public: 
    FloatNumber(){}
    FloatNumber(float n1, float n2){fnum1=n1;fnum2=n2;}
    virtual int add(){return fnum1 + fnum2;}
    virtual int mul(){return fnum1 * fnum2;}
    virtual int sub(){return fnum1 - fnum2;}
    virtual int div(){return fnum1 / fnum2;}
};
int main()
{
    IntNumber   int_o(213,2334);
    FloatNumber float_o(676.75,821.368);

    cout <<int_o.add()<<endl;
    cout <<int_o.mul()<<endl;
    cout <<float_o.add()<<endl;
    cout <<float_o.mul()<<endl;
    return 0;
} 
