#include<iostream>
using namespace std;

class temp{
protected:
    float  val;
    char  symbol;
    float cel, far, kel;
    public:
       temp(){}
       virtual ~temp(){cout <<"temp"<<endl;}
       temp(float v, char s){
           val = v;
           symbol = s;
       }
       virtual void makeHot() = 0;
       virtual void makeCold() = 0;
       virtual void freeze() = 0;
       virtual void boil() = 0;
       virtual float display() = 0;
};

class celcius:public virtual temp{
     float cel;
     public:
       celcius(){}
       ~celcius(){cout <<"celcius"<<endl;}
       celcius(float v, char s):temp(v, s){
           if(s == 'F')
           {
               cel = (v - 32) * 5/9;
           }
           else if(s == 'K')
           {
               cel = v - 273.15;
           }
           else
           {
               cel = v;
           }
       }
       
       void makeHot(){cel += 5;}
       void makeCold(){cel -= 5;}
       void freeze(){cel = 0;}
       void boil(){cel = 100;}
       float display(){
          return cel;
       }
};

class Fahrenheit:public virtual temp{
     float far;
     public:
       Fahrenheit(){}
       ~Fahrenheit(){cout <<"Fahrenheit"<<endl;}
       Fahrenheit(float v, char s):temp(v, s){
           if(s == 'C')
           {
               far = (v * 9/5) + 32;
           }
           else if(s == 'K')
           {
               far = (v - 273.15) * 9/5 + 32;
           }
           else
           {
               far = v;
           }
       }
       
       void makeHot(){far += 5;}
       void makeCold(){far -= 5;}
       void freeze(){far = 32;}
       void boil(){far = 212;}
       float display(){
          return far;
       }
};

class Kelvin:public virtual temp{
     float kel;
     public:
       Kelvin(){}
       ~Kelvin(){cout <<"Kelvin"<<endl;}
       Kelvin(float v, char s):temp(v, s){
           if(s == 'C')
           {
               kel = v + 273.15;
           }
           else if(s == 'F')
           {
               kel = (v - 32) * 5/9 + 273.15;
           }
           else
           {
               kel = v;
           }
       }
       
       void makeHot(){kel += 5;}
       void makeCold(){kel -= 5;}
       void freeze(){kel = 32;}
       void boil(){kel = 373.15;}
       float display(){
          return kel;
       }
};

int main()
{
    temp *ptrTemp = new celcius(2,'F');
    cout<<ptrTemp->display()<<endl;
    ptrTemp->makeHot();
    cout<<ptrTemp->display()<<endl;
    ptrTemp->makeCold();
    cout<<ptrTemp->display()<<endl;
    ptrTemp->freeze();
    cout<<ptrTemp->display()<<endl;
    ptrTemp->boil();
    cout<<ptrTemp->display()<<endl;
    
    temp *ptrTemp1 = new Fahrenheit(56,'K');
    cout<<ptrTemp1->display()<<endl;
    ptrTemp1->makeHot();
    cout<<ptrTemp1->display()<<endl;
    ptrTemp1->makeCold();
    cout<<ptrTemp1->display()<<endl;
    ptrTemp1->freeze();
    cout<<ptrTemp1->display()<<endl;
    ptrTemp1->boil();
    cout<<ptrTemp1->display()<<endl;
    
    temp *ptrTemp2 = new Kelvin(22,'C');
    cout<<ptrTemp2->display()<<endl;
    ptrTemp2->makeHot();
    cout<<ptrTemp2->display()<<endl;
    ptrTemp2->makeCold();
    cout<<ptrTemp2->display()<<endl;
    ptrTemp2->freeze();
    cout<<ptrTemp2->display()<<endl;
    ptrTemp2->boil();
    cout<<ptrTemp2->display()<<endl;
    
}

