#include<stdio.h> 
int main()
{
    int   *ptr=NULL;
    int  array[5]={23,234,2,213,54};

    ptr=array;

    printf("%d\n",ptr[0]);
    printf("%d\n",*(ptr+0));
}
