#include<stdio.h> 

int main()
{
   /*
     char  names[5][25];
     int i;

     for(i=0; i< 5; i++){
         printf("Enter %dth name\n",i);
         scanf("%s",names[i]);
     }
     for(i=0; i< 5; i++){
         printf("%dth name is :%s\n",i,names[i]);
     }*/

     int nums[3][5];
     int i,j;

     
     for(i=0; i< 3; i++){
         for(j=0; j< 5; j++){
             printf("Enter %dth number\n",i);
             scanf("%d",&nums[i][j]);
         }
     }
     for(i=0; i< 3; i++){
         for(j=0; j< 5; j++){
             printf("%dth number in %dth array is  :%d\n",j,i,nums[i][j]);
         }
     }
}
