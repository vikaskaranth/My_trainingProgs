#include<iostream>
using namespace std;

class Degree{
    float  degree;
    public:
        Degree(){}    
        ~Degree(){}    
        Degree(float   d){
            degree = d;
        }    
        Degree operator +(Degree  d){
            Degree  temp;
            temp.degree = this->degree + d.degree;
            return temp;
        }
        Degree operator -(Degree  d){
            Degree  temp;
            temp.degree = this->degree - d.degree;
            return temp;
        }
        Degree operator *(Degree  d){
            Degree  temp;
            temp.degree = this->degree * d.degree;
            return temp;

        }
        Degree operator /(Degree  d){
            Degree  temp;
            temp.degree = this->degree / d.degree;
            return temp;
        }
        void fndisplay(){
            cout <<"Degree is : "<< degree<<endl;
        }
};


int main()
{
    Degree d1(30.0),   d2(60.0),   d3;
    Degree d4(45.0), d5(90.0);
    d3 = d1 + d2 * d5 / d4; // d1.operator+(d2);
    d3.fndisplay();

   /* d3 = d1 - d2; // d1.operator-(d2);
    d3.fndisplay();
    d3 = d1 * d2; // d1.operator*(d2);
    d3.fndisplay();
    d3 = d1 / d2; // d1.operator/(d2);
    d3.fndisplay();
*/
}
