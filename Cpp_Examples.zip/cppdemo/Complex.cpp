#include<iostream>
using namespace std;

class Complex{
   private:
        float   real;
        float   imag;
   public:
        void setReal(const float   real){
             this->real = real;
        }
        void setImag(const float   imag)
        {this->imag = imag;}
 
        float getReal(void)const
        {return real ;}
 
       float getImag(void)const
        {return imag ;}

        void Display(void)const {
             cout <<"Real part is :"<<real  <<endl;
             cout << "Imaginary part is :"<<imag<<endl;
        }
};
int main()
{
    Complex  obj;
    obj.setImag(5.0);
    obj.setReal(10.0);
    cout <<"---------------------------------"<<endl;
    obj.Display(); 
    cout <<"---------------------------------"<<endl;
    cout <<"Real part is :"<<fixed<<obj.getReal();
    cout <<"Imaginary part is :"<<fixed<<obj.getImag();

}
