class Book{
    public:
    class chapter {
        char   chap_name[25];
        int number;
        int pages;
        public:
           chapter(){}
           chapter(char *ch,int  n,int  p){
               strcpy(chap_name,ch);
               number=n;
               pages=p;
           }           
           void display(){
               cout << chap_name<<endl;
               cout <<number <endl;
               cout << pages<<endl;
           }
    };
    Book(char *bn,int amt,char  *name,int n,int p){
           strcpy(name,bn);  
           price=amt;
        }
        void display(){
           cout << name<<endl;
           cout <<price<endl;
           cout << "******chapter info ****" <<endl;

           cout << pages<<endl;
        }
    private:
        chapter   sub(name,n,p);
        char   name[25];
        int price ;
};

/*

include <iostream>

class Task 
{ 
public:
    class Error 
    {
    public :
        int code;
    };

    bool DoTask()
    {
        //...some task code that failed
        lastError.code = 666;
        return false;
    }

    Error getLastError(){return lastError;};
   
private:
    Error lastError;
};

//-----------------------------------------------------------------------------
int main()  
try
{
    using std::cout;
    using std::endl;

    Task aTask;

    if(!aTask.DoTask())
    {
        Task::Error e = aTask.getLastError();
        cout << e.code << endl;
    }
    
    return 0;
}
catch(...)
{
    std::cout << "Somthing whent wrong...big time." << std::endl;
    return 999;
}
*/
