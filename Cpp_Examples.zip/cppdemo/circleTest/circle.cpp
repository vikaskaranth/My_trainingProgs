#include"circle.h"

int main()
{
    Circle  c1(10.0);
    //c1.set_radius(25.5);
    c1.fn_area();
    c1.fn_circumference();
    c1.fn_diameter();
 
    cout<<"radius is "<<c1.get_radius()<<endl;
    cout<<"diameter is "<<c1.get_diameter()<<endl;
    cout<<"Area is "<<c1.get_area()<<endl;
    cout<<"Circumference is "<<c1.get_circumference()<<endl;  
 }

