#include"circle.h"
#include "gtest/gtest.h"

// In this example, we test the Circle class .

// Tests the default c'tor.
TEST( Circle, DefaultConstructor) {
  Circle s;

  EXPECT_EQ(0, s.get_radius());
  EXPECT_EQ(0, s.get_diameter());
  EXPECT_EQ(0, s.get_area());
  EXPECT_EQ(0, s.get_circumference());
}


// Tests the c'tor that accepts a float radius.
TEST(Circle, ConstructorFromRadius) {
  Circle c1(10.0);
  Circle c2(-10.0);
  Circle c3(0.0);

  EXPECT_EQ(10,c1.get_radius());
  EXPECT_EQ(0, c1.get_diameter());
  EXPECT_EQ(0, c1.get_area());
  EXPECT_EQ(0, c1.get_circumference());

  EXPECT_EQ(0, c2.get_radius());
  EXPECT_EQ(0, c2.get_diameter());
  EXPECT_EQ(0, c2.get_area());
  EXPECT_EQ(0, c2.get_circumference());

  EXPECT_EQ(0, c3.get_radius());
  EXPECT_EQ(0, c3.get_diameter());
  EXPECT_EQ(0, c3.get_area());
  EXPECT_EQ(0, c3.get_circumference());
}
// Tests the Seter method.
TEST(Circle, Set) {
  Circle c1;
  Circle c2;
  Circle c3;

  c1.set_radius(10.0f);
  c2.set_radius(-10.0f);
  c3.set_radius(0.0f);
  EXPECT_EQ(10,c1.get_radius());
  EXPECT_EQ(0, c1.get_diameter());
  EXPECT_EQ(0, c1.get_area());
  EXPECT_EQ(0, c1.get_circumference());

  EXPECT_EQ(0, c2.get_radius());
  EXPECT_EQ(0, c2.get_diameter());
  EXPECT_EQ(0, c2.get_area());
  EXPECT_EQ(0, c2.get_circumference());

  EXPECT_EQ(0, c3.get_radius());
  EXPECT_EQ(0, c3.get_diameter());
  EXPECT_EQ(0, c3.get_area());
  EXPECT_EQ(0, c3.get_circumference());
}
//Tests find Area function
TEST(Circle,findArea){
  Circle c1(10.0);
  c1.fn_area();

  EXPECT_FLOAT_EQ(314.156, c1.get_area());
  EXPECT_NEAR(314.15, c1.get_area(),0.009);
}

//TESTs findCirCumference function
TEST(Circle,findCirCumference){
  Circle c1(10.0);
  c1.fn_circumference();

  EXPECT_FLOAT_EQ(62.8312, c1.get_circumference());
  EXPECT_NEAR(62.83, c1.get_circumference(),0.099);
}

//TESTs findDiameter function
TEST(Circle,findDiameter){
  Circle c1(10.0);
  c1.fn_diameter();

  EXPECT_FLOAT_EQ(20.0, c1.get_diameter());
  EXPECT_NEAR(20.0, c1.get_diameter(),0.9);
}


int main(int argc, char **argv) {
    ::testing::InitGoogleTest( &argc, argv );
    return RUN_ALL_TESTS();
}
