#include<iostream>
using namespace std;
const float  pi=3.14156f;

class Circle{
    private:
       float radius, circumference;
       float area, diameter;
     public:
        Circle(){
            radius= circumference=0;
            area=diameter=0;
        }
        Circle(float   r){
            if(r>0.0f)
                radius=r;
            else{
                radius=0.0f;
            }
            circumference=0.0f;
            area=diameter=0.0f;
        }
        void set_radius(float  r){
           radius=r;
        }
        void fn_area(void){
          area = pi * radius * radius;
        }
        void fn_circumference(void){
           circumference = 2 * pi *radius;
        }
        void fn_diameter(void){
           diameter = 2*radius;
        }
        
        float get_radius(){
           return radius;
        }
        float get_diameter(){
          return diameter;
        }
        float get_area(){
           return area;
        }
       float get_circumference(){
           return circumference;
       }
};

