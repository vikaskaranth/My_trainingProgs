#include<iostream>
const float PI=3.141592654;
using namespace std;
class Degree {
        friend class Radian;
	float degree;
     public:
	Degree(float  d = 0.0){ degree=d;}

	float Getdegree(){ return(degree); }
	void output(){  cout<<"Degree="<<degree<<endl;}
};

class Radian {
	float rad;
     public:
	Radian() { rad=0;}

	Radian (float initrad)//constructor 1
	{ rad=initrad; }

	float GetRadian() { return (rad); }
	void Input() {
    		cout<<"Enter radian:";
      		cin>>rad;
	}
	void output(){ cout<<"Radian="<<GetRadian(); }
        void Display(Degree *ref){
            cout <<"Degree is :"<<ref->degree<<endl;
        }
};
int  main(void)
{
       Degree deg1(55.0);
       Radian rad2(99.00);

       rad2.Display(&deg1);

}

