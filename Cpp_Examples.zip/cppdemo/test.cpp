#include<iostream>
using namespace std;
int main()
{
    int ival=10;

    int &ref = ival;
    int y=999;
    ref = y;
    std::cout <<"ival : "<<ival;
}

/*
void swap ( int &a, int &b ) 
{ 
	int nTemp = a;
	a = b;
	b = nTemp;
 } 

int main()
{
    int x = 5, y = 10;
    swap(x,y);
    cout << x << " "<<y<<endl;
}
*/
