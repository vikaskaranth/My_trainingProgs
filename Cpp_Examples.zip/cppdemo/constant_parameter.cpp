#include"header.h"
int num;
void Person :: init()
{
      name=address=phone=0;
}
void Person :: clear()
{
      delete name;
      delete address;
      delete phone;
}
void Person :: setname(char const *str)
{
	if(name)
		delete name;
	name=new char[strlen(str)+1];
	strcpy(name,str);
}
void Person :: setaddress(char const *str)
{
      if(address)
	delete address;
	address=new char[strlen(str)+1];
	strcpy(address,str);
}
void Person :: setphone(char const *str)
{
      if(phone)
	delete phone;
	phone=new char[strlen(str)+1];
	strcpy(phone,str);
}

char const *Person :: getname() const
{
	   num = 10;
       return name;
}
char const *Person :: getaddress() const
{
       return address;
}
char const *Person :: getphone() const
{
       return phone;
}
void Person::printperson(Person const &p)
{
       if(p.getname())
		cout<<"name="<<p.getname()<<endl;
       if(p.getaddress())
		cout<<"address"<<p.getaddress()<<endl;
       if(p.getname())
		cout<<"phone="<<p.getphone()<<endl;
}
