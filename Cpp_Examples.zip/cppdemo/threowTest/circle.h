#include<iostream>
#include<cstdlib>
using namespace std;

const float  pi=3.14156;

class Circle{
    private:
       float radius, circumference;
       float area, diameter;
    public:
       Circle(float  r=0){radius  = r;}

       void set_radius(float  r){
          try{
              if(r >0)
                  radius = r;
              else
                  throw r;
          }
          catch(float   e){
              cerr<<"improper radius"<<endl;
          }
       }
       void fn_area(void){
          try{
              if(radius >0)
                  area = pi * radius * radius;
              else
                  throw radius;
          }
          catch(float   e){
              cerr<<"area:improper radius"<<endl;
          }
       }  
       void fn_circumference(void){
          circumference = 2 * pi *radius;
       }
       void fn_diameter(void){
          diameter = 2*radius;
       }
       float get_radius(){
          return radius;
       }
       float get_diameter(){
          return diameter;
       }
       float get_area(){
          return area;
       }
       float get_circumference(){
          return circumference;
       }
};

