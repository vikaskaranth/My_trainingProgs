
/****************************************************************
*	File name:  staticmethod.cpp					*
*	Version No: 1.3						*
*     	Description : program to illustrate private static data *
*	members     					        *
****************************************************************/
#include<iostream>
using namespace std;

class Myclass
{
      static   int count;	//Declaring the static member
   	int number;
   public:
      Myclass(){
        number = ++count;
      }
	void fun(void)
	{ 
	  cout <<"Address of the object is" <<hex<<this;
	  cout <<endl;
	}
 	static    void set(int num)  {
     	     count=num;
      }
      void show()    {
    	   cout<<"Number of calls made to 'set()' through any object:"\
	     <<count<<endl<<"Ticket number is :"<<number<<endl;
     }
};

//Defination of the static member

int Myclass :: count;

main()
{
	Myclass::set(1000);
	Myclass obj1;
	obj1.show();

	Myclass obj2,obj3;
	cout <<"obj3 is calling\n";obj3.fun();
	cout <<"obj1 is calling\n";obj1.fun();
	cout <<dec;
	obj1.show();
	obj2.show();
	obj3.show();
}

