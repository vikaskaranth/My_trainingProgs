#include<iostream>
using namespace std;
const float  pi=3.14156;

class Circle{
    private:
       float radius, circumference;
       float area, diameter;
     public:
        Circle(){
            radius= circumference=0;
            area=diameter=0;
        }
        Circle(float   r){
            if(r>0)
                radius=r;
            else{
                radius=0;
            }
            circumference=0;
            area=diameter=0;
        }
        void set_radius(float  r){
           radius=r;
        }
        void fn_area(void){
          area = pi * radius * radius;
        }
        void fn_circumference(void){
           circumference = 2 * pi *radius;
        }
        void fn_diameter(void){
           diameter = 2*radius;
        }
        
        float get_radius(){
           return radius;
        }
        float get_diameter(){
          return diameter;
        }
        float get_area(){
           return area;
        }
       float get_circumference(){
           return circumference;
       }
};
int main()
{
    Circle  c1(10.0);
    //c1.set_radius(25.5);
    c1.fn_area();
    c1.fn_circumference();
    c1.fn_diameter();
 
    cout<<"radius is "<<c1.get_radius()<<endl;
    cout<<"diameter is "<<c1.get_diameter()<<endl;
    cout<<"Area is "<<c1.get_area()<<endl;
    cout<<"Circumference is "<<c1.get_circumference()<<endl;  
 }

