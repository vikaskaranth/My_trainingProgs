#include"triangle.h"

main(){
    Triangle otriangle;
    Triangle *ptr_triangle=nullptr;

    ptr_triangle = new Triangle();
    ptr_triangle->set_base(25.0);
    ptr_triangle->set_height(15.0);

    cout <<"Area of triangle is :"<<ptr_triangle->fnarea()<<endl;
    cout <<"perimeter of triangle is :"<<ptr_triangle->fnperimeter()<<endl;

    cout <<"-------------------------------------------\n";

    Triangle *ptr_triangle2= new Triangle(15.5,25.75);
    ptr_triangle2->fnarea();
    ptr_triangle2->fnperimeter();
    ptr_triangle2->display();


   delete ptr_triangle;
   delete ptr_triangle2;



















/*
    Triangle otriangle2(5.0,10.0);
    otriangle.set_base(25.0);
    Triangle otriangle;
    otriangle.set_height(15.0);
    cout <<"Area of triangle is :"<<otriangle.fnarea()<<endl;
    cout <<"perimeter of triangle is :"<<otriangle.fnperimeter()<<endl;

    cout <<"-------------------------------------------\n";
    otriangle2.fnarea();
    otriangle2.fnperimeter();
    otriangle2.display();
*/
}
