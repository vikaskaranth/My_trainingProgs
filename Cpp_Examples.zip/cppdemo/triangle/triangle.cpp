#include<iostream>
#include"triangle.h"

using namespace std;

Triangle::     Triangle(float   b, float h){
    base = b; height = h;
}
Triangle::      Triangle(Triangle&){}
void Triangle::  set_base(float b){ 
    base = b;
}
void Triangle::  set_height(float  h){
    height = h;
}
float Triangle:: fnarea(){  
    area= (0.5*base*height);
    return area;
}
float Triangle:: fnperimeter(){
    float  side1;
    float  side2;
    side1= (sqrt(0.5*((pow(2.0*height,2.0))+(base*base))));
    side2= (sqrt(0.5*((pow(2.0*height,2.0))+(base*base))));
    perimeter=  base + side1 + side2;
    return perimeter;
}
float Triangle::  get_base(){
    return base;
}
float Triangle:: get_height(){
    return height;
}
float  Triangle:: get_area(){
    return area;
}
float  Triangle:: get_primeter(){
    return perimeter;
}
void Triangle:: display(){
    cout << "Base is: "<< base;
    cout << "Height is "<< height;
    cout << "Area is "<< area;
    cout << "Perimeter is "<<perimeter;
}
 Triangle::      ~Triangle(){}
