#include<iostream>
#include<cmath>

using namespace std;
class Triangle
{
    protected:
        int side1, side2, side3;
        float  area;
        float perimeter;
    public:
        Triangle(){}
        Triangle(int s1, int s2, int s3){
            side1 = s1;
            side2 = s2;
            side3 = s3;
        }
        virtual float fnarea()=0;
        virtual float fnperimeter()=0;

        void Print(){
           cout <<"side1 is: "<<side1  <<endl;
           cout <<"side2 is: "<<side2  <<endl;
           cout <<"side3 is: "<<side3  <<endl;
           cout <<"area is: "<< area <<endl;
           cout <<"perimeter is: "<<perimeter  <<endl;
        }
};

class Rtriangle: public Triangle{
    public:
        Rtriangle(int s1, int s2, int s3):Triangle(s1,s2,s3){}

        virtual float fnarea(){
            area = 0.5 * side1 * side2;
            return area;
        }
        virtual float fnperimeter(){
            perimeter = side1 + side2 + side3;
            return perimeter;
        }
};
class Sctriangle: public Triangle{
    public:
        Sctriangle(int s1, int s2, int s3):Triangle(s1,s2,s3){}
        virtual float fnarea(){
             float s;
             s = (side1 + side2 + side3)/ 2.0;  
             area = sqrt(s*(s-side1)*(s-side2)*(s-side3));
             return area;
        }
        virtual float fnperimeter(){
            perimeter = side1 + side2 + side3;
            return perimeter;
        }
};
