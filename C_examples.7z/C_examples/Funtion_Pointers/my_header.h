#include<stdio.h>

typedef int (*fun_pointer) (int x, int y);

int addition_function(int x, int y);

int multiplication_function(int x, int y);
