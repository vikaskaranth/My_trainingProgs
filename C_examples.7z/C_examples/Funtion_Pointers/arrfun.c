# include <stdio.h>
char fun(void)
{
	printf(" world \n"); 
}
char fun1(void)
{
	printf("hello \n "); 
}
char fun2(void)
{
	printf(" Bye.........! \n"); 
}
main()
{
	
	char (*fn[3])(void);

	fn[0] = fun;
	fn[1] = fun1;
	fn[2] = fun2;


	printf("address of fn[0] is : %u\n",fn[0]);
	printf("address of fn[1] is : %u\n",fn[1]);
	printf("address of fn[2] is : %u\n",fn[2]);
	fn[0]();
	fn[1]();
	fn[2]();
}
