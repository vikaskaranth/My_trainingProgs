#include<stdio.h>

typedef int (* fun_pointer) (int x, int y);

int addition_function(int x, int y){
		//printf("%d", (x+y));
		return ( x + y);
	}

int multiplication_function(int x, int y){
		//printf("%d",(x*y));
		return (x * y);
	}

main()
{
	fun_pointer x = addition_function;
	fun_pointer y = multiplication_function;

	printf("The Address of the addition_function is : %d\n", x);
	printf("The Addition Result is :%d\n",x(10,5));

	printf("The Address of the multiplication function is : %d\n", y);
	printf("The Multiplication result is : %d\n", y(10,5));

}
