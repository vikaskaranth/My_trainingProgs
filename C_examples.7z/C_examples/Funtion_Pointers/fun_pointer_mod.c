#include<stdio.h>
#include "my_header.h"
// Link "lib.c" while compiling

main()
{
	
	fun_pointer x = addition_function;

	printf("The Address of Addition Function : %d\n", x);
	printf("The Addition Value is : %d\n", x(10,5));

	x = multiplication_function;

	printf("The Address of Multiplication Function : %d\n", x);
	printf("The Multiplication Value is :%d\n", x(100,5));
}
