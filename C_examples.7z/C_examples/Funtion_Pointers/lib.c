#include<stdio.h>
#include "my_header.h"

int addition_function(int x, int y){
	return ( x + y );
}

int multiplication_function(int x, int y){
	return( x * y );
}
