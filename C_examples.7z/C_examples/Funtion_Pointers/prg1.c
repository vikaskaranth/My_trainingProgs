# include <stdio.h>

int small (int a, int b)
{
	return a<b?a:b;
}
int large (int a, int b)
{
	return a>b?a:b;
}
int select(int (*fn)(int,int),int x,int y)
{
	int value=fn(x,y);
	return value;
}

main()
{
	int m,n,high,low;
	int (*ptrf)(int,int);
	
	printf("Enter 2 integers\n");
	scanf("%d %d",&m,&n);
	/*ptrf=large;
	high=select(ptrf,m,n);
	ptrf=small;
	low=select(ptrf,m,n);
	*/
        high=select(large,m,n); 
	low=select(small,m,n); 
	printf("large=%d\n",high);
	printf("small=%d\n",low);

}
