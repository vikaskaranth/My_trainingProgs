#include<stdio.h> 
long fact(long int num)
{
	if(num==0)
	return 1;
	else
	return num * fact(num-1);
}

main()
{
	long int n, f1;
	long int(*ptrfact)(long int);
	
	ptrfact=fact;
	printf("Enter the number whose factorial has to be found\n");
	scanf("%ld",&n);
	
	f1=(*ptrfact)(n);
	
        printf("%d\n",sizeof ptrfact);
	printf("The factorial of %ld is %ld\n",n,f1);
	printf("The factorial of %ld is %ld\n",n+1,ptrfact(n+1));
}
