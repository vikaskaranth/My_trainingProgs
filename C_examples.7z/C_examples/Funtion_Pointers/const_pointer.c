#include<stdio.h> 

main()
{
     int   iNum=10;
     int   iz= 77;
     int  * const iPtr = &iNum;
     
     iPtr=  &iz;
   //  printf("%d\n",++(*iPtr));
}
