#include <stdio.h>
struct elec
{
	char name[20];
	char add1[20];
	char add2[20];
	float previous;
	float current;
	float unit;
	float due;
	float total;
}rec[10];

main()
{
	int i;
	int num;
	printf("enter number of records\n");
	scanf("%d",&num);
	for(i=0;i<num;i++){
		printf("enter name\n");
		scanf("%s",rec[i].name);
		printf("enter address\n");
		scanf("%s",rec[i].add1);
		printf("enter address2\n");
		scanf("%s",rec[i].add2);
		printf("enter previous reading\n");
		scanf("%f",&rec[i].previous);
		printf("enter current reading\n");
		scanf("%f",&rec[i].current);
		printf("enter amount due\n");
		scanf("%f",&rec[i].due);
		rec[i].unit=rec[i].current-rec[i].previous;
		if(rec[i].unit<=00)
			rec[i].total=rec[i].unit*2.00+rec[i].due;
		if(rec[i].unit>100 && rec[i].unit<=250)
			rec[i].total=rec[i].unit*3.00+rec[i].due;
		if(rec[i].unit>250)
			rec[i].total=rec[i].unit*5.00+rec[i].due;
	}
	for(i=0;i<num;i++){
		printf("custmers name=%s\n",rec[i].name);
		printf("address=%s\n",rec[i].add1);
		printf("address=%s\n",rec[i].add2);
		printf("previous reading=%f\n",rec[i].previous);
		printf("current reading=%f\n",rec[i].current);
		printf("total amount due=%f\n",rec[i].total);
	}
}


