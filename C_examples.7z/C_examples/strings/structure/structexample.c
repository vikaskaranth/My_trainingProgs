#include<stdio.h>
struct student
{
	int rollno;
	char name[20];
	int marks;
};
main()
{
	struct student student1;
	
	student1.rollno=1;
	strcpy(student1.name,"raju");
	student1.marks=45;
	printf("\n printing student1 details");
	printf("\n student Roll No : %d ",student1.rollno);
	printf("\n student Name	 : %s ",student1.name);
	printf("\n student Marks   : %d \n",student1.marks);	

	printf("\n printing student2 details");
	struct student student2 = {2,"Yashawini",67};
	printf("\n student Roll No : %d ",student2.rollno);
	printf("\n student Name	 : %s ",student2.name);
	printf("\n student Marks   : %d\n ",student2.marks);	
	
	
	printf("\n Enter student3 details : \n");
	struct student student3;
	scanf("%d%s%d",&student3.rollno,student3.name,&student3.marks);
	printf("\n student Roll No : %d ",student3.rollno);
	printf("\n student Name	 : %s ",student3.name);
	printf("\n student Marks   : %d\n ",student3.marks);
	
}
