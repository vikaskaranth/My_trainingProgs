#include <stdio.h>
struct stud
{
char name[25];
char rno[10];
int marks[5];
int total;
float avg;
}rec[10];
main()
{
	int i,j;
	for(i=0;i<2;i++)
	{
		printf("enter student's name\n");
		scanf("%s",rec[i].name);
		printf("enter roll number\n");
		scanf("%s",rec[i].rno);
		printf("enter marks obtained in 5 subjects\n");
		for(j=0;j<5;j++)	
			scanf("%d",&rec[i].marks[j]);
		rec[i].total=0;
		for(j=0;j<5;j++)
		rec[i].total=rec[i].total+rec[i].marks[j];
		rec[i].avg=(rec[i].total)/5;
	}
	for(i=0;i<2;i++)
	{
		printf("name=%s\n",rec[i].name);
		printf("roll number=%s\n",rec[i].rno);
		printf("total marks obtained in 5 subjects=%d\n",rec[i].total);
		printf("average marks=%f\n",rec[i].avg);
	}
}
