void strcopy(char [], char []);

main()
{
	char source[20],  target[20];
	printf("enter any string ");
	scanf("%[^\n]s",source);
	strcopy(target, source);
	printf("\ncopied string is %s\n",target);
}

void strcopy(char t[],char   s[])
{
	int i;
	for(i = 0; (t[i]=s[i])!='\0'; i++)
		;
}
