#include<stdio.h> 

extern int iData=100;
main()
{
      printf("%d\n",iData);
}
