/*file1.c*/

extern int a , b ;

int f (void)
{
a = a * b;
return a;
}
