#include<stdio.h>
#include<stdlib.h>
main()
{
     int  *ai[10],     i,    j;

     int row = 2, col = 3;

     for(i = 0; i < row; i++){	
	    //ai[i] = (int *) malloc(sizeof(int) *5);
	    *(ai+i) = (int *) malloc(sizeof(int) *5);
     }
     for(i = 0; i < row; i++){
 	    printf("Enter 3 ints : \n");
	    for(j = 0; j < col;j++)
		//scanf("%d",*(ai+i)+j);
		scanf("%d",&ai[i][j]);
     }
     printf("Ints are\n"); 
	for(i = 0; i < row; i++){
		for(j = 0; j < col;j++)
	//		printf("%d   ",*(ai[i]+j));
	//		printf("%d   ",*(*(ai+i)+j));
	//		printf("%d   ",*(j+*(i+ai)));
			printf("%d   ",j[i[ai]]);
		printf("\n"); 
	}
	for(i = 0; i < row; i++){	
	    //free(ai[i]);
	    free(*(ai+i));
        }	
}
