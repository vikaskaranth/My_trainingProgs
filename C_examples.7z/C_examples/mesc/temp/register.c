#include<stdio.h>

int main()
{
int num1=5,num2=10;
int sum;

sum = num1 + num2;

printf("\nsum  : %d",sum);

return(0);
}
