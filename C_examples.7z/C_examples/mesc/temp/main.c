#include<stdio.h> 

static int  iData;

void  bar(void);

main()
{
    iData = 99;
    printf("iData is : %d\n",iData);
    bar();
    printf("This After iData is : %d\n",iData);
}
