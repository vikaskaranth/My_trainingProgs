#include<stdio.h> 
extern int iData; // Do not allocate memory

 void bar()
{
    iData=55;
    printf("In bar %p",&iData);
    //printf("In bar %d",iData);
}
