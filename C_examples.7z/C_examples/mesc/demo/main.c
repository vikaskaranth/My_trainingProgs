#include<stdio.h> 

int  iData;

static void  foo(void);
void  bar(void);

main()
{
    iData = 99;
    printf("iData is : %d\n",iData);
    bar();
    printf("This 55 After iData is : %d\n",iData);
}
