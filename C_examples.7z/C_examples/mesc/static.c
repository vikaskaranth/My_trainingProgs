#include<stdio.h> 
void foo(void);

main()
{
    foo();
    foo();
    foo();
    foo();
    foo();
}
void foo(void)
{
    int  i = 0;
    printf("%d-->",i++);
}
