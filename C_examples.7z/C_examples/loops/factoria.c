/* PROGRAM TO FIND THE factorial OF THE NUMBER without recursion */

#include<stdio.h>

main()
{
	int num,fact=1,i;

	printf("ENTER any number:");
	scanf("%d",&num);

	for (i=num; i>0; i--)
		fact=fact*i;

	printf("THE factorial of %d IS : %d",num,fact);
}
