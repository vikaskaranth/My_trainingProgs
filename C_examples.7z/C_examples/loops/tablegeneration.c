main()
{
	int num,counter;
	printf("Enter any number :");
	scanf("%d",&num);
	for(counter=1;counter<=10;counter++)
	{
		printf("%d x %d = %d\n",num,counter,num*counter);
	}
}
