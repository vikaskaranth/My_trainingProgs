#include<stdio.h>
main()
{
	while(1){
		int x ;
		scanf("%d",&x);
		if(x!=20)
			printf("Hai\n");
		else if(x == -999) break;
		else{ 
			continue;
			printf("I am here in else\n");
		}
		printf("Bye\n");
	}
}
