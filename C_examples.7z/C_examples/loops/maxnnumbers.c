main()
{
	int	n,  max, i , num;
	printf("total numbers\n");
	scanf("%d",&n);
	printf("Enter a number\n");
	scanf("%d",&num);
	max = num;
	for(i = 1; i < n; i++){
		printf("Enter a number\n");
		scanf("%d",&num);
		if(num > max)
			max = num;
	}
	printf("The max is %d",max);
}
	
