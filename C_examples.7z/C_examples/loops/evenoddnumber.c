/* program to generate even and odd number    */

main()
{
	
	int counter;

	printf("printing even numbers in 0 to 100\n\n");
	for(counter=0;counter<=100;counter+=2)
		printf("%4d",counter);
	
	printf("\nprinting odd numbers in 1 to 100");
	printf("\n");

	for(counter=1;counter<=100;counter += 2)
		printf("%4d",counter);
	printf("\n");	
	
}
