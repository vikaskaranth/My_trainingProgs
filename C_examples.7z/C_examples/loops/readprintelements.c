// A program to read and display the elements 

#include<stdio.h>

main()
{
	int element[10],ctr;
	printf("\n Reading the elements\n");

	for(ctr=0;ctr<10;ctr++){
		printf("\n element %d is :\t",ctr+1);
		scanf("%d",&element[ctr]);
	}

	printf("\n Printing the elements\n");
	for(ctr=0;ctr<10;ctr++)
		printf("%8d",element[ctr]);
		
	printf("\n");	
}
