#include<stdio.h>

int *nums;

main()
{
	int next, *old;
	int n=0;
	void print_nums(unsigned int);

	nums=(int *)malloc(sizeof(int));
	while(1)
	{
		printf("Enter %dth number\n", n);
		if(scanf("%d", nums+n)!=1)break;
		old=nums;
		nums=(int *)malloc((++n+1)*sizeof(int));
		for(next=0;next<n;next++)	
			nums[next]=old[next];
		free(old);
	}//closing while loop
	
	print_nums(n);
	exit(0);

}//closing main


void print_nums(unsigned int N)
{
	unsigned int i ; i=0;
	while(i<N)
	{
		printf("Number is %d\n", *(nums+i));
		i++;
	}
}//closing function print_nums
