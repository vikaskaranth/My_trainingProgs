#include<stdio.h> 
#include<string.h>
main()
{
        char    name[17]="Sachin Tendulkar";
	char    *ptr= "Rahul";
	strcpy(name,"Rahul");  
	strcpy(ptr,"Sachin");  
	printf("address is %u string is : %s\n",ptr,ptr);
	printf("address is %u string is : %s\n",name,name);
	}
