#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

main()
{
	int  *a[5],*b[5]  ,  *c[5],   i , j,   k;
	for(i = 0; i < 5;i++)
	{
		a[i] = (int *) malloc(sizeof(int)*5);
		b[i] = (int *) malloc(sizeof(int)*5);
		c[i] = (int *) malloc(sizeof(int)*5);
	}

	puts("Enter elements to mat1\n");
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
			scanf("%d",*(a+i)+j);

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(a+i)+j));
		puts("\n");
	}
	puts("Enter elements to mat2\n");
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
			scanf("%d",*(b+i)+j);

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(b+i)+j));
		puts("\n");
	}
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
		{
			*(*(c+i)+j) = 0;
			for(k = 0; k < 2;k++)
				*(*(c+i)+j) += *(*(a+i)+k) * *(*(b+k)+j);
		}

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(c+i)+j));
		puts("\n");
	}
}
