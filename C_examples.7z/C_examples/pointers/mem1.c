#include<stdio.h>
#include<stdlib.h> 
#define MAX 10000000


unsigned int nmax;
unsigned int *nums;

main()
{
	unsigned int ctr, n;
	void print_nums(unsigned int);

	printf("Enter Max no. you want to input");
	if(scanf("%d",&nmax)!=1)
		exit(1);

	if(nmax <1 || nmax > MAX)
	{
		fprintf(stderr,"Enter nmax properly");
			exit(2);
	}
	nums= (unsigned int *)malloc(nmax * sizeof (unsigned int));
	ctr=0;
	while(ctr<nmax)
	{
		printf("Enter %dth number", ctr);
		if(scanf("%d",nums+ctr)!=1)break;
		ctr++;
	}

	n=ctr;
	print_nums(n);
	exit(0);

}  //closing main

void print_nums(unsigned int N)
{
	unsigned int i ; i=0;
	while(i<N)
	{
		printf("Number is %d\n", *(nums+i));
		i++;
	}
}//closing function print_nums
