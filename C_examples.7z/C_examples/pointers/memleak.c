#include<stdio.h>
#include<string.h> 
#include<stdlib.h> 

main()
{
      char   *cptr1,*cptr2,*cptr3;

      cptr1 = malloc(21);
      strcpy(cptr1,"TATA");
      printf(cptr1);
      
      cptr2 = malloc(21);
      strcpy(cptr2,"ELXSI");
      printf(cptr2);

      cptr3 = malloc(21);
      strcpy(cptr3,"BAngalore");
      printf(cptr3);
          /*

          */
 
       cptr2 = cptr1 ;
       /*
 *
 *
 *
 * */

       cptr2=NULL;
     
}
