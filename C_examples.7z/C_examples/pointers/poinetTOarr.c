#include<stdio.h> 
main()
{
    int   (*Ptr)[10];
    int   iarr[10];
    int   iarr2[5];

    int *aaa;



    Ptr = &iarr2;

}
