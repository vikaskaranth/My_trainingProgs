#include<stdio.h> 
# include<unistd.h> 
#include<stdlib.h>

main()
{
	int  *a[5],  *b[5]  ,  *c[5],   i , j;
	for(i = 0; i < 5;i++)
	{
		a[i] = (int *) malloc(sizeof(int));
		b[i] = (int *) malloc(sizeof(int));
		c[i] = (int *) malloc(sizeof(int));
	}

	puts("Enter elements to mat1\n");
	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
			scanf("%d",*(a+i)+j);

		for(i = 0; i < 2;i++)
			for(j = 0; j < 2;j++)
				scanf("%d",*(b+i)+j);

	for(i = 0; i < 2;i++)
		for(j = 0; j < 2;j++)
			*(*(c+i)+j) = *(*(a+i)+j) + *(*(b+i)+j);

	for(i = 0; i < 2;i++)
	{
		for(j = 0; j < 2;j++)
			printf("%d\t",*(*(c+i)+j));
		puts("\n");
	}
	for(i = 0; i < 5;i++){
		free(a[i]);
		free(b[i]);
		free(c[i]);
	}
}
