#include<string.h>
#include<stdio.h>
#include<stdlib.h> 
main()
{
    char   name[25];

    char  *ptr =name;         //4000

    strcpy(ptr, "string");
    printf(ptr);    

}














	/*
	//ptr =(char  *)  malloc(100);
	strcpy(ptr,"Bits of paper lying on the floor");
	printf(ptr);
	
//	free(ptr);
}
*/











