# include <stdio.h>
main()
{
	int  	x = 5;
	int 	*p = &x;
	printf("x=%d\n",x);
	printf("p=%u\n",p);
	printf("&x=%u\n",&x);
	printf("*p=%d\n",*p);
	printf("&p=%u\n",&p);
	printf("It is address of x *&p=%u\n",*&p);
}

