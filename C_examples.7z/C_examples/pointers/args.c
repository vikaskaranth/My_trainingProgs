#include<stdio.h>
#include<stdlib.h> 

main(int argc , char *argv[])
{
	int i;
	printf("argc is :%d\n",argc);
	for(i = 0 ; i < argc; i++)
    	    printf("%d -->%s\n",i,argv[i]);
}
