/* using malloc allocating memory. sorting using selection sort algorithm
 in decending order.  Passing pointer to a function */

#include<stdio.h>
#include<stdlib.h> 

void selection(int *,int );

main()
{
	int n,	i;
	int	*p ;
	
	printf("enter limit of an array");
	scanf("%d",&n);
 	p=(int  *) calloc(n,sizeof(*p));
	for(i=0;i<n;i++)
		scanf("%d",(p+i));

	selection(p,n);
	for(i = 0;i < n;i ++)
		printf("\n%d",*(p+i));
		
	free(p);
	p = NULL;
}

void selection (int *p,int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if(*(p+i)<*(p+j)) /*decending */
			{
				temp=*(p+i);
				*(p+i)=*(p+j);
				*(p+j)=temp;
	 		}
}
