#include<stdio.h>
main()
{
	int  arr[2][3][2]={
		   		{ {10,20}, {30,40}, {35,50}},
				{{1,2}, {3,4}, {5,10}}
				};
	printf("%u   %u     %u  %u\n",arr,*arr,**arr,***arr);
	printf("%u   %u   %u   %u  %u\n",arr,arr+1,*arr+1,**arr+1,***arr+1);
	//printf("%u   %u   %u    %u\n",arr,(*arr+0)+1,**arr+1);
}
