# include <stdio.h>
main()
{
	int  	x = 5;
	int 	*p = &x;
	
	char c = 'z',*cp;
	cp = &c;
	
	double  *dp;
	
	printf("sizeof=%d\n",sizeof(*cp));
	printf("sizeof=%d\n",sizeof(cp));
	
	printf("sizeof=%d\n",sizeof(*p));
	printf("sizeof=%d\n",sizeof(p));
	
	printf("sizeof=%d\n",sizeof(dp));
	printf("sizeof=%d\n",sizeof(*dp));
	
	printf("sizeof=%d\n",sizeof(int *));
	printf("sizeof=%d\n",sizeof(double *));
}

