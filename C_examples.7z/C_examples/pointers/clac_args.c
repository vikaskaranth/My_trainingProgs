#include<stdio.h>
#include<stdlib.h> 

main(int argc , char *argv[], char **env)
{
	int result;
	if(argc != 4)printf("Error in input\n");
	else{
	   switch(argv[2][0]){
		case '+':result =  atoi(argv[1]) + atoi(argv[3]);
	 		 printf("result is %d\n",result); 
	  	  	  break;	
		case '*': result = atoi(argv[1]) * atoi(argv[3]);
				printf("result is %d\n",result); 
			  break;	
		case '/':result= atoi(argv[1]) / atoi(argv[3]);
				printf("result is %d\n",result); 
			  break;	
		case '-': result = atoi(argv[1]) - atoi(argv[3]);
			printf("result is %d\n",result); 
			  break;	
		default: printf("Invalid operator\n");
	    }
	}	
//	puts(env[0]);
//	puts(env[1]);
//	puts(env[3]);
//	getchar();
}
