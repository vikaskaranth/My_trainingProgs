#include<stdio.h>
main()
{
	int  a=1024;
	char *ptr ;
	ptr =(char  *)&a;

	printf("\n%u    ",*ptr++); 
	printf("\n%u    ",*ptr++); 
	printf("\n%u    ",*ptr++); 
	printf("\n%u    ",*ptr++); 
}
