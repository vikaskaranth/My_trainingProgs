#include<stdio.h>

struct student
{
	unsigned int reg_no;
	char name[50];
	unsigned int mark;
} ;

main()
{
	struct student rec;
	FILE *fp;
	fp=fopen("class.rec","wb");
	printf("\n Enter the register number, name and mark\n");
	printf("Type ctrl+d to stop\n");

	// read from keyboard and type to file
	while(scanf("%u %s %u",&rec.reg_no,rec.name,&rec.mark)!=EOF)
		fwrite(&rec,sizeof(rec),1,fp);
	fclose(fp);
	printf("\n");

	// Read from file and write on screen
	fp=fopen("class.rec","rb");
	while(fread(&rec,sizeof(rec),1,fp))
	     printf("%5u %10s %3u\n",rec.reg_no,rec.name,rec.mark);
	fclose(fp);
}

