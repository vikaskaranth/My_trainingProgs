main()
{
	int i = 5;
	int z = i++ + i++ + ++i;
	printf("%d\n",z);
}
