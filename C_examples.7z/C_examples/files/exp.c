#include <stdio.h>
#include<math.h>
main()
{
	printf("%g\n",exp(1.00)); 
}
