#include<stdio.h>
main()
{
	int x;
	int retval;
	__fpurge(stdin);
	if((retval = scanf("%d",&x)) == 0) perror("Scanf:");
	else	printf("x is %d\n",x);
}
