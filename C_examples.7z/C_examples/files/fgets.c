/* Program to illustrate usage of fgets and rewind functions */

# include <stdio.h>
# include <unistd.h>
# include <string.h>
main()
{
	char	str[80];
	FILE	*fp;
	if((fp = fopen("Test","w+")) == NULL){
		printf("Can't open a file\n");
		_exit(1);
	}
	do{
		printf("Enter a string, <CR> to quit	>");
		gets(str);
		strcat(str,"\n");//add newline at the end of string
		fputs(str,fp);
	} while(*str!='\n');

	rewind(fp);	//Bring file pointer to the begining

	while(!feof(fp)){   //Check for not end of file
		fgets(str, 79,fp);	// Read from file
		printf(str);
	}
	fclose(fp);
}

