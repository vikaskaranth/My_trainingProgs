/*  Reading from file using fscanf */

#include<stdio.h>
#include<unistd.h>

main()
{
 	FILE *fp;
	char name[30];
	int d,m,y;
 	fp=fopen("students.dat","rb+");
	if(fp==NULL){
		 perror("can't open the file\n");
		 _exit(0);
	}	
	fscanf(fp,"%s %d %d %d",name,&d,&m,&y);	// Reading from file
        do{
		printf("name is: %s\n",name);
		printf("DOB is :%d/%d/%d\n",d,m,y);
		fscanf(fp,"%s %d %d %d",name,&d,&m,&y);	// Reading from file
}	while(!feof(fp)) ;

  	fclose(fp);
} 
