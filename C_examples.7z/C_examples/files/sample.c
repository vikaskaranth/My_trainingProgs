/*  Reading from file using fscanf */

#include<stdio.h>
#include<unistd.h>

main()
{
 	FILE *fp;
	int    d;
    char   m[25];
    
 	fp=fopen("nums.txt","rb+");
	if(fp==NULL){
		 perror("can't open the file\n");
		 _exit(0);
	}	
	
    	fgets(m,25,fp);	// Reading from file
  //  	printf("DOB is :%d\n",d);
        puts(m);
 //       if(m[0] == '\n')  break; 
    //}	while(!feof(fp)) ;

  	fclose(fp);
	puts("OK BOSS I'AM EXITING\n");
	getchar();
} 
