#include<stdio.h>
# include <unistd.h>


main()
{
 	FILE *fp;
	char name[30];
	int d,m,y;
 	fp=fopen("students.dat","ab+");
	if(fp==NULL){
		 perror("can't open the file\n");
		_exit(0);
	}
	scanf("%s",name);
	scanf("%d%d%d",&d,&m,&y);

	fprintf(fp,"%s %d %d %d\n",name,d,m,y);

  	fclose(fp);
} 
