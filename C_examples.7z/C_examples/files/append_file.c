#include<stdio.h>
#include<unistd.h>

main()
{
 	FILE *fp;
	char name[30];
	int d,m,y;
 	fp=fopen("stud.dat","a+");
	if(fp==NULL)
		 perror("can't open the file\n");
//	scanf("%s",name);
//	scanf("%d%d%d",&d,&m,&y);
	if(feof(fp)) {
		 printf("the file contains no data\n");
		 _exit(0);
 	}

//	fprintf(fp,"%s %d %d %d",name,d,m,y);

	rewind(fp);
	while(!feof(fp)){

		fscanf(fp,"%s %d %d %d",name,&d,&m,&y);
		printf("name is: %s\n",name);
		printf("DOB is :%d//%d//%d\n",d,m,y);

	}
  	fclose(fp);
	puts("OK BOSS I'AM EXITING\n");

} 
