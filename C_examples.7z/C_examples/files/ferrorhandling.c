#include<errno.h>
#include<stdio.h>
#define BUFSIZE (16384u)
typedef struct
{
	unsigned int reg_no;
	char name[50];
	unsigned int mark;
} st_rec;

char f_buf[BUFSIZE];

main()
{
	int sz=sizeof(st_rec);
	unsigned long len,i,n;
	st_rec rec;
	FILE *fp;
	if(!(fp=fopen("class.rec","rb")))
	{
		perror("Error in opening the file class.rec");
		return errno;
	}
	setvbuf(fp,f_buf,_IOFBF,BUFSIZE);	

	if(fseek(fp,0,SEEK_END))
	{	
		perror("Error while seeking to the end of file");
		return errno;
	}

	if((len=ftell(fp))==-1)
	{
		perror("Error finding the value of file pointer");
		return errno;
	}
		
	printf("\n The file class.rec is of %d bytes in length\n",len);
	n=len/sz;
	printf("There are %d records in the file\n",n);
	do
	{
		printf("Enter the record number to read (0 to stop):");
		__fpurge(stdin);
		scanf("%d",&i);
		printf("%d\n",i);
		if(i > 0 && i<=n)
		  if(fseek(fp,(i-1)*sz,SEEK_SET))
		    printf("Seek failed , record number %d doesnot exist\n",i);
		else
		{
		   if(sz==fread(&rec,sz,1,fp))
		   {
			  perror("Error reading the file class.rec");
		          return errno;
		   }
		   printf("%5u %-10s %3u\n",rec.reg_no,rec.name,rec.mark);
		}
	}while(i);
	if(fclose(fp))
	{
        	 perror("Error closing the file class.rec");
                 return errno;
	}
}

