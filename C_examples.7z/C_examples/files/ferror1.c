# include <stdio.h>

# define  TABSIZE	8
# define  IN	0
# define  OUT	1

void err(int	e);
main(int argc, char *argv[])
{
	FILE	*in, *out;
	int	tab,  i;
	char	ch;
	if(argc!=3){
		printf("Usage: a.out <in> <out>\n");
		exit(1);
	}
	if((in = fopen(argv[1],"rb")) == NULL){
		printf("error in opening a file for in\n");
		exit(2);
	}
	if((out = fopen(argv[2],"wb")) == NULL){
		printf("error in opening a file for in\n");
		exit(3);
	}
	tab = 0;
	do{
		ch = getc(in);
		if(ferror(in))	err(IN);
		// If tab found output appropriate number of spaces
		if(ch =='\t') {
			putc('@',out);
			if(ferror(out)) err(OUT);
			tab = 0;
		}
		else {
			putc(ch, out);
			if(ferror(out))	err(OUT);
			tab ++;
			if(tab == TABSIZE) tab = 0;
			if(ch =='\n' || ch =='\r') tab = 0;
		}	
	} while(!feof(in));
	fclose(in);
	fclose(out);
}
void err(int  e)
{ 
	if(e == IN) printf("Error on input");
	else	printf("Error on Output\n");
	exit(1);
}
			
