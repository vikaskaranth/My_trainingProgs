//A sample session with gdb
# include <stdio.h>
main()
{
	int num1, num2, total;
	printf("Enter the first number\n");
	scanf("%d",num1);
	printf("Enter the second number\n");
	scanf("%d",num2);
	total = num1 + num2;
	printf("The sum is %d\n",total);
}
