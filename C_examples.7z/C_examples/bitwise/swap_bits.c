//4.program to swap two integers using bitwise operators.
#include<stdio.h> 
#include<unistd.h> 
/*
main( )
{
	int x,y,i;
	printf("Enter any two numbers:");
	scanf("%d%d",&x,&y);
	printf("Before swapping:x=%d,y=%d",x,y);	
	x^=y;
	y^=x;
	x^=y;
	printf("After swapping:x=%d,y=%d",x,y);
}
*/

main()
{
      int   x = 5;
      printf("%d   ",5|4);
      }
