//program to invert the n bits from position p.

main()
{
int x,j,p,n,i;
	printf("Enter any number:");
	scanf("%d",&x);
	
	for(i=31;i>=0;i--)
	printf("%d",(x>>i)&1);
	
	printf("Enter the position p from where u want to invert the bits:");
	scanf("%d",&p);
	
	printf("Enter the number of bits u want to invert:");
	scanf("%d",&n);
	
	x=(x^(~(~0<<n)<<(p+1-n)));
	for(i=31;i>=0;i--)
	printf("%d",(x>>i)&1);
	
}
