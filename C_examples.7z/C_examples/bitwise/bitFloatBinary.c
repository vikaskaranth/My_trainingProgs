/*
*	Print the decimal floating point number in the binary form
*/
#include<stdio.h> 
#define SIZE 32
main()
{
	float x = -5.6;
	unsigned int *y;
	unsigned int mask = 0x01;
	int a[SIZE];
	int res, i;
	y = (unsigned int)&x;

	for(i = 31; i >= 0; i--)	
	{
		res = *y & mask;
		mask = mask << 1;
		if(res == 0)
			a[i] = 0;
		else
			a[i] = 1;
	}
	for(i=0;i<SIZE;i++)
	{
		if( i == 1 || i == 9 )
			printf(" ");
		printf("%d",a[i]);
	}
	printf("\n");


}
