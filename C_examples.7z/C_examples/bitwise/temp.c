#include<stdio.h> 
main()
{
     char x = 4;
	 x ^= 4;
	 printf("%d\n",x);
}
