//To make both numbers EQ using bitwise operator

#include<stdio.h>
main()
{
      int num = 1,  num2=64;
      printf("Num2 is %d\n",num2);
      num = num << 6;
      if(num == num2) printf("EQ\n");
      printf("Num is %d\n",num);
   getchar();
      }
