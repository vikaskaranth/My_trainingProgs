// To keep only first bit on

#include<stdio.h>
main()
{
      char num = 33;
      printf("Num is %d\n",num);
      num &=~32;
      printf("Num is %d\n",num);

} 
