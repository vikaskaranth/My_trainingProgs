//program to swap any two bits of a given integer.
// Debugged

main( )
{
 	int num,x,y,i;
	printf("Enter any number:");
	scanf("%d",& num);
	for(i=31;i>=0;i--)
	printf("%d",(num>>i)&1);
	
	printf("Enter any two bit positions which u want to swap\n");
	scanf("%d%d",&x,&y);
	
	if(((num >>x)&1) != ((num>>y)&1))
	{
	num=num^(1<<x);
	num=num^(1<<y);
	}
	for(i=31;i>=0;i--)
	printf("%d",(num>>i)&1);
	
}
