#include<stdio.h> 
#include<stdlib.h>
#include<unistd.h>
main(int argc,char*argv[])
{
	unsigned char Snum=8 ;
	
	printf("%u  \n", (1 << Snum ));
	for( ; Snum;Snum--)
             printf("%d  ",(1 << Snum ));
}
