/*
* Swap corresponding bits
*/

/*
*  This program swaps the corresponding bits of a character.  For example,
*          msb (bit 7) is exchanged with lsb (bit 0);
*          msb-1 (bit 6) is exchanged with lsb+a (bit 1), so on
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h> 

unsigned char
swap_bits ( unsigned char uc )
{
    unsigned char bits = 0;
    int times = CHAR_BIT / 2,
          msb = CHAR_BIT-1,
          lsb = 0;



     while ( times )
     {
        bits |= ( (uc & (1<<msb)) >> msb ) << lsb;
        bits |= ( (uc & (1<<lsb)) >> lsb ) << msb;
        msb;
        lsb++;
     }
          
    return bits;
}

int
main ( void )
{
    unsigned char uc = 0xef;

    printf ( "The byte: %#x\n", uc );
    printf ( "After bit swapping: %#x\n", swap_bits ( uc ) );
    return EXIT_SUCCESS;

}
