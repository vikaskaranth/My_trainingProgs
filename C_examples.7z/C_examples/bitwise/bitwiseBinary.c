/*
*	Print the integer decimal number in the binary form
*/
#include<stdio.h> 
#define SIZE 32
main()
{
	unsigned int x = 165;
	unsigned int mask = 0x01;
	int a[SIZE];
	int res, i;
	for(i = 31; i >= 0; i--)	
	{
		res = x & mask;
		mask = mask << 1;
		if(res == 0)
			a[i] = 0;
		else
			a[i] = 1;
	}
	for(i=0;i<SIZE;i++)
	{
		if(i%4 == 0)
			printf(" ");
		printf("%d",a[i]);
	}
	printf("\n");


}
