//program to reverse the bits of an integer.
#include<stdio.h> 
/*
main( )
{
 	int i,num=5;
	for(i=31;i>=0;i--) {
		printf("%d",num&1);
		num=num>>1;
	}
	getchar();
}
*/
main( )
{
 	int i,num=5;
	for(i=0;i<32;i++) {
		printf("%d",num&1);
          num=num>>1;
	}
}
