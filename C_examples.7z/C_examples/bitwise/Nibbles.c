#include <stdio.h>
#define nibbles( c )  ((c<<4)&0xF0) | ((c>>4)&0x0F)

//Macro for exchanging the nibbles	

int main(int argc, char *argv[])
{
	char ch=0x27;
	printf("%x  ",nibbles(ch));

	return 0;
}
