// a program to swap 2 numbers without using temporary variables

main()
{
	int num1,num2;
	printf("Enter any 2 numbers :");
	scanf("%d %d",&num1,&num2);
	printf("numbers before swaping\n ");
	printf("num1 = %d \t  num2 = %d\n",num1,num2);
	num1 = num1 ^ num2;
	num2 = num1 ^ num2;
	num1 = num1 ^ num2;
	printf("numbers after swaping \n");	
	printf("num1 = %d \t  num2 = %d\n",num1,num2);
}
