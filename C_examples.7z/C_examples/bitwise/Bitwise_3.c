#include<stdio.h>

main()
{
      unsigned char num = 32;
      printf("Num is %d\n",num);
      num &=~64;
      printf("Num is %d\n",num);

}

Output: 32
