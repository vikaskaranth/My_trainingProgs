//1.Program to show the bits of an integer in both big-endian and little - endian style.

main( )
{
	int i,num=64;
	for(i=31;i>=0;i--)
	printf("%d",(num>>i)&1);
    printf("\n");
    for(i=0;i<32;i++)
	printf("%d",(num>>i)&1);
    
    getchar();
}
