//program to set the n bits from position p with the right most n bits of y,leaving the other bits unchanged.

main( )	
{
	int n,p,y,x;
	printf("Enter any number:");
	scanf("%d",&x);
	
	for(i=31;i>=0;i--)
	printf("%d",(x>>i)&1);
	
	for(i=31;i>=0;i--)
	printf("%d",(y>>i)&1);
	
	printf("Enter the position p from where u want to set the right most bits of y");
	scanf("%d",&p);
	printf("Enter number of bits u want to set from position p with the right most bits of y");
	scanf("%d",&n);
	
	x=x&~(~(~0<<n) << (p+1-n)) | (y& ~(~0<<n)) <<(p+1-n);
	for(i=31;i>=0;i--)
	printf("%d",(x>>i)&1);
	
	for(i=31;i>=0;i--)
	printf("%d",(y>>i)&1);
}
