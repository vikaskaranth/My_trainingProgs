#include<stdio.h>

struct sample
{
	int _today_hour;
	int _today_min;
	int _today_sec;
}_sample_struct;

main()
{
	printf("Enter the Current hour : \n");
	scanf("%d", &_sample_struct._today_hour);
	printf("Enter the current minute : \n");
	scanf("%d", &_sample_struct._today_min);
	printf("Enter the current minute : \n");
	scanf("%d", &_sample_struct._today_sec);
	
	printf("\n");
	printf("%d : %d : %d\n", _sample_struct._today_hour, _sample_struct._today_min, _sample_struct._today_sec);
}	      
