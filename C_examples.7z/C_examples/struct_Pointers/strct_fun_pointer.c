#include<stdio.h> 
struct pointers{
	int (* int_fun_pointer)(int, int);
	float (* float_fun_pointer)(float, float);
	char str[100];
};

int int_function(int x , int y);
int function(int x , int y);

float float_function(float x , float y);
float fun(float x , float y);

main()
{
	struct pointers   obj={	
		int_fun_pointer : function,
		float_fun_pointer : float_function,"MY name is Khan"
	};
	
	printf("%d\n",(*obj.int_fun_pointer)(10,20));
	printf("%f\n",(*obj.float_fun_pointer)(10.0001,20.00001));
	printf("%s\n",obj.str);
}

int function(int x , int y)
{
	   printf("function is called\n");
	   return 999;
}
float fun(float x , float y)
{
	   printf("fun is called\n");
	   return 999;
	   return 99.9999;
}
int int_function(int x , int y)
{
	   printf("int_function is called\n");
	return (x + y);
}
float float_function(float x , float y)
{
	   printf("float_function is called\n");
	return (x + y);
}
