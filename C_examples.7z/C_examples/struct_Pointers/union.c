#include<stdio.h>

union sample
{
    char   cData;
    int    iData;
    float  fData;
    double dData;
};
union sample   Obj;

void foo(){
     Obj.iData = 91;  
     printf("%d   ",Obj.iData);
}

main()
{
     

   Obj.cData = 'a';
   printf("%c   ",Obj.cData);
    
    Obj.iData = 191;  
    printf("%d   ",Obj.iData);
    foo();
    printf("after calling foo() in main %d   ",Obj.iData);
    printf("%c   ",Obj.cData);
    Obj.dData = 91.78655;
    printf("%g   ",Obj.dData);
    printf("%d",sizeof(Obj));
}
