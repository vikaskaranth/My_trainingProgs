# include <stdio.h>

struct emp{
	char  name[10];
	int age;
}; 

main()
{
	int i ;
	struct emp   *rec;

	rec=(struct emp *) malloc(3*sizeof(struct emp ));
	for(i = 0; i < 3; i++)
		scanf("%s %d",(rec+i) ->name,&(rec+i) ->age);
	for(i = 0; i < 3; i++)
		printf("%s\t%d\n",(rec+i)->name,(rec+i)->age);
}
