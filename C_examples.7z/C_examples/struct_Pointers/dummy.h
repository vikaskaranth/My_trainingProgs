struct date
{
    int d , m , y;
}Obj;
