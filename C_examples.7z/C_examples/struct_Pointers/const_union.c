#include<stdio.h>

/*union sample
{
    char   cData;
    int    iData;
    float  fData;
    double dData;
};*/
union sample
{
    char    cData;
    int     iData;
    double  dData;
}
main()
{
    const union sample   Obj1={.cData=85};
    const union sample   Obj2={.iData=8576453};
    const union sample   Obj3={.dData=857.6453};
   // Obj.cData = 'a';
    printf("%c   ",Obj1.cData);
    //Obj.iData = 91;  
    printf("%d   ",Obj2.iData);
    
    //Obj.dData = 91.78655;
    printf("%g   ",Obj3.dData);

//   printf("%d",sizeof(Obj));
   	
}
