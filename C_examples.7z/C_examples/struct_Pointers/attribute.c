# include<stdio.h>
# include<string.h>
struct test
	{
    	    unsigned char  field1;
    	    unsigned short field2;
    	    unsigned long  field3;
	} __attribute__((__packed__));
	
	typedef struct test test_t;
	
	test_t var1, var2;

main()
{
    printf("%d\n",sizeof var1);

}
