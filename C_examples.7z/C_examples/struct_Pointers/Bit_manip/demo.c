# include <stdio.h>

struct bit{
	unsigned  int  a: 4;
	unsigned  int  b: 5;
	unsigned  int  c: 3;
        unsigned  int  d: 7;
        unsigned  int  e: 12;
        unsigned  int  f: 8;
        unsigned int unused:30 ; //pading
};
main()
{
	struct bit Obj = { 8,25,4,45};
	printf("%u\n",Obj.a); 
	printf("%u\n",Obj.b); 
	printf("%u\n",Obj.c); 
	printf("%u\n",Obj.d); 

	printf("size od Obj is :%u\n",sizeof (Obj)); 
}
