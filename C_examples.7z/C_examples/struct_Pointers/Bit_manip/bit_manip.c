#include<stdio.h>

struct bit{
	unsigned val : 7;
	unsigned sex : 1;
        unsigned mstatus : 2;
	unsigned mem : 10;
	unsigned padding : 12;
	
};

main()
{
	struct bit obj={25,0,1,100};
	printf("%u\n", obj.val);
	printf("%u\n", obj.sex);
	printf("%u\n", obj.mstatus);
	//printf("%d\n",obj.a);
	printf("%d\n", sizeof(obj));
}
