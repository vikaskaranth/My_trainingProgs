# include <stdio.h>


struct bit{
	unsigned age : 7;
	unsigned sex : 1;
	signed mstatus : 1;
	unsigned sal : 16;
	unsigned experience : 5;
	unsigned Noleaves:5;
	//unsigned unused :   5;
	float    Hra;
	float    CCa;
	float    Lta;
	char     Designation[10];
};
main()
{
	struct bit obj={25,1,0,19000,5,18,8000.0,2000.00,2000.00,"PL"};
	struct bit obj1;
	obj.Hra=3500.0;
	obj.CCa=2500.0;

	printf("%u\n",obj.age);
	printf("%u\n",obj.sex);
	printf("%d\n",obj.mstatus);
	printf("%f\n",obj.Hra);
	printf("%f\n",obj.CCa);

//	printf("%i\n%d",obj1.x,obj1.i);
//	printf("sizeof %d\n",sizeof(obj));
}
