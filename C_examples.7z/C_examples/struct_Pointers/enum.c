#include <stdio.h>

main()
{
   enum
   {
      monday=1, tuesday, wednesday, thursday,\
      friday, saturday, sunday
   } day;

   day = wednesday;

   if(day == saturday || day == sunday)
      printf( "Day is a weekend day" );
   else if(day == wednesday)
      printf( "Day is hump day - middle of the work week");
}

          
