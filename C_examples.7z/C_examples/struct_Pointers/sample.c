#include<stdio.h>

struct day
{
    struct date
    {
         int dd,mm,yy;
    } Date;
    struct 
    {
         int HH,MM,SS;
    }Time;
};

main()
{
	struct day Day={
                          {10,06,2015},
                          {10,10,50 }
                       };
        
	printf("%d   \n",Day.Date.dd); 
	printf("%d   \n",Day.Date.mm); 
	printf("%d   \n",Day.Date.yy); 

	printf("%d   \n",Day.Time.HH); 
	printf("%d   \n",Day.Time.MM); 
	printf("%d   \n",Day.Time.SS); 
}










