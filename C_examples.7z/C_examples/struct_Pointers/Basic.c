# include <stdio.h>
# include <string.h>

struct Employee  { 
      char name[50]; 
      int     EmpId;
      float salary; 
}  oEmpRaj = {"Raj kumar",15399 ,100000.90 };
	 
   
main ()
{
	struct Employee  oRecord;
	//struct student student3;	
	printf("Enter Employee  name\n"); 
	scanf("%s",oRecord.name);	
	printf("Eneter Emp ID\n");
	scanf("%d",&oRecord.EmpId );
	printf("Eneter Emp salary\n");
	scanf("%f",&oRecord.salary );
	
	printf("Employee One Data is \n"); 
	printf(" Name is %s \n", oEmpRaj.name);
	printf(" Employee ID is %d \n",oEmpRaj.EmpId);
	printf(" Employee ID is %f \n",oEmpRaj.salary);
	
	printf("Employee Two's Data is \n"); 
	printf(" Name is %s \n", oRecord.name);
	printf(" Employee ID is %d \n",oRecord.EmpId);
	printf(" Employee ID is %f \n",oRecord.salary);

}
