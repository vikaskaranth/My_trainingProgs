#include<stdio.h> 

main()
{
     enum bool {
        false=1 ,
        true=0
     } value ;

     value = false;
     if (value){
         printf("You are what you belive\n");
     }
     else if (value==false){
         printf("You are what you pretend\n");
     }
}
