#include<stdio.h>
main(int  argc, char  *argv[])
{
	int i;
	printf("sum is %d\n", atoi(argv[1])+atoi(argv[2]));

}
