
# include <stdio.h>
main()
{
	char   name[10];
	int   phy , che, math;
	float	total , ave;
	printf("Enter marks obtained in three subjects\n");
	scanf("%d%d%d",&phy,&che,&math);
	total = math+che+phy;
	ave = total / 3;
	if(phy >= 50  && che >= 50 && math >=50)
	{
		if(ave >= 80)
		{
			printf("A grade\n");
			printf("Total is : %f\tave is %f\n",total,ave);
		}
		else if(ave < 80 && ave >= 60)
		{
			printf("B grade\n");
			printf("Total is : %f\tave is %f\n",total,ave);
		}
		else
		{
			printf("C grade\n");
			printf("Total is : %f\tave is %f\n",total,ave);
		}
	}
	else
	{
		printf("Student is failed\n");
		printf("Total is : %f\tave is %f\n",total,ave);
	}
}
