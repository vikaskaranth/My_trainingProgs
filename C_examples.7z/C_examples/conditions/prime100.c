#include <stdio.h>
#include <math.h>
main()
{
	int m,n,i,j,flag=1;
	printf("enter 2 numbers\n");
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++)
	{
		flag = 1;
	//	printf("\nm = %d",m);
		for(j=2;j<=sqrt(i);j++)
		{
		//	printf(" i= %d j= %d\t",i,j);
			if(i%j==0)
			{
				flag=0;
				break;
			}

		}
		if(flag==1)
			printf("prime no: %d\n",i);
	}
	printf("\n");
}


