/* PROGRAM TO FIND THE ROOTS OF A QUADRATIC EQUATION */

#include<ctype.h>
# include <math.h>
#include<stdio.h>

main()
{
	float a,b,c,dino,disc,x1,x2,xr,xi,x;

	printf("ENTER THE value FOR THE 1 NUMBERS:");
	scanf("%f",&a);

	printf("\n");
	printf("ENTER THE value FOR THE 2 NUMBERS:");
	scanf("%f",&b);

	printf("\n");
	printf("ENTER THE value FOR THE 3 NUMBERS:");
	scanf("%f",&c);

	disc=b*b-4*a*c;
	printf("\n");

	if (disc>0)
	{
		printf("THE ROOTS ARE REAL AND DISTINCT:-\n");
		dino=2*a;
		x1=(-b+sqrt(disc))/dino;
		x2=(-b-sqrt(disc))/dino;
		printf("\n");
		printf("THE FIRST ROOT:  %f\n",x1);
		printf("\n");
		printf("THE SECOND ROOT: %f\n",x2);
	}
	else if(disc<0)
	{
		printf("THE ROOTS ARE COMPLEX:-\n");
		printf("\n");
		dino=2*a;
		xr=-b/dino;
		xi=sqrt(abs(disc))/dino;
		printf("THE FIRST COMPLEX ROOT: %f\n",xr);
		printf("\n");
		printf("THE SECOND COMPLEX ROOT: i%f\n",xi);
	}
	else
	{
		printf("THE ROOTS ARE COMPLEX:-\n");
		x=-b/(2*a);
		printf("\n");
		printf("ROOTS ARE: %f%f\n",x,x);
	}

}

