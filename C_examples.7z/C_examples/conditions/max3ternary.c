main()
{
	int num1,num2,num3,max;
	printf("Enter any 3 numbers :");
	scanf("%d %d %d",&num1,&num2,&num3);
//	max = (num1 > num2 ? (num1 > num3 ? num1 : num3) : num2 > num3 ? num2 : 	num3);
	max=((num1>num2)&&(num1>num3)?num1:(num2>num3)?num2:num3);
	printf("The greatest of three numbers is %d\n",max);
}













/*main()
{
	int   num1,num2,num3;
	int max;
	scanf("%d%d%d",&num1,&num2,&num3);
	max=num1>num2?num1>num3?num1:num3:num2>num3?num2:num3;
	printf("%d",max);
}*/
