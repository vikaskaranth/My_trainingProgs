#include<stdio.h> 
main()
{
	int dd, mm, yy;
	printf("Enter ur date of birth\n");
	scanf("%d%d%d",&dd,&mm,&yy);
	switch(mm){
		default	:	printf("Invalid month\n");
				break;
		case	1 :	printf("%d Jan %d\n",dd,yy);
				break;
		case	2 :	printf("%d Feb %d\n",dd,yy);
				break;
		case	3 :	printf("%d March %d\n",dd,yy);
				break;
		case	4 :	printf("%d April %d\n",dd,yy);
				break;
		case	5 :	printf("%d May %d\n",dd,yy);
				break;
		case	6 :	printf("%d Jun %d\n",dd,yy);
				break;
		case	7 :	printf("%d July %d\n",dd,yy);
				break;
		case	8 :	printf("%d Augst %d\n",dd,yy);
				break;
		case	9 :	printf("%d Septmber %d\n",dd,yy);
				break;
		case	10 :	printf("%d October %d\n",dd,yy);
				break;
		case	11 :	printf("%d November %d\n",dd,yy);
				break;
		case	12 :	printf("%d December %d\n",dd,yy);
				break;
	}
}
