/*	Program to find maximum amoung three numbers using ternary operator */

main()
{
	int   num1,num2,num3;
	int max;
	scanf("%d%d%d",&num1,&num2,&num3);
	max=num1>num2?num1>num3?num1:num3:num2>num3?num2:num3;
	printf("%d",max);
}
