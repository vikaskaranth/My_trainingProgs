/*

# Version 1.0 
# 15 July 2006, vikas karanth <vikaskaranth@gmail.com>
# written to use as  program to check back traces points in gdb 
# bt  : print the back trace of the entaire stack
  bt n : print the inner most n frams  
  bt -n: print the outermost n frams
  bt full : print the values of the local variables

  Selecting the frames: 
	f n : select the frame number n
	f addr : select the fame at adress addr
	up n   : move n frams up the stack
	down n : move n frams down the stack

*/

# include <stdio.h>
#include<unistd.h> 
#include<stdlib.h> 
#include <pthread.h>

void fun1(void);
inline void fun2(void);
void fun3(void);

/* The main program. */
int main ()
{
	long long ctr=0;
	pthread_t thread_id;

/* Create a new thread. The new thread will run the print_xs
function. */

	pthread_create (&thread_id, NULL, (void *)fun1, NULL);
			/* Print o's continuously to stderr. */
	sleep(1);
	ctr = 0;
	while (ctr < 10000000000000ull)
	ctr ++	;
return 0;
	
}

void fun1(void)
{
	int fun1j = 10;
	printf("fun1j = %d\n",fun1j);
	fun2();
}

inline void fun2(void)
{
	int fun2k = 10;
	printf("fun2k = %d\n",++fun2k);
	fun3();
}
void fun3(void)
{
	int fun = 10;
	printf("In fun3\n");
	printf("fun = %d\n",fun++);
}

