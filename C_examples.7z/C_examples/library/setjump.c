#include<stdio.h> 
#include<setjmp.h>

jump_buf	jbuf;
banana()
{
	printf("In banana\n");
	longjump(jbuf,1);
	printf("You will never see this because I am longjumped\n");
}
main()
{
	if(setjump(jbuf))
		printf("back in main\n");
	else{
		printf("Ist time through\n");
		banana();
	}
}
