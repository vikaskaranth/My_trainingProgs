#ifndef __FILE2_H__
#define __FILE2_H__

# define  UKP	1

#endif
