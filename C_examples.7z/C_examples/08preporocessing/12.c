/*
 *	# and ## are two preprocessor operators used to string operations  *
 */
# include <stdio.h>
#define mkstr(s)	#s
main()
{
   /*replaced as printf("I like C");  */

    	printf(mkstr(I like C));
}
