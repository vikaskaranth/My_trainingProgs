#include <stdio.h>
#include <math.h>

#define LARGER(x, y)   ((x) > (y) ? (x) : (y)) 

#define MAX(x,y)  x > y? x:y 
#define SQR(x) (x) * (x)
#define SQUARE(x) pow(x,2)\

main ()
{
	int k = 4;
	int j = 24;
	int z;
	
	z = LARGER(k++,j++);
	
	printf ("value of z is %d j is %d\n", z, j);	
	
	
/*int z = MAX(k++,j++);// k++ > j++ ? k++ : j++
  
        printf("k^k %d\n",SQR(k+5));  //4+5 * 4+5
       printf("j^j %lf\n",SQUARE(j)); // pow(j,2)
*/


}

