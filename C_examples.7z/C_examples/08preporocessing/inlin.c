#include <stdio.h>

#define LARGER(x,y) (x *x* y+(x- --y ))

inline int larger(int, int);

main()
{
     int a=10,b=5;
	int max;
	max = LARGER(a++,b++);
	printf("max is : %d\n",max); 
	printf("%d    %d\n",a,b); 
}
int larger(int x, int  y)
{
	   return (x > y ?x : y );
}
