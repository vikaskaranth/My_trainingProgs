#include <stdio.h>
#include "file1.h" 		 //A

#ifdef USD	       		// B 
       #define currency_rate 46     //C

#endif          			//G
#ifdef UKP   			// E
   #define currency_rate 100 //F
#endif          			//G

main()
{		
	int rs;
	rs = 10 * currency_rate;  //H
	printf ("%d\n", rs);
}
