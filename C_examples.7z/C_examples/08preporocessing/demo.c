#include<stdio.h>
void fun(void);
main()
{
    #define   MAX  1024
	printf("MAX is %d\n",MAX);
	#undef MAX
	fun();


}
void fun(void)
{
     #if (defined   MAX)
		printf("MAX is %d\n",MAX);
	#endif
}
