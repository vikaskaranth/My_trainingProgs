#include <stdio.h>
#include "file2.h" 			 

#if ((1>0) &&(defined (USD))	)       	 
       #define currency_rate 46     	
#endif        				

#if (defined (UKP))   	//predicate returns true if the symbol is defined
   #define currency_rate 100 
#endif         
main()
{		
	int rs;
	rs = 10 * currency_rate;
	printf ("%d\n", rs);
}

