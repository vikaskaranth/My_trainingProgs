#include<string.h>
#include<stdio.h> 

#define DUMBCOPY   	for(i=0;i<65536;i++)destination[i]=source[i]
#define SMARTCOPY   	memcpy(destination,source,65536)

main()
{
	char source[65536],destination[65536];
	int   i,   j;

	printf("DUMBCOPY\n");  // always faster 
	for(j=0;j<100;j++) DUMBCOPY;
/*
	printf("SMARTCOPY\n");
	for(j=0;j<100;j++) SMARTCOPY;
*/
}
