#include <stdio.h>
#define VAL 40
int x=VAL;

main()
{
	printf ("%d\n",x);	
	printf ("%d\n",VAL);	
    #undef  VAL 
	#define  VAL 50	
	printf ("%d\n",x);	
	printf ("%d\n",VAL);	
}

