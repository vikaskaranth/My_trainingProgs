# include <stdio.h>

/*# line 13	"11.c"		//reset the line number */
main()				//3
{				//4
	printf("%d\n",__LINE__);//5
	printf("%s\n",__FILE__);//6
	printf("%s\n",__DATE__);
	printf("%s\n",__TIME__);
}				
