/*
 *	# and ## are two preprocessor operators used to string operations  *
 */
# include <stdio.h>

#define concat(a,b) a##b	
main()
{
	int helloworld = 10;
	printf("%d",concat(hello,world));//This is expanded into printf("%d",xy);
}
