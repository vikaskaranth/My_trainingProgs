#include <stdio.h>
#include "file1.h"  		 //A

#ifndef USD	       		 // B 
       #define currency_rate 100     //C
#endif        			//D

#ifndef UKP   			// E
   #define currency_rate 46 //F
#endif          			//G
main()
{		
	int rs;
	rs = 10 * currency_rate;  //H
	printf ("%d\n", rs);
}

