#include <stdio.h>
main()
{
	printf("A\n");	

//     # line 100			
	printf("B\n");		
	printf("C FILE %s  LINE %d\n", __FILE__, __LINE__ );		
  //   #line200			

	printf("D\n");	
	printf("E\n");	
}

