/* PROGRAM TO FIND THE NORM AND TRACE OF THE MATRIX  */

#include<stdio.h>
#include<math.h>

int	* alloc(void);
main()
{
	int *a,i,j,n,trace=0;
	float norm=0.0;

	printf("ENTER THE ORDER OF THE MATRIX :");
	scanf("%d",&n);

	for (i=0; i<n; i++)
		for (j=0; j<n; j++)
		{
			scanf("%d",&a[i][j]);
			norm=norm+a[i][j]*a[i][j];
		}

	for(i=0; i<n; i++)
		trace += a[i][i];

	for (i=0; i<n; i++)
	{
		for (j=0; j<n; j++)
			printf("%d\t",a[i][j]);
			printf("\n");
	}

	printf("THE NORM OF THE MATRIX IS :%lf \n",norm);
	printf("THE TRACE OF THE MATRIX IS:%d \n",trace);

}
