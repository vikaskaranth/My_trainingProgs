/* PROGRAM TO FIND THE TRANSPOSE OF THE MATRIX  */

#include<stdio.h>

main()
{
	int a[10][10];
	int row,col;
	int i,j;

	printf("ENTER THE ROW AND COLUMN ORDER FOR THE MATRIX :\n");
	scanf("%d%d",&row,&col);
	printf("\n");

	if (row == col)
	{
		printf("ENTER MATRIX A :\n");
		for (i=0; i<row; i++)
			for (j=0; j<col; j++)
				scanf("%d",&a[i][j]);

		printf("\n");
		printf("THE FOLLOWING ARE THE NUMBERS YOU HAVE ENTERED \n");
		printf("\n");

		for (i=0; i<row; i++)
		{
			for (j=0; j<col; j++)
				printf("%d\t",a[i][j]);
			printf("\n");
		}

		printf("\n");
		printf(" transpose OF THE MATRIX IS .......... \n");
		printf("\n");

		for (i=0; i<row; i++)
		{
			for (j=0; j<col; j++)
				printf("%d\t",a[j][i]);
			printf("\n");
		}

	}
}
