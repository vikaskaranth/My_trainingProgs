main()
{
      int iNum[]={5,10,15,20,25}; int    *ptr;
      int   ctr;      ptr = iNum;
      printf("ptr is %d \n",++*ptr); 
      printf("ptr is %d \n",*ptr++);
      
      printf("ptr is %d \n",*++ptr);
      printf("ptr is %d \n",(*ptr)++); 
      printf("ptr is %d \n",++(*ptr));
      printf("\n");
      for(ctr=0; ctr < 3;ctr++) 
        printf("ptr is %d \n",*(ptr+ctr));
      getchar();
      }
