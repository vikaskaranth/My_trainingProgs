/* PROGRAM TO MULTIPLY THE CONTENTS OF THE TWO COMPATABLE MATRIX  */

#include<stdio.h>
#include<math.h>

main()
{
	int a[10][10],b[10][10],c[10][10];
	int row1,row2,col1,col2;
	int i,j,k;

	printf("ENTER THE ROW AND COLUMN ORDER FOR THE MATRIX A :\n");
	scanf("%d%d",&row1,&col1);
	printf("\n");

	printf("ENTER THE ROW AND COLUMN ORDER FOR THE MATRIX B :\n");
	scanf("%d%d",&row2,&col2);
	printf("\n");

	if (col1 == row2)
	{
		printf("ENTER THE %d ELEMENTS INTO %d * %d MATRIX A :\n",row1*col2,row1,col1);

		for (i=0; i<row1; i++)
			for (j=0; j<col1; j++)
				scanf("%d", &a[i][j]);

		printf("MATRIX A \n");
		for (i=0; i<row1; i++)
		{
			for (j=0; j<col1; j++)
				printf("%d\t",a[i][j]);
			printf("\n");
		}
		printf("ENTER THE %d ELEMENTS INTO %d * %d MATRIX B :\n",row2*col2,row2,col2);
		for (i=0; i<row2; i++)
			for (j=0; j<col2; j++)
				scanf("%d", &b[i][j]);

		printf("MATRIX B \n");

		for (i=0; i<row2; i++)
		{
			for (j=0; j<col2; j++)
				printf("%d\t", b[i][j]);
			printf("\n");
		}

		for (i=0; i<row1; i++)
			for(j=0; j<col2; j++)
			{
				c[i][j]=0;
				for (k=0; k<col2; k++)
				   c[i][j] = (c[i][j] + (a[i][k] * b[k][j]));
			}

		printf("Resultant Matrix is\n");
		for(i=0; i<row1; i++)
		{
			for(j=0; j<col2; j++)
				printf("%d\t", c[i][j]);
			printf("\n");
		}
	}
	else
		printf("THE PRODUCT OF TWO MATRIX IS NOT POSSIBLE \n");

}
