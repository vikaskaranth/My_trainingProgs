
#include <stdio.h>
 #include <string.h>
void fun();
    main()
    {  
           fun();
            fun();
           fun();
           fun();
           getchar();
           return 0;
}
void fun()
{
    static  int x  = 5;
     printf("%d\n",++x);
 }
