 # include<stdio.h>
 
  struct point
  {
   int x[4];
    double y;
 }O;


// struct sample  Obj,*pp;
main()
{
printf("(%d,)\n",sizeof(O));

 	getchar();

}
