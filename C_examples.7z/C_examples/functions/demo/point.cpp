#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int func(int i);
main()
{
       unsigned int  i = -1;     
 int j = -4;  
 printf("%d", i + j);           

      getchar();

}
