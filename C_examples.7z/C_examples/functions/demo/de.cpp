#include<stdio.h>

main()
{
      char   name[]="algc";
     char *p=name;
     printf("%c",++*(p++));
      printf("%c",*++p);
       fflush(stdin);
       getchar();
      }
