
/* PROGRAM TO FIND THE factorial OF THE NUMBER recursivly */
# include <stdio.h>

int  factorial(int);

main()
{
	int   num;
	printf("Enter a number \n");
	scanf("%d",&num);
	printf("%d\n",factorial(num));
}
int factorial(int n)
{
	if(n == 0)
		return 1;
	return (n * factorial(n - 1));
}
