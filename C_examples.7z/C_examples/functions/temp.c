#include<stdio.h>
void fun(void);
void foo(void);
void bar(void);
void zoozoo(void);
int g_num;

main()
{
	g_num = 5;
    printf("Hai in main  before fun %d\n",g_num); 
    fun();
    printf("Hai in main after call to fun %d\n",g_num); 
printf("Hai in fun  %f\n",z);
}
float  z=50;
void fun(void)
{
     z++;
     g_num++;
     printf("Hai in fun  %d\n",g_num); 
     printf("Hai in fun  %f\n",z); 
     /*foo();*/
 }
void foo(void)
{	
    z++;
    printf("Hai in foo  %f\n",z); 
     bar();
 }
void bar(void)
{	
    z++;
     printf("Hai in bar  %f\n",z); 
 }
void zoozoo(void)
{
 }
