#include<stdio.h>
int uvPow(int );
main(int argc, char **argv)
{
     int iNum,iPowerof;
     int iResult;
     printf("Enter a number\n");
     scanf("%u",&iNum);
     iResult=uvPow(iNum);
     printf("%u to the power is %u\n",iNum,iResult);
}
int uvPow(unsigned  int p)
{
     if(p == 1)	
          return  n;
     return (n * uvPow(n, p - 1));
}
