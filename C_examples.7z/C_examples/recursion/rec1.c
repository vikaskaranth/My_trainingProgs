/*    Program to find the product of array elements using Recursion    */

long int prod(int *,int);

main()
{
	int a[10];
	int n;
	int i;
	printf("Enter the value of n\n");
	scanf("%d",&n);
	printf("Enter the array elements:\n");
	for(i=1;i<=n;i++)
		scanf("%d",&a[i]);
	printf("the product is =%ld\n",prod(a,n));
}

long int prod(int a[],int n)
{
	if(n==0)
		return 1;
	else
		return(a[n]*prod(a,n-1));
}

