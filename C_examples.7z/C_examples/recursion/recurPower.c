#include<stdio.h>
unsigned int uvPow(unsigned int ,unsigned  int);
main()
{
     unsigned int iNum,iPowerof;
     unsigned int iResult;
     printf("Enter a number\n");
     scanf("%u",&iNum);
     printf("Enter power to be found\n");
     scanf("%u",&iPowerof);
     iResult=uvPow(iNum,iPowerof);
     printf("%u to the power %u is %u\n",iNum,iPowerof,iResult);
}
unsigned int uvPow(unsigned int n,unsigned  int p)
{
     if(p == 1)	
          return  n;
     return (n * uvPow(n, p - 1));
}
