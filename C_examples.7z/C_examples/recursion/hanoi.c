/****    Implementation of tower of hanoi     ****/
#include<stdio.h>
void towers(int,char,char,char);
main()
{
	int n;
	printf("Enter the number of disks:");
	scanf("%d",&n);
	towers(n,'A','C','B');
}
void towers(int n,char src,char dst,char aux)
{
	if(n>0){
		towers(n-1,src,aux,dst);
		printf("Move disk %d from peg %c to peg %c\n",n,src,dst);
		towers(n-1,aux,dst,src);
	}
}
