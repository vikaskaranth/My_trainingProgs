/**************************************************************************/
/*                 TO FIND THE FACTORIAL OF A NUMBER	                  */
/**************************************************************************/

#include<stdio.h>
main()
{
	unsigned int fact(unsigned int);
	unsigned int num,factorial;
	printf("Enter the number\n");
	scanf("%u",&num);	
	factorial=fact(num);
	printf("The factorial of a number is %u\n",factorial);
}

unsigned int fact(unsigned int n)
{
	if(n==1)
		return 1;
	return(n*fact(n-1));
}
