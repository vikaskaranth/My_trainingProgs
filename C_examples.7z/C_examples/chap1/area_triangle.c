/* if area is calculated as 1/2*base *height the result is zero since 1/2 is an integer division which yields the quotient as zero               */

#include<stdio.h>

main()
{
	float base,height,area;
	printf("Enter the base and height of the triangle\n");
	scanf("%f%f",&base,&height);
	area = 1 / 2.0 * base * height;
	printf("The area of the trianlge is %f\n",area);
}

