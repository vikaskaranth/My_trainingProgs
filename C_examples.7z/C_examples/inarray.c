/* incarray.c */
#include <stdio.h>

typedef struct {
	int size;
	char string[33];
	char secname[];
} vlen;

vlen initvlen = { 33 ,{"Bits of paper lying on the floor"} };

int main(int argc,char *argv[])
{
	int i;
	vlen obj;
	printf("sizeof(vlen)=%d\n",sizeof(vlen));
	printf("sizeof(initvlen)=%d\n",sizeof(initvlen));
	for(i=0; i<initvlen.size; i++)
		printf("%c  ",initvlen.string[i]);

	scanf("%s%s",obj.string,obj.secname);
	printf("%s    %s",obj.string,obj.secname);
	printf("\n");
	return(0);
}
