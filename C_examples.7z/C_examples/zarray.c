/* zarray.c */
#include <stdio.h>
#include<stdlib.h> 
#include<unistd.h> 

typedef struct {
     int size;
     char string[0];
} vlen;

int main(int argc,char *argv[])
{
     int i ,count = 22;
     char letter = 'a';
     vlen *line = (vlen *)malloc(sizeof(vlen) + count);
     line->size = count;
     for(i=0; i<count; i++)
     	line->string[i] = letter++;
     printf("sizeof(vlen)=%d\n",sizeof(vlen));
     for(i=0; i<line->size; i++)
  	printf("%c ",line->string[i]);
     printf("\n");
     return(0);
}
