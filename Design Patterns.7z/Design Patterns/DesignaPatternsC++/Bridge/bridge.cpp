#include<iostream>
using namespace std;

/** "Implementor" */
class DrawingAPI {
    public:
           DrawingAPI(){}
      virtual ~DrawingAPI(){}
     virtual void drawCircle(double x, double y, double radius)=0;
};
 
/** "ConcreteImplementor"  1/2 */
class DrawingAPI1  :public DrawingAPI {
   public:
      void drawCircle(double x, double y, double radius) {
        cout<<"Blue colour API1.circle at  "<< x<<":"<< y<<"radius"<< radius<<endl;
   }
};
 
/** "ConcreteImplementor" 2/2 */
class DrawingAPI2  :public DrawingAPI {
   public :
     void drawCircle(double x, double y, double radius) { 
       cout<<"Green colour API2.circle at  "<< x<<":"<< y<<"radius"<< radius<<endl;
   }
};
 
/** "Abstraction" */
class Shape {
   public:
       virtual void draw()=0;                             // low-level
       virtual void resizeByPercentage(double pct)=0;     // high-level
};
 
/** "Refined Abstraction" */
class CircleShape : public Shape {
   private :
      double x, y, radius;
      DrawingAPI *drawingAPI;
   public :
     CircleShape(double xx, double yy, double Radius, DrawingAPI *oDrawingAPI) {
       x = xx;  y = yy; radius = Radius; 
       drawingAPI = oDrawingAPI;
   }
 
   // low-level i.e. Implementation specific
   void draw() {
        (*drawingAPI).drawCircle(x, y, radius);
   }   
   // high-level i.e. Abstraction specific
   void resizeByPercentage(double pct) {
        radius *= pct;
   }
};
 
/** "Client" */
main() {
     Shape *shapes[] ={
           new CircleShape(1, 2, 3, new DrawingAPI1()),
           new CircleShape(5, 7, 11, new DrawingAPI2()),
       };
 
       for (int i =0; i<2;i++) {
           (*shapes[i]).resizeByPercentage(2.5);
           (*shapes[i]).draw();
       }
       system("pause");
   }
