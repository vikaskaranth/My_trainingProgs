//AddrVerification.h 
#pragma once
#include "Observer.h"
#include "Customer.h"

class AddrVerification : public Observer
{
public:
    AddrVerification(void);
    void update( Customer *myCust);
public:
    ~AddrVerification(void);
};
AddrVerification.cpp 
#include "AddrVerification.h"

AddrVerification::AddrVerification(void)
{
}

AddrVerification::~AddrVerification(void)
{
}

void AddrVerification::update ( Customer *myCust) 
{
      // do Address verification stuff here
      // can get more information about customer
      // in question by using myCust
}
