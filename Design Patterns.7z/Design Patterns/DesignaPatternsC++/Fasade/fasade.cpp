#include<iostream>
#include<string>

using namespace std;


namespace ConsoleApplication1
{

   class DifficultProduct
   {
       char *nameChars;

       public:
          DifficultProduct()  {nameChars = new char[10];  }

          void SetFirstNameCharacter(char c)
          {
              nameChars[0] = c;
          }

          void SetSecondNameCharacter(char c)
          {
               nameChars[1] = c;
          }

          void SetThirdNameCharacter(char c)
          {
              nameChars[2] = c;
          }

          void SetFourthNameCharacter(char c)
          {
              nameChars[3] = c;
          }

          void SetFifthNameCharacter(char c)
          {
              nameChars[4] = c;
          }

          void SetSixthNameCharacter(char c)
          {
              nameChars[5] = c;
          }

          void SetSeventhNameCharacter(char c)
          {
              nameChars[6] = c;
              nameChars[7]='\0';
          }

          string GetName()
          {
               return nameChars;
          }
};

class SimpleProductFacade
{
    DifficultProduct *difficultProduct;

    public:
        SimpleProductFacade()
        {
            difficultProduct = new DifficultProduct();
        }

    void setName(char* n)
    {
         char *chars = new char[25];
         strcpy(chars,n);  
         if(strlen(chars) > 0){
              difficultProduct->SetFirstNameCharacter(chars[0]);
         }

         if (strlen(chars) > 1)
         {
              difficultProduct->SetSecondNameCharacter(chars[1]);
         }

         if (strlen(chars) > 2)
         {
              difficultProduct->SetThirdNameCharacter(chars[2]);
         }

    if (strlen(chars) > 3)
    {
      difficultProduct->SetFourthNameCharacter(chars[3]);
    }

    if (strlen(chars) > 4)
    {
      difficultProduct->SetFifthNameCharacter(chars[4]);
    }

    if (strlen(chars) > 5)
    {
      difficultProduct->SetSixthNameCharacter(chars[5]);
    }

    if (strlen(chars) > 6)
    {
      difficultProduct->SetSeventhNameCharacter(chars[6]);
    }
  }

    string GetName()
    {
        return difficultProduct->GetName();
    }
};
    

 class Program
 {
     public :
         Program()
         {
           SimpleProductFacade *simpleProductFacade = new SimpleProductFacade();
           simpleProductFacade->setName("printer");

           cout<<"The product is a " + simpleProductFacade->GetName();
          }
    };
} // End of Namespace
main()
 {
  using namespace ConsoleApplication1;

     Program *p = new Program();
      system("pause");
 }

