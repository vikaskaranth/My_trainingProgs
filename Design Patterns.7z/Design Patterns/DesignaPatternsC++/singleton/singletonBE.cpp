#include <iostream>
using namespace std;

class Singleton {
  static Singleton s;
  int i;
  protected:
  Singleton(){ }
  ~Singleton(){ }
  Singleton(int x) : i(x) { }
  Singleton& operator=(Singleton&);  // Disallowed
  Singleton(const Singleton&);       // Disallowed
public:
  static Singleton& instance() { return s; }
  int getValue() { return i; }
  void setValue(int x) { i = x; }
};

Singleton Singleton::s(47);

int main() {
  Singleton &ref= Singleton::instance();
  cout << ref.getValue() << endl;
  Singleton& s2 = Singleton::instance();
  //s2.setValue(9);
  cout << s2.getValue() << endl;
  cout <<"size of ref is : "<<sizeof ref;
  getchar();
} ///:~
