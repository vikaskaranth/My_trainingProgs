WelcomeLetter.h 
#pragma once
#include "Observer.h"
#include "Customer.h"

class WelcomeLetter : public Observer
{
public:
    WelcomeLetter(void);
    void update( Customer *myCust);
public:
    ~WelcomeLetter(void);
};
WelcomeLetter.cpp 
#include "WelcomeLetter.h"

WelcomeLetter::WelcomeLetter(void)
{
}

WelcomeLetter::~WelcomeLetter(void)
{
}

void WelcomeLetter::update( Customer *myCust)
{
   // do Welcome Letter stuff 
   // here can get more 
   // information about customer 
   // in question by using myCust
}

WelcomeLetter.h 
#pragma once
#include "Observer.h"
#include "Customer.h"

class WelcomeLetter : public Observer
{
public:
    WelcomeLetter(void);
    void update( Customer *myCust);
public:
    ~WelcomeLetter(void);
};
WelcomeLetter.cpp 
#include "WelcomeLetter.h"

WelcomeLetter::WelcomeLetter(void)
{
}

WelcomeLetter::~WelcomeLetter(void)
{
}

void WelcomeLetter::update( Customer *myCust)
{
   // do Welcome Letter stuff 
   // here can get more 
   // information about customer 
   // in question by using myCust
}