#include<iostream>
#include<string>

using namespace std;
     class IQuackBehavior
    {
        public:
           virtual  void Quack()=0;
    };

     class IFlyBehavior
    {
        public :
           virtual void Fly()=0;
    };

     class Quacker :public IQuackBehavior
    {
           public:
         void Quack()
        {
             cout<<"Hi I am quacking\n";
        }
    };

     class Squeak :public IQuackBehavior
    {
        public:
        void Quack()
        {
            cout <<"Squeak Squeak ...\n";
        }
    };

    class FlyWithWings :public IFlyBehavior
    {
        public :
        void Fly()
        {
            cout <<"I am flying in the air\n";
        }
    };

    class FlyNoWay :public IFlyBehavior
    {
        public:
        void Fly()
        {
            cout <<" I cannot fly Sorry!";
        }
    };

class Duck
{
    protected :
        IFlyBehavior *flyBehavior;
        IQuackBehavior *quackBehavior;

    public :
     virtual void SetFlyBehavior(IFlyBehavior*)=0;
       void PerformQuack()
       {
           quackBehavior->Quack();
       }

       void PerformFly()
       {
            flyBehavior->Fly();
       }
};


class MallardDuck : public Duck
{
    public:
    /* virtual */ void SetFlyBehavior(IFlyBehavior*   fly){
                       flyBehavior = fly;
                  }
        MallardDuck()
        {
            flyBehavior = new FlyWithWings();
            quackBehavior = new Quacker();
        }
};

class RubberDuck :public Duck
{
    public :
    /* virtual */ void SetFlyBehavior(IFlyBehavior*   fly){
                       flyBehavior = fly;
                  }
        RubberDuck()
        {
            flyBehavior = new FlyNoWay();
            quackBehavior = new Squeak();
        }
};

main()
{
      Duck *d1 = new MallardDuck();
      cout <<"This is mallard Duck...";
      d1->PerformFly();
      d1->PerformQuack();

      Duck *d2 = new RubberDuck();
      cout <<"This is Rubber Duck...";
      d2->PerformFly();
      d2->PerformQuack();
      cout <<"*******************\n";
      //d2 -> SetFlyBehavior(new FlyWithWings());
       //d2->PerformFly();
      
      system("pause");
}
