bserverTOP
Observer.h 
#pragma once
class Customer;

class Observer
{
public:
    Observer(void);
    virtual void update( Customer *myCust)= 0;
public:
    ~Observer(void);
};
Observer.cpp 
#include "Observer.h"

Observer::Observer(void)
{
}

Observer::~Observer(void)
{
}