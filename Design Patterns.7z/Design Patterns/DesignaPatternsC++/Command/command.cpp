#include<iostream>
using namespace std;

namespace ConsoleApplication4
{
          /* Receiver  */
     class IReceiver
     {
       public:
          virtual  void Connect()=0;
          virtual  void Diagnostics()=0;
          virtual  void Reboot()=0;
          virtual  void Shutdown()=0;
          virtual  void Disconnect()=0;
    };

/* Concerete Receiver 1  */
    class AsiaServer : public IReceiver
    {
        public:
                AsiaServer()     {   }
        void Connect()
        {
            cout<<"You're connected to the Asia server.\n";
        }

        void Diagnostics()
        {
            cout<<"The Asia server diagnostics check out OK.\n";
        }

        void Shutdown()
        {
            cout<<"Shutting down the Asia server.\n";
        }

        void Reboot()
        {
            cout<<"Rebooting the Asia server.\n";
        }

        void Disconnect()
        {
            cout<<"You're disconnected from the Asia server.\n";
        }
    };
/* Concerete Receiver 2  */
    class EuroServer :public IReceiver
    {
        public: EuroServer()  {}

        void Connect()
        {
            cout<<"You're connected to the Euro server.\n";
        }

        void Diagnostics()
        {
            cout<<"The Euro server diagnostics check out OK.\n";
        }

        void Shutdown()
        {
            cout<<"Shutting down the Euro server.\n";
        }

        void Reboot()
        {
            cout<<"Rebooting the Euro server.\n";
        }

        void Disconnect()
        {
            cout<<"You're disconnected from the Euro server.\n";
        }
    };

/* Concerete Receiver 3  */
    class USServer : public IReceiver
    {
        public : USServer()   { }

        void Connect()
        {
            cout<<"You're connected to the US server.\n";
        }

        void Diagnostics()
        {
            cout<<"The US server diagnostics check out OK.\n";
        }

        void Shutdown()
        {
            cout<<"Shutting down the US server.\n";
        }

        void Reboot()
        {
            cout<<"Rebooting the US server.\n";
        }

        void Disconnect()
        {
            cout<<"You're disconnected from the US server.\n";
        }
    };
// Command
     class ICommand
     {
       public:
        virtual void Execute(){}
        virtual void Undo(){}
     };
//Concerete command 1
    class RebootCommand :public ICommand
    {
        IReceiver *receiver;

        public:
           RebootCommand(IReceiver *r)
           {
               receiver = r;
           }

        void Execute()
        {
            receiver->Connect();
            receiver->Reboot();
            receiver->Disconnect();
        }

        void Undo()
        {
            cout<<"Undoing Reboot Command...";
            receiver->Connect();
            receiver->Shutdown();
            receiver->Disconnect();
        }
    };
//Concerete command 2
    class RunDiagnosticsCommand :public ICommand
    {
        IReceiver *receiver;

        public:
           RunDiagnosticsCommand(IReceiver *r)
           {
               receiver = r;
           }

        void Execute()
        {
            receiver->Connect();
            receiver->Diagnostics();
            receiver->Disconnect();
        }

        void Undo()
        {
            cout<<"Can't Undo Run Diagnostics.";
        }
    };
//Concerete command 3
   class ShutDownCommand :public ICommand
    {
        IReceiver *receiver;

        public :
           ShutDownCommand(IReceiver *r)
           {
               receiver = r;
           }

         void Execute()
        {
            receiver->Connect();
            receiver->Shutdown();
            receiver->Disconnect();
        }

         void Undo()
        {
            cout<<"Undoing Shutdown Command...";
            receiver->Connect();
            receiver->Reboot();
            receiver->Disconnect();
         }
    };
/* Invoker  */
    class Invoker
    {
        ICommand *commands[5];
        int position;

        public:
        Invoker() { position = -1;}

         void SetCommand(ICommand *c)
        {
            if (position < 5 - 1)
            {
                position++;
                commands[position] = c;
            }
            else
            {
                for (int loopIndex = 0; loopIndex < 5 - 2;loopIndex++)
                {
                    commands[loopIndex] = commands[loopIndex + 1];
                }
                commands[5 - 1] = c;
            }
        }

        void Run()
        {
            (*commands[position]).Execute();
        }

        void Undo()
        {
            if (position >= 0)
            {
                (*commands[position]).Undo();
            }
            position--;
        }
    };

/* Client   */

class Program
{
    public:
       Program()
       {
            Invoker *invoker = new Invoker();

            // Create the receivers
            IReceiver *asiaServer = new AsiaServer();
            IReceiver *euroServer = new EuroServer();
            IReceiver *usServer = new USServer();

            //Create the commands

            //AsiaServer Commands
            ICommand *shutDownAsia = new ShutDownCommand(asiaServer);
            ICommand *runDiagnosticsAsia = new
              RunDiagnosticsCommand(asiaServer);
            ICommand *rebootAsia = new RebootCommand(asiaServer);

            //EuroServer Commands
            ICommand *shutDownEuro = new ShutDownCommand(euroServer);
            ICommand *runDiagnosticsEuro = new
              RunDiagnosticsCommand(euroServer);
            ICommand *rebootEuro = new RebootCommand(euroServer);

            //UsServer Commands
            ICommand *shutDownUS = new ShutDownCommand(usServer);
            ICommand *runDiagnosticsUS = new
              RunDiagnosticsCommand(usServer);
            ICommand *rebootUS = new RebootCommand(usServer);


            invoker->SetCommand(shutDownAsia);
            invoker->Run();
            invoker->SetCommand(rebootAsia);
            invoker->Run();

            invoker->Undo();
            invoker->Undo();

            invoker->SetCommand(runDiagnosticsEuro);
            invoker->Run();
            invoker->Undo();
        }
};
}//End OF Namespace

int   main()
{
       using namespace ConsoleApplication4;

       Program *p = new Program();
       system("pause");
}
