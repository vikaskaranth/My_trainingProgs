/*
GOF Implimentation
vikaskaranth@gmail.com
*/

#include<iostream>
using namespace std;
namespace ConsoleApplication1
{

// product 1 - Button

class IButton
{
      public: 
	virtual void setText()=0;
	virtual void getText()=0;
	virtual void show()=0;
	virtual void hide()=0;
	// etc...
};

class XWinButton :public IButton
{
	// some data members here...

	public :
      void setText() {}
	  void getText() {}
	  void show()
	  {
		cout<< "XWinButton\n";
	  }
	  void hide() {}
	// etc...
};

class XMacButton :public IButton
{
	// some data members here...
	public:
      void setText() {}
      void getText() {}
	  void show()
	  {
		cout<<"XMacButton\n";
	  }
	  void hide() {}
	// etc...
};
// product 2 - Label
class ILabel
{
      public:
	virtual void setLabel()=0;
	virtual void getLabel()=0;
	virtual void enableView()=0;
	virtual void setStyle()=0;
	virtual void setFont()=0;
	virtual void setOrientation()=0;
	// etc...
};

class XWinLabel : public ILabel
{
	// some data members here...
   public:
	 void setLabel() {}
     void getLabel() {}
     void enableView()
	 {
		cout<<"XWinLabel\n";
  	 }
     void setStyle() {}
     void setFont() {}
     void setOrientation() {}
	// etc...
};

class XMacLabel : public ILabel
{
	// some data members here...
public:
	void setLabel() {}
	void getLabel() {}
	void enableView()
	{
		cout<<"XMacLabel\n";
	}
    void setStyle() {}
    void setFont() {}
    void setOrientation() {}
	// etc...
};
  // product 3 - Window

class IWindow
{
	public:
    virtual void setTitle()=0;
	virtual void getTitle()=0;
    virtual	void setVisible(bool flag)=0;
    virtual	void setSize()=0;
    virtual	void add()=0;
    virtual	void remove()=0;
	// etc...
};

class XWinWindow : public IWindow
{
	// some data members here...
    public:
	 void setTitle() {}
 	 void getTitle() {}
	 void setVisible(bool flag)
	 {
		if(flag)
			cout << "XWinWindow\n";
	 }
	 void setSize() {}
	 void add() {}
	 void remove() {}
	// etc...
};

class XMacWindow : public IWindow
{
	// some data members here...
public:
	void setTitle() {}
	void getTitle() {}
	void setVisible(bool flag)
	{
		if(flag)
			cout<< "XMacWindow\n";
	}
	void setSize() {}
	void add() {}
	void remove() {}
	// etc...
};


// factories

class IWidgetFactory
{
      public:
	virtual IButton *createButton()=0;
	virtual ILabel *createLabel()=0;
	virtual IWindow *createWindow()=0;
};

class XMacFactory :public IWidgetFactory
{
	public :
       IButton *createButton() { return new XMacButton(); }
	   ILabel *createLabel() { return new XMacLabel(); }
       IWindow *createWindow() { return new XMacWindow(); }
};

class XWinFactory :public IWidgetFactory
{
	public :
           IButton *createButton() { return new XWinButton(); }
	ILabel *createLabel() { return new XWinLabel(); }
	IWindow *createWindow() { return new XWinWindow(); }
};


class LookFeelFactory
{
	public :
           static IWidgetFactory * getLookFeel(int type)
	       {
	        	switch(type)
		        {
          			case 1: return new XMacFactory();			
		        	case 2: return new XWinFactory();					
		         }
           		return NULL;		// throw new UnsupportedLookAndFeelException();
            }
};

// and many other components in the toolkit are available
/* Client interface */
class IForm
{
	public : 
           virtual void showForm(int lfType)=0;
};

/*Concreate Client  */

class AddLFForm : public IForm
{
	public :
      void showForm(int lfType)
   	  {
		IWidgetFactory *factory = LookFeelFactory::getLookFeel(lfType);
		IWindow *w1 = (*factory).createWindow();
		IButton *b1 = (*factory).createButton();
		ILabel *l1 = (*factory).createLabel();

		(*w1).setVisible(true);
		(*b1).show();
		(*l1).enableView();
	}
};

}
int main()
{
    using  namespace ConsoleApplication1;

		int  lfType;
		cout << "1. Mac Look and Feel\n";
		cout << "2. Wndows Look and feel\n";
		cin >> lfType;
		
		IForm *form = new AddLFForm();

		(*form ).showForm(lfType);
		system("pause");
}
