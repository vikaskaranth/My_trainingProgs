/* A class adapter uses multiple inheritance to adapt one interface to another:
     */
     
#include<iostream>
using namespace std;

namespace ConsoleApplication1
{     
    class Duck
    {
        public :
               Duck(){}
               virtual ~Duck(){}
               virtual void PerformQuack()=0;
               virtual void PerformFly()=0;
    };


    class MallardDuck :public  Duck
    {
        public :
           void PerformQuack()
           {
                cout<<"Mallard duck Quacking\n";
           }

           void PerformFly()
           {
               cout<< "Mallard duck Flying\n";
           }
    };

    class RubberDuck :public Duck
    {
        public :
        void PerformQuack()
        { 
          cout<<"Rubber duck Quacking\n";
        }

        void PerformFly()
        {
            cout << "Rubber duck Flying\n";
        }
        
    };

    class Turkey
    {
        public:
        void Gobble()
        {
           cout<< "Turkey Gobbling\n";
        }

       void Fly()
        {
            cout << "Turkey Flying\n";
        }
    };


    class TurkeyAdapter : public Duck
    {
        Turkey turkey;
        public:
        TurkeyAdapter(Turkey &tturkey)
        {
            turkey = tturkey;
        }
        void PerformQuack()
        {
            turkey.Gobble();
        }

        void PerformFly()
        {
            turkey.Fly();
        }
    };
void TestDuck(Duck *duck)
{
      duck->PerformQuack();
      duck->PerformFly();
}
} // EOF Namespace

main()
{
        using namespace ConsoleApplication1;

            Duck *d1 = new MallardDuck();
            cout<<"This is mallard Duck...\n";
            TestDuck(d1);

            Duck *d2 = new RubberDuck();
            cout<<"This is Rubber Duck...\n";
            TestDuck(d2);

            Turkey *turkey = new Turkey();
            Duck *adapter = new TurkeyAdapter(*turkey);
            cout<<"This is Turkey...";
            TestDuck(adapter);
            system("pause");
}
