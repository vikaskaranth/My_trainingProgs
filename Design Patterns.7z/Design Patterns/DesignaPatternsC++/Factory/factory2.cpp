/*   Parameterized factory methods. 
Another variation on the pattern lets the factory method create multiple kinds of products. 
The factory method takes a parameter that identifies the kind of object to create. 
All objects the factory method creates will share the Product interface. 
e. 
*/
#include<iostream>
using namespace std;

class Connection
{
        public :
        Connection()  { }
        virtual string Description()=0;
 };


class OracleConnection :public Connection
{
        public:
        OracleConnection()  {}
        string Description()
        {
            return "Oracle";
        }
};


class SqlServerConnection : public Connection
{
        public :
        SqlServerConnection() {}
        string Description()
        {
            return "SQL Server";
        }
};


class MySqlConnection : public Connection
{
        public :
        string Description()
        {
            return "MySQL";
        }
};
class ConnFactory
{
      protected:
        string type;
      public:
        ConnFactory(string t)
        {
            type = t;
        }
        Connection *CreateConnection()
        {
            if (type=="Oracle")
            {
                return new OracleConnection();
            }
            else if (type=="SQL Server")
            {
                return new SqlServerConnection();
            }
            else
            {
                return new MySqlConnection();
            }
        }
};

main()
{
        ConnFactory   Obj("Oracle");
        Connection  *ptr = Obj.CreateConnection();
        cout << ptr->Description()<<endl;
       
        ConnFactory   Obj2("SQL Server");
        Connection  *ptr2 = Obj2.CreateConnection();
        cout << ptr2->Description()<<endl;
       
        
      system("pause");
      }
