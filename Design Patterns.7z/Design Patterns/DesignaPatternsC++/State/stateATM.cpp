#include<iostream>
using namespace std;


class ATMMachine {
   
    ATMState *hasCard;    
    ATMState *noCard;
    ATMState *hasCorrectPin;
    ATMState *atmOutOfMoney;
    ATMState *atmState;

    int cashInMachine;
    int correctPinEntered;

    public:
    ATMMachine(){
        cashInMachine = 2000;
        correctPinEntered = false;
        hasCard = new HasCard(this);
        noCard = new NoCard(this);
        hasCorrectPin = new HasPin(this);
        atmOutOfMoney = new NoCash(this);
         
        atmState = noCard;

        if(cashInMachine < 0){
            atmState = atmOutOfMoney;
        }
    }
    void setATMState(ATMState* newATMState){
        atmState = newATMState;
    }
    void setCashInMachine(int newCashInMachine){
        cashInMachine = newCashInMachine;
    }
    void insertCard() {
        atmState->insertCard();
    }
    void ejectCard() {
        atmState->ejectCard();
    }
    void requestCash(int cashToWithdraw) {
        atmState->requestCash(cashToWithdraw);
    }
    void insertPin(int pinEntered){
        atmState->insertPin(pinEntered);
    }
    ATMState *getYesCardState() { return hasCard; }

    ATMState *getNoCardState() { return noCard; }

    ATMState *getHasPin() { return hasCorrectPin; }

    ATMState *getNoCashState() { return atmOutOfMoney; }
};



class ATMState {
   // Different states expected
    // HasCard, NoCard, HasPin, NoCash

    virtual void insertCard()=0;
    virtual void ejectCard()=0;
    virtual void insertPin(int pinEntered)=0;
    virtual void requestCash(int cashToWithdraw)=0;
};

class HasCard:public ATMState {

    ATMMachine *atmMachine;
    public:
      HasCard(ATMMachine *newATMMachine){
        atmMachine = newATMMachine;
      }
    void insertCard() {
        cout << "You can only insert one card at a time\n";
    }
    void ejectCard() {
        cout << "Your card is ejected\n";
        atmMachine->setATMState(atmMachine->getNoCardState());
    }
    void requestCash(int cashToWithdraw) {
        cout <<"You have not entered your PIN\n";
    }
    void insertPin(int pinEntered) {
        if(pinEntered == 1234){
            cout <<"You entered the correct PIN\n";

            atmMachine->correctPinEntered = true;

            atmMachine->setATMState(atmMachine->getHasPin());
        } else {
            cout <<"You entered the wrong PIN\n";
            atmMachine->correctPinEntered = false;
            cout <<"Your card is ejected\n";
            atmMachine->setATMState(atmMachine->getNoCardState());
       }  
    }  
}

class NoCard : public ATMState {
    ATMMachine *atmMachine;
    public :
    NoCard(ATMMachine* newATMMachine){
        atmMachine = newATMMachine;
    }
    void insertCard() {
        cout <<"Please enter your pin\n";
        atmMachine->setATMState(atmMachine->getYesCardState());
    }
    void ejectCard() {
        cout <<"You didn't enter a card\n";
    }
    void requestCash(int cashToWithdraw) {
        cout <<"You have not entered your card\n";
    }
    void insertPin(int pinEntered) {
        cout <<"You have not entered your card\n";
    }
}

class HasPin :public ATMState {
    ATMMachine* atmMachine;
    public :
    HasPin(ATMMachine* newATMMachine){
        atmMachine = newATMMachine;
    }
    void insertCard() {
        cout <<"You already entered a card\n";
    }
    void ejectCard() {
        cout <<"Your card is ejected\n";

        atmMachine->setATMState(atmMachine->getNoCardState());
    }
    void requestCash(int cashToWithdraw) {
        if(cashToWithdraw > atmMachine->cashInMachine){
            cout <<"You don't have that much cash available\n";
            cout <<"Your card is ejected\n";
            atmMachine->setATMState(atmMachine->getNoCardState());
        } else {
            cout <<cashToWithdraw + " is provided by the machine\n";
            atmMachine->setCashInMachine(atmMachine->cashInMachine - cashToWithdraw);
            cout <<"Your card is ejected\n";
            atmMachine->setATMState(atmMachine->getNoCardState());
       
            if(atmMachine->cashInMachine <= 0){
                atmMachine->setATMState(atmMachine->getNoCashState());
            }

        }

   }
   void insertPin(int pinEntered) {
        cout <<"You already entered a PIN\n";
    }  
}

class NoCash :public ATMState {
    ATMMachine* atmMachine;
    public :
    NoCash(ATMMachine* newATMMachine){
        atmMachine = newATMMachine;
    }
    void insertCard() {
        cout <<"We don't have any money\n";
        cout <<"Your card is ejected\n";
    }
    public: void ejectCard() {
        cout <<"We don't have any money\n";
        cout <<"There is no card to eject\n";
    }
    public :void requestCash(int cashToWithdraw) {
        cout <<"We don't have any money\n");
    }
    public :void insertPin(int pinEntered) {
        cout <<"We don't have any money\n";
    }  
}


main(){
        ATMMachine *atmMachine = new ATMMachine();
        *(atmMachine).insertCard();
        *(atmMachine).ejectCard();
        *(atmMachine).insertCard();
        *(atmMachine).insertPin(1234);
        *(atmMachine).requestCash(2000);
        *(atmMachine).insertCard();
        *(atmMachine).insertPin(1234);  
    cin.sync();cin.get();
}
