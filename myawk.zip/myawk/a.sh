#!/bin/sh
getfreemem()
{
    ps -aeo rss --no-headers | awk '{ total += $0 } END { print total}'
}

dirsize()
{
   ls -l | awk '{ total += $5 } END { print total }'
}

dirsize

getfreemem

