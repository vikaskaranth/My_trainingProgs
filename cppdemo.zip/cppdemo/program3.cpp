/****************************************************************
*	File name: program3.cpp					*
*	Version No:1.3						*
*     	Description : 						*
*    	Constructor both in the base and derived class		*
* 	This program illustrates obj ect of base class is 	*
*    	created first then derived class. While destructing 	*
*    	derived class destructor is called first then base class*
*****************************************************************/
#include<iostream>

using namespace std;

class Base
{
      int  ix;
     public:
 	Base(void){
 	  cout<<"\nConstructor of base classB \n";
 	}
 	Base(int xx){
          ix = xx;
 	    cout<<"\nOne arg Constructor of base classB \n";
 	}
	void show(){cout <<"ix is "<<ix;}
	~Base() { cout << "destructor in base class is called next\n"; } 
};

class derived : public Base
{
      int iNum1;
    public:
	derived(void){
 		cout<<"Constructor of the derived class executed next\n";
 	}
	derived(int   xx):Base(xx*10){
        iNum1 = xx;
        cout<<"One argument Constructor of the derived class executed next\n";
 	}
	void show(){
         cout <<"\ninum1 is "<<iNum1;
         Base::show();
     }

	~derived() { cout << "destructor in derived class is called first\n"; } 
};

main()
{

	derived obj(10);
	obj.show();
}
