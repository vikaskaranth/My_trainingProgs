#include<iostream>
using namespace std;

namespace nsvikas{

    template<class X>
    X  div(X val1,X val2){
        try{
           if(val2==0){
               throw  val2;
           }
           else
                return val1 / val2;
        }
        catch(int &e)  {
            cerr<<"Zero division Error\n";
        }
    }
}
int main()
{
    int  d1=12, d2=0;
   
    nsvikas::div(d1,d2); 
}
