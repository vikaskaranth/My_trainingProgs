/************************************************************************
*	File name: program7.cpp						*
*	Version No:1.3							*
*       Description : Dynamic initialization through Copy constructors  *
*********************************************************************/  

#include<iostream>
using namespace std;

class Vector 
{
	int *v;
	int sz;
     public:
	Vector(void){ v =NULL; sz=0;}
	Vector (int size) 
	{
		sz = size;
		v = new int[size];
		cout <<"One argument cons\n";
	}
	Vector (Vector & v2);	//Copy constructor
	~Vector () 
	{
		delete 	[]v;
		
	}
      Vector operator=(Vector &tempv);
	int &elem (int i) 
	{
		if (i >= sz)
			cout << "Error:out of range\n";
		return v[i];
	}
	void show ();
};

Vector Vector::operator=(Vector &tempv){
    if(this ==&tempv){
         cout <<"Self assignment\n";
         return *this;
    }
    sz=tempv.sz;
    if(v!=NULL)
        delete []int;
    v = new int[sz];
    for (int i = 0; i < sz; i++)
   	  v[i] = tempv.v[i];
}
Vector::Vector (Vector & tempv) 
{
	cout << "\ncopy constructor invoked";
	sz = tempv.sz;
	v = new int[sz];
	for (int i = 0; i < sz; i++)
		v[i] = tempv.v[i];
}
void Vector::show () 
{
	for (int i = 0; i < sz; i++)
	cout << elem (i) << ",";
}

main () 
{
	int i;
	Vector obj;
	Vector v1 (5), v2 (5);
	for (i = 0; i < 5; i++)
		v1.elem(i) = i + 1;

//	v1 = v2;	// Bit wise copy is done
	Vector v3 =v1; //Copy constructor is called v3(v2)
	//Vector v3(v1); 

	cout << "\nVector v1:";
	v1.show ();

      v2 = v1;
	v2.show();
}
