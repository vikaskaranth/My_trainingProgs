int iVal;
int iData;
int main()
{
    float fVal;

}
