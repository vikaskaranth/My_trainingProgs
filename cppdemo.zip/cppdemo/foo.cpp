namespace ns_foo{
int iData;
void foo(){
    int iVal;
}
}
