#include"cons_Complex.h"

int main()
{
    cout <<"-----------CASE I-----------------"<<endl;
    Complex  obj;
    obj.Display(); 
    cout <<"---------------------------------"<<endl;
    cout <<"Real part is :"<<fixed<<obj.getReal();
    cout <<"Imaginary part is :"<<fixed<<obj.getImag();
  {
    cout <<"----------CASE II-----------------"<<endl;
    Complex  cObj = Complex(55.00);
    cObj.Display(); 
    cout <<"Real part is :"<<fixed<<cObj.getReal();
    cout <<"Imaginary part is :"<<fixed<<cObj.getImag();
  }
    {
    cout <<"----------CASE III ----------------\n";
    Complex  cObj2(55.0,5.00);
    cObj2.Display(); 
    cout <<"Real part is :"<<fixed<<cObj2.getReal();
    cout <<"Imaginary part is :"<<fixed<<cObj2.getImag();
   }
}
