#include<iostream>
using namespace std;

class Shape
{
    protected:
       float  side1, side2;
       float  area, perimeter;
    public:
        Shape(){}
         ~Shape(){cout << "Shape"<<endl;}
        Shape(float s1,float s2){
            side1 = s1;
            side2 = s2;
        }
        virtual float fnarea()=0;//Pure virtual function
        virtual float fnperimeter()=0;

};
class rTriangle:public Shape
{
    float  side3;
    public:
       rTriangle(){}
       ~rTriangle(){cout << " Triangle"<<endl;}
       rTriangle(float s1,float  s2,float s3):Shape(s1,s2)       {
           side3 = s3;
       }
       float fnarea(){
          area = 0.5*side1*side2;
          return area;
       }
       float fnperimeter() {
           perimeter = side1 + side2 + side3;
           return perimeter;
       }
};
class Rectangle:public Shape
{
    public:
       Rectangle(){}
       ~Rectangle(){cout <<"Rectangle" <<endl;}
       Rectangle(float s1,float s2):Shape(s1,s2){ }
       float fnarea(){
          area = side1*side2;
          return area;
       }
       float fnperimeter() {
           perimeter = 2*side1;
           return perimeter;
       }
};

int main()
{
    Shape *ptr=new rTriangle(4,6,9);
    cout<<ptr->fnarea()<<endl;
    cout<<ptr->fnperimeter()<<endl;
    delete  ptr;

    Shape *ptr1=new Rectangle(7,9);
    cout<<ptr1->fnarea()<<endl;
    cout<<ptr1->fnperimeter()<<endl;
 
    delete  ptr1;
}
