#include "myString.h"
mystring(){
	nstring=NULL;
}
myString(const char* s){
	nstring=s;
}
myString(const myString &s){
	nstring=s;
}
~myString(){
	cout<<"destructor is called";
}
bool empty(){
	if(nstring==NULL){
		return true;
	}
	else
		retrun false;
}

myString operator+(const myString &s1,const mySTring &s2){
	myString temp;
	temp=s1+s2;
	return temp;
}
void swap(myString &from){
	myString s1;
	s1=from;
	from=s;
	s1=s;
}
int length(){
	while(getch(nstring)!=NULL){
		nlength++;
	}
	return nlength;
}

