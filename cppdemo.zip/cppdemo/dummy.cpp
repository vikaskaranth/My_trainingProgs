class  Vector{
    int *data;
    int size;
    public:
      Vector(int s){
         size = s;
         data = new int[size];
      }
      Vector(Vector &v){
         size = v.size;
         data = new int[size];
      }

};

int main()
{
     Vector   v1(5);

     Vector   v2(v1);

}
