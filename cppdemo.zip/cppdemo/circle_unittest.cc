#include "gtest/gtest.h"

// In this example, we test the Circle class .

// Tests the default c'tor.
TEST( Circle, DefaultConstructor) {
  const Circle s;

  EXPECT_EQ(0, s.get_radius());
  EXPECT_EQ(0, s.get_diameter());
  EXPECT_EQ(0, s.get_area());
  EXPECT_EQ(0, s.get_circumference());
}


// Tests the c'tor that accepts a float radius.
TEST(Circle, ConstructorFromRadius) {
  const Circle c1(10.0);
  const Circle c2(-10.0);
  const Circle c3(0.0);

  EXPECT_EQ(10,c1.get_radius());
  EXPECT_EQ(0, c1.get_diameter());
  EXPECT_EQ(0, c1.get_area());
  EXPECT_EQ(0, c1.get_circumference());

  EXPECT_EQ(0, c2.get_radius());
  EXPECT_EQ(0, c2.get_diameter());
  EXPECT_EQ(0, c2.get_area());
  EXPECT_EQ(0, c2.get_circumference());

  EXPECT_EQ(0, c3.get_radius());
  EXPECT_EQ(0, c3.get_diameter());
  EXPECT_EQ(0, c3.get_area());
  EXPECT_EQ(0, c3.get_circumference());
}
/*

// Tests the Set method.
TEST(MyString, Set) {
  MyString s;

  s.Set(kHelloString);
  EXPECT_EQ(0, strcmp(s.c_string(), kHelloString));

  // Set should work when the input pointer is the same as the one
  // already in the MyString object.
  s.Set(s.c_string());
  EXPECT_EQ(0, strcmp(s.c_string(), kHelloString));

  // Can we set the MyString to NULL?
  s.Set(NULL);
  EXPECT_STREQ(NULL, s.c_string());
}*/
