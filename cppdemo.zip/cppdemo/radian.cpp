#include<iostream>

class Degree
{
    float  radian;
    static float pi;
    mutable float  degree;
  public:
    Degree(float d){degree = d;}
    float getDegree()const 
    {
        return degree=78;
    }
    static float fnRadian(){return (pi/180);}
};

float Degree::pi=3.1453f;

int main()
{
     Degree  o(23.5),o2(44.5);
     std::cout <<Degree::fnRadian()<<std::endl;
     std::cout <<o.getDegree()*Degree::fnRadian();
}
