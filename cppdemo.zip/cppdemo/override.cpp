// A CPP program that uses override keyword so 
// that any difference in function signature is 
// caught during compilation. 
#include <iostream> 
using namespace std; 

class Base { 
    public: 
	void func() { 
		cout << "I am in base" << endl; 
	} 
}; 

class derived : public Base { 
public: 

	void func() { 
		cout << "I am in derived class" << endl; 
	} 
}; 

int main() 
{ 
	Base b; 
	derived d; 
      d.Base::func();
	cout << "Compiled successfully" << endl; 
	return 0; 
} /*
The override keyword serves two purposes:

It shows the reader of the code that "this is a virtual method, 
that is overriding a virtual method of the base class."

The compiler also knows that it's an override, 
so it can "check" that you are not altering/adding new methods 
that you think are overrides.

class base
{
  public:
    virtual int foo(float x) = 0; 
};
class derived: public base
{
   public:
     int foo(float x) override { ... do stuff with x and such ... }
}
class derived2: public base
{
   public:
     int foo(int x) override { ... } 
};
*/
