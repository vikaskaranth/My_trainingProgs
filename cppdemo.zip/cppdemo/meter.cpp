#include<iostream>
using namespace std;

class metre   {
    float length;
	public:
        metre(){  length=0.0;   }
        metre(float Initlength)  
	    {  length=Initlength/100.0;  }

 //metre(float Initlength) {  length =I nitlength/100.0;  }
//conversion from userdefined type to basic datatype
     operator float()  {
            float lengthcms;
            lengthcms=length*100.0;
            return(lengthcms);
      }        
      void getlength()    {
	    cout<<"\nEnter length in metres:";
	    cin>>length;
      }
      void showlength()    {
	    cout<<"\nlength in metres:"<<length;
     }
};

int main()
{
    metre oMeter(1000.00);
    float  fdata;

    fdata = oMeter;//oMeter.operator float()
    cout << "fadata is : "<<fdata<<endl;
}








