#include <iostream>

using namespace std;
const int imax=1024;
class Stack
{
    int data[imax];
    int  sp,   itop;
    public:
    void setup(void){
        sp = 0;
        itop=0;
    }
    void push(int val){
        if(isStackFull())
            cout <<"Stack full"<<endl;
        else{
            data[sp]=val;
            sp++;
        }
    }
    int pop(){
        if(isStackEmpty())
            cout <<"Stack is empty can't push"<<endl;
        else
            return(data[--sp]);
    }
    bool isStackFull(){
        if(sp==1024) return 1;
        else return 0;
    }
    bool isStackEmpty(){
        if(sp==0) return 1;
        else return 0;
    }
    int top(){
        return data[sp-1];
    }
    int size(){
        return sp;
    }
};

int main()
{
    Stack obj;
    obj.setup();
    obj.push(5);
    obj.push(15);
    obj.push(50);
    obj.push(25);
    obj.push(51);
    
    cout <<"Top element is : "<<obj.top()<<endl;
    cout <<"Size of stack is : "<<obj.size()<<endl;
    cout <<obj.pop()<<endl;
    cout <<obj.pop()<<endl;
    cout <<obj.pop()<<endl;
    cout <<obj.pop()<<endl;
    cout <<obj.pop()<<endl;
    cout <<"Size of stack is : "<<obj.size()<<endl;

    return 0;
}
