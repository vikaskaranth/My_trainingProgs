#include<iostream>

using namespace std;

class Number{
    protected: 
        int value;
    public:
        Number(){}
        Number(int  val){
            value = val;
        }
        virtual void Print(){ }

        virtual ~Number(){  cout <<"Number"<<  endl; }
};
class Hex:public Number  {
    public:
        Hex(){}
        Hex(int v) :Number(v){  }
        virtual void Print(){
           cout <<"Value is : "<<hex<<value ;
        }
        void bar(){cout <<"In bar function\n";}
        ~Hex(){ cout <<"Hex destructor"  <<endl;}
};
class Oct:public Number  {
    public:
        Oct() {  }
        Oct(int v) :Number(v){  }
        virtual void Print(){
           cout <<"Value is : "<<oct<<value ;
        }
        void foo(){cout <<"foo in Oct\n";}
        ~Oct(){ cout <<"Octal destructor" <<endl;}
};
class Decimal:public Number  {
    public:
        Decimal(){}
        Decimal(int v) :Number(v){  }
        virtual void Print(){
           cout <<"Value is : "<<dec<<value ;
        }
};

void Select(Number &ref){
    ref.Print();
}
int main()
{
    Number   *ptr = new Oct(55);
    ptr->Print(); 
    delete  ptr;

    ptr = new Decimal(100);
    ptr->Print();
    delete  ptr;
   
    ptr = new Hex(100);
    ptr->Print();
    delete  ptr;

    //Select(oct_obj);

    Hex   hex_obj(55);
    Select(hex_obj);
    //hex_obj.Print();
*/
}
