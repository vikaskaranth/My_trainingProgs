#include<iostream>
using namespace std;

class Array
{
     int *data;
     int size;
     public:
        Array(){}
        Array(int sz){
           size=sz;
           data = new int[size];
        }
        Array(Array &ref){
           int i;
           size=ref.size;
           data=new int[size];
           for(i=0;i<size;i++){
                *(data+i)=ref.data[i];
            }
        }
        void Read(){
            int i;
            for(i=0;i<size;i++){
                *(data+i)=i*5;
            }
        }
        void Print(){
            int i;
            for(i=0;i<size;i++){
                cout <<*(data+i)<<"->";
            }
            cout <<endl;
        }       
        ~Array(){
            delete []data;
            data=NULL;
        }


};
int main()
{
    Array    obj(5);
    obj.Read();

    Array & obj2=obj;
    obj2.Print();

}
