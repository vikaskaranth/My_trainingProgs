#include<iostream>
using namespace std;

class Circle{
     static float const PI;
     private: 
        float radius;
        float area;
        float circumference;

      public:
        Circle(){}
        Circle(float  r){
            radius = r;
        }
        static void foo(){
            cout << "Foo function is called:"<<endl;
        }
        void setRadius(float r){
              radius = r;
        }
        float fnArea(){
              area = PI *(this->radius)*(this->radius);
              return area;
        }
        float fnCircum(){
              circumference = 2 * PI * radius;
              return circumference;
        }
        float   getRadius(){
             return radius;
        }
        float getCircumf(){   
             return circumference;
        }
        float getArea(){
             return area;
        }
        ~Circle(){}
};
float const Circle::PI=3.1416f;

int main()
{
    Circle  aocir[10];

    aocir[0].setRadius(23.2);
    //ocir->setRadius(23.25);
    cout <<cPtr->fnArea()<<endl; 
    cPtr->fnCircum();
    cout<<cPtr->getCircumf()<<endl;
    cout <<"Radius is:"<<cPtr->getRadius()<<endl;
    cout <<"Area of Circle is : "<<cPtr->getArea()<<endl;
    
    delete  cPtr;
    cPtr=NULL;// Good coding
    return 0;
}
