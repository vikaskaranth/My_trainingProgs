#include<iostream>
using namespace std;
int modify(int  &ref){
      ref=55;
}
int main()
{
     int iNum=10;

     modify(iNum);
     cout <<iNum<<endl;
}
