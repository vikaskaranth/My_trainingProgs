#include<iostream>
using namespace std;

const float PI=3.14159f;
class Circle{
     private: 
        float radius;
        float area;
        float circumference;

      public:
        void setRadius(float r){
              radius = r;
        }
        float fnArea(){
              area = PI *radius*radius;
              return area;
        }
        float fnCircum(){
              circumference = 2 * PI * radius;
              return circumference;
        }
        float   getRadius(){
             return radius;
        }
        float getCircumf(){   
             return circumference;
        }
        float getArea(){
             return area;
        }
};


int main()
{
    Circle  ocir;

    ocir.setRadius(23.25);

    cout <<ocir.fnArea()<<endl; 
    ocir.fnCircum();
    cout<<ocir.getCircumf()<<endl;
    cout <<"Radius is:"<<ocir.getRadius()<<endl;
    cout <<"Area of Circle is : "<<ocir.getArea()<<endl;
    return 0;
}
