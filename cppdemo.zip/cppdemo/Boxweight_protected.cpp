#include<iostream>
using namespace std;

class Cube{
  protected:
    float  height;
    float  width;
    float  length;
    float  volume;
    float surfacearea;

    public:
       Cube(){
           height = 0 ;
           length = 0;
           width = 0;
       }
       Cube(float h, float w, float l){
           height = h;
           length = l;
           width = w;
       }
       Cube(Cube & b){
           height = b.height;
           length = b.length;
           width = b.width;
       }
       void setHeight(float h){
           height = h;
       }
       void setLength(float l){
           length = l;
       }
       void setWidth(float w){
           width = w;
       }
       double fnVolume(){
           volume = length * width * height;
           return  volume;
       }
       double  fnsurfacearea(){
           surfacearea = (2*height * width) + \
           (2 * length * width)+ (2 * height * length);
           return surfacearea;
       }
       float  getVolume(){
           return volume;
       }
       float getSurfaceArea(){
           return surfacearea;
       }
       void Print(){
           cout <<"volume is : "<<volume<<endl;
           cout <<"surfacearea is:"<<surfacearea<<endl;
       }
       float getHeight(void){
           return height;
       }
       float getLength(void){
           return length;
       }
       float getWidth(void){
           return width;
       }

};
class Boxweight:public Cube{
     float weight;
     public:
       Boxweight(){}
       Boxweight(float h,float  w,float l,float m){
           height=h;
           width=w;
           length=l;
           weight = m;
       }
       Boxweight(Boxweight& box):Cube(box){
           weight=box.weight;
       }
       float setWeight(float w){
           weight = w;
       }
       float getWeight(void){
           return weight;
       }

};
int main()
{
    Boxweight   x_obj(12.6,21.3,41.5,45);
    Boxweight   y_obj(x_obj);

    y_obj.fnVolume();
    y_obj.fnsurfacearea();
    y_obj.Print();

    cout <<hex<<y_obj.getWeight()<<endl;
    cout <<y_obj.getLength()<<endl;
    cout <<y_obj.getVolume()<<endl;
}
