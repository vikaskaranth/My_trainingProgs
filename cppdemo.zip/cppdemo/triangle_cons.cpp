#include<iostream>
#include<cmath>
using namespace std;

class RTriangle{
     private:
         float   base ;
         float   height;
         float   area;
         float   perimeter;
     public:
         static float  pi;
         RTriangle(){
             cout <<"Indefault constructor\n" ;
         }
         ~RTriangle(){cout<<"In destructor\n"; }
         RTriangle(float b, float h){
             base = b;
             height = h;
         }
         void setBase(float   b){
              base =b;
          }
         void setHeight(float  h){
               height =h;
         }
         float getBase(void){
              return base;
          }
         float getHeight(void){
               return height;
         }
         float getArea(void){
               return(area);
          }
         float getPerimeter(void){
               return (perimeter);
         }
         float  fnArea(void);
         float  fnPerimeter(void);
};

float   RTriangle::pi=3.14156f;

float  RTriangle::fnArea(void){
     area = 0.5*base*height;
     return(area);
}
float  RTriangle::fnPerimeter(void){
     float  hypo;
     hypo = sqrt(base*base+height*height);
     perimeter = hypo+base+height;
     return perimeter;
}
int main()
{
     
      RTriangle   *ptr=NULL;
      RTriangle   obj(23.123,232.23);
      obj.fnArea();
      obj.fnPerimeter();

      obj.setBase(236.8);
      cout <<"Area is : "<<obj.fnArea()<<endl;
      cout <<"Perimeter is : "<<obj.fnPerimeter()<<endl;

      ptr = new  RTriangle(123.24,65.7213);

      cout <<"Area is : "<<ptr->fnArea()<<endl;
      cout <<"Perimeter is : "<<ptr->fnPerimeter()<<endl;
      
      cout <<"Pi is : "<<RTriangle::pi<<endl;
      delete  ptr;
}

