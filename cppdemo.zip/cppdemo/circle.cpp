#include<iostream>
using namespace std;


class Circle{
     float radius;
     float area;
     static float pi;
  public:
     float fnArea(){
        return pi*radius*radius;
     }
     static void set_pi(float p){
        pi=p;
     }
};

float Circle::pi; //4 bytes allocated

int main()
{
    Circle::set_pi(3.14256);
    Circle::pi=12.32f;
    cout <<Circle::pi;

}
