#include<iostream>
using namespace std;

class Box{
    float  height;
    float  width;
    float  length;
    float  volume;
    float surfacearea;

    public:
       Box(){}
       ~Box(){cout <<"Box";}
       Box(float h, float w, float l){
           height = h;
           length = l;
           width = w;
       }
       Box(Box & b){
           height = b.height;
           length = b.length;
           width = b.width;
       }
       void setHeight(float h){
           height = h;
       }
       void setLength(float l){
           length = l;
       }
       void setWidth(float w){
           width = w;
       }
       double fnVolume(){
           volume = length * width * height;
           return  volume;
       }
       double  fnsurfacearea(){
           surfacearea = (2*height * width) + \
           (2 * length * width)+ (2 * height * length);
           return surfacearea;
       }
       float  getVolume(){
           return volume;
       }
       float getSurfaceArea(){
           return surfacearea;
       }
       void Print(){
           cout <<"volume is : "<<volume<<endl;
           cout <<"surfacearea is:"<<surfacearea<<endl;
       }
       float getHeight(void){
           return height;
       }
       float getLength(void){
           return length;
       }
       float getWidth(void){
           return width;
       }

};
class Boxweight:public virtual Box{
     float weight;
     public:
       Boxweight(){}
       ~Boxweight(){cout <<"Boxweight"<<endl;}
       Boxweight(float  w){
           weight = w;
       }
       Boxweight(float h,float  w,float l,float m):Box(h,w,l){
           weight = m;
       }
       float setWeight(float w){
           weight = w;
       }
       float getWeight(void){
           return weight;
       }

};
class Boxcolor:public virtual Box{
     float color;
     public:
       Boxcolor(){}
       ~Boxcolor(){cout <<"Boxcolor"<<endl;}
       Boxcolor(float  c){
           color  = c;
       }
       Boxcolor(float h,float  w,float l,float c):Box(h,w,l){
           color = c;
       }
       float setColor(float c){
           color = c;
       }
       float getColor(){
           return color;
       }

};
class Shipment: public Boxcolor,public Boxweight{
     float cost;
     public:
       Shipment(){}
       ~Shipment(){cout <<"Shipment"<<endl;}
       Shipment(float h,float  w,float l,float c,float m ,float cost):Box(h,w,l),Boxweight(m),Boxcolor(c){
           this->cost = cost;
       }
       float setColor(float c){
           cost = c;
       }
       float getColor(){
           return cost;
       }

};
int main()
{
    Shipment   *obj = new Shipment(12.6,21.3,41.5,99.9,0x45,1000.00);
    obj->fnVolume();
    obj->fnsurfacearea();
    obj->Print();

    cout <<hex<<"color:"<<obj->getColor()<<endl;
    cout <<"Lengthis :"<<obj->getLength()<<endl;
    cout <<"Volume is :"<<obj->getVolume()<<endl;
    delete obj;
    
}
