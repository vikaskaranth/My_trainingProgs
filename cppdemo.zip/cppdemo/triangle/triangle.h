#include<iostream>
#include<cmath>
using namespace std;

class Triangle{
    float  base;
    float  height;
    float  area;
    float  perimeter;
    public:
      Triangle(float =1.0, float=1.0);
      Triangle(Triangle&);
      
      void  set_base(float);
      void  set_height(float);
      float fnarea(void);
      float fnperimeter(void);
      float  get_base(void);
      float  get_height(void);
      float  get_area(void);
      float  get_primeter(void);
      void display(void);
      ~Triangle();
};
