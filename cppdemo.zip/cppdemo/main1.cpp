int val;
int main()
{


}
