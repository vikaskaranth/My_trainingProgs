#include<iostream>
using namespace std;


class base{
public:
 int bval;
 base(){ bval=0;}
};

class deri:public base {
public: 
  int dval;
  deri(){ dval=1;}
};
void SomeFunc(base *arr,int size)
{
for(int i=0; i<size; i++,arr++)
        cout<<arr->bval;
cout<<endl;
}

int main(int c, char  **v) {
     cout << v[0]<<endl;
     cout << v[1]<<endl;
     cout << v[2]<<endl;
     cout << v[3]<<endl;

     cout <<  "argc is " << c<<endl;
base BaseArr[5];
SomeFunc(BaseArr,5);
deri DeriArr[5];
SomeFunc(DeriArr,5);
}

