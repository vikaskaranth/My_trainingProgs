#include<iostream>

using namespace std;

void modify(int &x)const 
{
     x  *=x;
}

int main()
{
     int a = 10;
     cout <<"a is "<<a   <<endl;
     modify(a);

     cout <<"after modify:"<<a<<endl;
}
