#include<iostream>
using namespace std;

inline int    max(int  ,int );
inline float  max (float , float);
inline double max (double , double );

int main()
{
   int ival1,ival2;
   float fval1,fval2;
   double dval1,dval2;

   cout <<"Enter integers vals:" <<endl;
   cin >> ival1>>ival2;

   cout <<"Enter float vals:" <<endl;
   cin >> fval1>>fval2;

   cout <<"Enter double vals:" <<endl;
   cin >> dval1>>dval2;

   cout << max(ival1,ival2)<<endl;
   cout <<max (fval1,fval2)<<endl;
   cout <<fixed<<max (dval1,dval2)<<endl;
}
int    max(int x ,int y){
     return(x>y?x:y);
}
float  max (float x, float y){
     return(x>y?x:y);
}
double max (double x, double y){
     return(x>y?x:y);
}
