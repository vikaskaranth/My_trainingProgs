#include<iostream>
using namespace std;


int main()
{
    int *ptr;
    ptr = new int;
    *ptr=999;

    int *ptr2;
    ptr2= ptr;

    delete ptr;

    cout <<*ptr2<<endl;
}
