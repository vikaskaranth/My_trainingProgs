#include<iostream>
using namespace std;

class sample{
    private: int  private_val;
    protected: int protected_val;
    public:
        sample(int ii=0, int jj=0){
            private_val=ii;
            protected_val = jj;
        }
        friend void Display(sample &ref);
        friend void modify(sample &ref);
};

void Display(sample &ref){
     cout <<"private_val is :"<<ref.private_val<<endl;
     cout <<"protected val is :"<<ref.protected_val <<endl;
}
void modify(sample &ref){
     ref.private_val=999;
     ref.protected_val=555 ;
}

int main()
{
   /*
     sample osample(5,10);
     Display(osample);
     modify(osample);
     Display(osample);
*/
    int *ptr ;
   delete ptr;

}
