#include<iostream>
using namespace std;

class Duck
{
     char   colour[15];
     int   weight;
     float price;

    public:
        virtual void walk()=0;
        virtual void swim()=0;
        void change_colour(){
            cout <<" decorate\n" ;
        }
};
class Mallard:public Duck
{
    public:
        void walk(){
            cout <<"Walkes using two legs\n";
        }
        void swim(){
            cout<<"Swims using legs\n";
        }
};
class Rubber_duck:public Duck
{
    public:
        void walk(){
            cout <<"Do not walk\n";
        }
        void swim(){
            cout <<"Floats\n";
        }
};
int main()
{
     Duck  *ptr;
 
     ptr= new Mallard();

     ptr->walk();//
     ptr->swim();

     ptr= new Rubber_duck();
     ptr->walk();
     ptr->swim();

}
